package com.findme.blueto;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;

/**
 * Created by csw on 2017-08-30.
 */

public class FindMeView extends View {
    private int curValue; //현재값 저장
    private int minValue; //최대값 저장
    private int maxValue; //최대값 저장
    private int lineColor; //진행바 색 저장
    private Handler mHandler = new Handler();
    public FindMeView(Context context){
        super(context);
    }

    public FindMeView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);

        TypedArray a = context.getTheme().obtainStyledAttributes(attrs, R.styleable.FindMeView,0,0);

        try{
            this.minValue = a.getInteger(R.styleable.FindMeView_minValue2,100);
            this.maxValue = a.getInteger(R.styleable.FindMeView_maxValue2,100);
            this.curValue = a.getInteger(R.styleable.FindMeView_curValue2,100);
            this.lineColor = a.getColor(R.styleable.FindMeView_lineColor2,0xff000000);

        }finally {

        }

    }
    public int getLineColor() {
        return lineColor;
    }

    public void setLineColor(int color) {
        this.lineColor = color;
        invalidate();
        requestLayout();
    }

    public int getCurValue() {
        return curValue;
    }

    public void setCurValue(int curValue) {
        if(curValue>=minValue) {
            this.curValue = curValue;
        }else{
            this.curValue = minValue;
        }

        invalidate();
        requestLayout();
    }

    public int getMaxValue() {
        return maxValue;
    }

    public void setMaxValue(int maxValue) {
        this.maxValue = maxValue;
        invalidate();
        requestLayout();
    }

    public int getMinValue() {
        return maxValue;
    }

    public void setMinValue(int maxValue) {
        this.maxValue = maxValue;
        invalidate();
        requestLayout();
    }




    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int width  =  this.getMeasuredWidth();
        int height = this.getMeasuredHeight();
        System.out.println("width : "+width+"height "+height);


        // 원 그리기 속성
        Paint circle = new Paint();
        circle.setColor(Color.BLACK);
        circle.setStrokeWidth(5);
        circle.setAntiAlias(false);
        circle.setStyle(Paint.Style.STROKE);
// 진행바 그리기
        float radius = (float)width/(float)2;
        radius -= (float)circle.getStrokeWidth() /(float) 2;

        canvas.drawCircle(width/2,height/2,radius,circle);



        //중앙
       Paint pointC = new Paint();
        pointC.setColor(Color.BLACK);
        pointC.setStrokeWidth(10);
        canvas.drawPoint(radius,radius,pointC);
        // 점 그리기
        Paint point = new Paint();
        point.setColor(Color.RED);
        point.setStrokeWidth(10);

        canvas.drawPoint(radius,(radius-(radius/(maxValue-minValue)*(curValue-minValue))),point);

    }












}
