package com.findme.blueto;

/**
 * Created by csw on 2017-08-28.
 */

public class FindMeItem {
    String name;
    String addr;
    long checktime;
    int rssi;
    int isOut = -1;

    public FindMeItem(String name, String addr, long checktime, int rssi) {
        this.name = name;
        this.addr = addr;
        this.checktime = checktime;
        this.rssi = rssi;
        isOut = -1;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public long getChecktime() {
        return checktime;
    }

    public void setChecktime(long checktime) {
        this.checktime = checktime;
    }

    public int getRssi() {
        return rssi;
    }

    public void setRssi(int rssi) {
        this.rssi = rssi;
    }
}
