package com.findme.blueto;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;



import java.util.ArrayList;


public class FindMeAdapter extends BaseAdapter {
	private Context context;
	private LayoutInflater inflater;
	private ArrayList<FindMeItem> arSrc;
	private int layout;

	public FindMeAdapter(Context c, int layout, ArrayList<FindMeItem> arSrc) {
		this.context = c;
		this.inflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		this.arSrc = arSrc;
		this.layout = layout;

	}

	@Override
	public int getCount() {
		return arSrc.size();
	}

	@Override
	public FindMeItem getItem(int position) {
		return arSrc.get(position);
	}

	@Override
	public long getItemId(int arg0) {
		return 0;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		LVHolder viewHolder;

		if (convertView == null) {
			convertView = inflater.inflate(layout, parent, false);

			viewHolder = new LVHolder();
			viewHolder.tv_name = (TextView) convertView.findViewById(R.id.device_name);
			viewHolder.tv_addr = (TextView) convertView.findViewById(R.id.device_address);
			viewHolder.tv_rssi = (TextView) convertView.findViewById(R.id.device_rssi);
			viewHolder.findMeView = (FindMeView)convertView.findViewById(R.id.device_find);

			convertView.setTag(viewHolder);
		} else {
			viewHolder = (LVHolder) convertView.getTag();
		}

		FindMeItem item = arSrc.get(position);
		viewHolder.tv_name.setText(item.getName());
		viewHolder.tv_addr.setText(item.getAddr());
		viewHolder.tv_rssi.setText(item.getRssi()+"");
		viewHolder.findMeView.setCurValue(Math.abs(item.getRssi()));
		return convertView;
	}



	public class LVHolder {
		TextView tv_name,tv_addr,tv_rssi;
		FindMeView findMeView;
	}

	

	



}
