package com.findme.blueto;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;

import java.util.ArrayList;

public class FindmeActivity extends Activity {

    private BluetoothAdapter mBluetoothAdapter;
    ArrayList<FindMeItem> alDevice = new ArrayList<>();
    long checkTime;
    Handler handler = new Handler();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_findme);
        checkTime = System.currentTimeMillis();
        FindMeDBAdapter dbAdapter = new FindMeDBAdapter(FindmeActivity.this);
        dbAdapter.open();
        Cursor c = dbAdapter.fetchAllEntry();
        while(c.moveToNext()){
            alDevice.add(new FindMeItem(c.getString(1),c.getString(2), System.currentTimeMillis(),0));
        }
        dbAdapter.close();
        final BluetoothManager bluetoothManager =
                (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = bluetoothManager.getAdapter();
        scanLeDevice(true);
        handler.postDelayed(checkRunnable,10000);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        scanLeDevice(false);
        handler.removeCallbacks(checkRunnable);
    }

    private void scanLeDevice(final boolean enable) {
        if (enable) {
            // Stops scanning after a pre-defined scan period.


            mBluetoothAdapter.startLeScan(mLeScanCallback);
        } else {

            mBluetoothAdapter.stopLeScan(mLeScanCallback);
        }

    }

    // Device scan callback.
    private BluetoothAdapter.LeScanCallback mLeScanCallback =
            new BluetoothAdapter.LeScanCallback() {

                @Override
                public void onLeScan(final BluetoothDevice device, final int rssi, byte[] scanRecord) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            int n = -1;
                            String name ="";
                            System.out.println("device"+device.getAddress()+" "+rssi);
                            for(int i=0;i<alDevice.size();i++){
                                if(device.getAddress().equals(alDevice.get(i).getAddr())){
                                    n =i;
                                    name = device.getName();
                                }
                            }
                            if(n >= 0) {
                                alDevice.remove(n);
                                alDevice.add(new FindMeItem(name,device.getAddress(), System.currentTimeMillis(),rssi));
                                checkTime = System.currentTimeMillis();
                            }

                        }
                    });
                }
            };
            Runnable checkRunnable = new Runnable() {
                @Override
                public void run() {
                    if(checkTime+10000 < System.currentTimeMillis()){
                        Toast.makeText(FindmeActivity.this, "아웃", Toast.LENGTH_SHORT).show();
                    }
                    handler.postDelayed(checkRunnable,2000);
                }
            };
}
