package com.findme.blueto;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.app.NotificationCompat;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.gun0912.tedpermission.PermissionListener;
import com.gun0912.tedpermission.TedPermission;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private BluetoothAdapter mBluetoothAdapter;
    ListView list;
    ArrayList<FindMeItem> alDevice = new ArrayList<>();
    long checkTime;
    Handler handler = new Handler();
    ImageView iv_plus;

    boolean isScan =false;
    FindMeAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        checkPermission();
        list = (ListView)findViewById(R.id.list);
        adapter = new FindMeAdapter(this,R.layout.listitem_find,alDevice);
        list.setAdapter(adapter);
        iv_plus = (ImageView)findViewById(R.id.iv_plus);
        iv_plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,RegistActivity.class);
                startActivity(intent);
                scanLeDevice(false);
            }
        });
        checkTime = System.currentTimeMillis();
        FindMeDBAdapter dbAdapter = new FindMeDBAdapter(MainActivity.this);
        dbAdapter.open();
        Cursor c = dbAdapter.fetchAllEntry();
        while(c.moveToNext()){
            alDevice.add(new FindMeItem(c.getString(1),c.getString(2), System.currentTimeMillis(),0));
        }
        dbAdapter.close();
        final BluetoothManager bluetoothManager =
                (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = bluetoothManager.getAdapter();
        scanLeDevice(true);
        handler.postDelayed(checkRunnable,10000);
    }
    public void checkPermission(){
        TedPermission.with(this)
                .setPermissionListener(permissionlistener)
                .setDeniedMessage("If you reject permission,you can not use this service\n\nPlease turn on permissions at [Setting] > [Permission]")
                .setPermissions(Manifest.permission.ACCESS_COARSE_LOCATION)
                .check();
    }
    PermissionListener permissionlistener = new PermissionListener() {
        @Override
        public void onPermissionGranted() {
            Toast.makeText(MainActivity.this, "Permission Granted", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onPermissionDenied(ArrayList<String> deniedPermissions) {
            Toast.makeText(MainActivity.this, "Permission Denied\n" + deniedPermissions.toString(), Toast.LENGTH_SHORT).show();
        }


    };

    @Override
    protected void onStart() {
        super.onStart();
        if(!isScan){
            scanLeDevice(true);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        scanLeDevice(false);
        handler.removeCallbacks(checkRunnable);
    }

        private void scanLeDevice(final boolean enable) {
            isScan= enable;
        if (enable) {
            // Stops scanning after a pre-defined scan period.


            mBluetoothAdapter.startLeScan(mLeScanCallback);
        } else {

            mBluetoothAdapter.stopLeScan(mLeScanCallback);
        }

    }

    // Device scan callback.
    private BluetoothAdapter.LeScanCallback mLeScanCallback =
            new BluetoothAdapter.LeScanCallback() {

                @Override
                public void onLeScan(final BluetoothDevice device, final int rssi, byte[] scanRecord) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            int n = -1;
                            String name ="";
                            System.out.println("device"+device.getName()+" "+rssi);
                            for(int i=0;i<alDevice.size();i++){
                                if(device.getAddress().equals(alDevice.get(i).getAddr())){
                                    n =i;

                                    name = device.getName();
                                    if(alDevice.get(i).isOut== 2){

                                        Toast.makeText(MainActivity.this, "인", Toast.LENGTH_SHORT).show();
                                        NotificationSomethings("인",alDevice.get(i).getName()+"들어왔습니다.");
                                    }
                                    alDevice.get(i).isOut = 1;
                                    checkTime = System.currentTimeMillis();
                                    alDevice.get(i).checktime = checkTime;
                                    alDevice.get(i).rssi = rssi;
                                    adapter.notifyDataSetChanged();
                                }
                            }


                        }
                    });
                }
            };
    Runnable checkRunnable = new Runnable() {
        @Override
        public void run() {

            for(int i=0;i<alDevice.size();i++){
                System.out.println("alDevice.get(i).isOut"+alDevice.get(i).addr+" "+alDevice.get(i).isOut+ " "+(alDevice.get(i).checktime+10000)+ " "+ System.currentTimeMillis());
                if(alDevice.get(i).isOut==-1 || alDevice.get(i).isOut ==1 ){
                    if((alDevice.get(i).checktime+10000)<=System.currentTimeMillis() ){
                        alDevice.get(i).isOut = 2;
                        alDevice.get(i).rssi = -100;
                        Toast.makeText(MainActivity.this, "아웃", Toast.LENGTH_SHORT).show();
                        NotificationSomethings("아웃",alDevice.get(i).getName()+"벗어났습니다.");
                        adapter.notifyDataSetChanged();
                    }
                }
            }
            handler.postDelayed(checkRunnable,2000);
        }
    };
    public void NotificationSomethings(String strTitle,String strSub) {


        Resources res = getResources();

        Intent notificationIntent = new Intent(this, MainActivity.class);
        notificationIntent.putExtra("notificationId", 9999); //전달할 값
        notificationIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this);

        builder.setContentTitle(strTitle)
                .setContentText(strSub)

                .setSmallIcon(R.mipmap.ic_launcher)
                .setLargeIcon(BitmapFactory.decodeResource(res, R.mipmap.ic_launcher))
                .setContentIntent(contentIntent)
                .setAutoCancel(true)
                .setWhen(System.currentTimeMillis())
                .setDefaults(Notification.DEFAULT_ALL);



        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            builder.setCategory(Notification.CATEGORY_MESSAGE)
                    .setPriority(Notification.PRIORITY_HIGH)
                    .setVisibility(Notification.VISIBILITY_PUBLIC);
        }

        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(1234, builder.build());
    }
}
