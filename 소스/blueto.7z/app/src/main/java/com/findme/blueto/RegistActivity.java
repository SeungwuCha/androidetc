package com.findme.blueto;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RegistActivity extends Activity {
    EditText et_name;
    TextView tv_addr;
    Button btn_addr;
    Button btn_reg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regist);

        et_name = (EditText)findViewById(R.id.et_name);
        tv_addr = (TextView)findViewById(R.id.tv_addr);
        btn_addr = (Button)findViewById(R.id.btn_addr);
        btn_addr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RegistActivity.this,DeviceScanActivity.class);
                startActivityForResult(intent,0);

            }
        });
        btn_reg = (Button)findViewById(R.id.btn_reg);
        btn_reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String strName = et_name.getText().toString().trim();
                String strAddr = tv_addr.getText().toString().trim();
                if(strName.equals("")){
                    Toast.makeText(RegistActivity.this, "이름 입력하세요.", Toast.LENGTH_SHORT).show();
                }else if(strAddr.equals("")){
                    Toast.makeText(RegistActivity.this, "주소 입력하세요.", Toast.LENGTH_SHORT).show();
                }else {
                    FindMeDBAdapter dbAdapter = new FindMeDBAdapter(RegistActivity.this);
                    dbAdapter.open();
                    dbAdapter.createEntry(strName,strAddr);
                    dbAdapter.close();
                }

            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 0){
            if(resultCode == RESULT_OK){
                String addr = data.getStringExtra("addr");
                System.out.println("addr " + addr);
                tv_addr.setText(addr);
            }
        }
    }
}
