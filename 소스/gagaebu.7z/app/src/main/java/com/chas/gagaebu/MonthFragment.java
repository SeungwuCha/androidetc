package com.chas.gagaebu;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import io.github.luizgrp.sectionedrecyclerviewadapter.SectionedRecyclerViewAdapter;


public class MonthFragment extends Fragment {

    SectionedRecyclerViewAdapter sectionAdapter;
    ArrayList<GaGaeItem> alString = new ArrayList<>();
    String strDate = "";
    GaGaeDBAdapter dbAdapter;
    public MonthFragment() {
        // Required empty public constructor
    }


    // TODO: Rename and change types and number of parameters
    public static MonthFragment newInstance() {
        MonthFragment fragment = new MonthFragment();

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_item_list, container, false);
        // Inflate the layout for this fragment

        // Set the adapter
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
        strDate = sdf.format(new Date());
        sectionAdapter = new SectionedRecyclerViewAdapter();


        dbAdapter = new GaGaeDBAdapter(getContext());
        dbAdapter.open();
        Cursor c = dbAdapter.fetchAllEntryForYear();
        while(c.moveToNext()){


            List<GaGaeItem> contacts = getContactsWithLetter(c.getString(0));
            int income = 0;
            int expand = 0;

            if (contacts.size() > 0) {
                for(GaGaeItem item : contacts){
                    if(item.getType().equals("1")){
                        income += Integer.parseInt(item.getWon());
                    }else{
                        expand += Integer.parseInt(item.getWon());
                    }
                }
                sectionAdapter.addSection(new ContactsSectionForMonth(new HeaderItem(String.format("%s",strDate),income,expand), contacts));
            }
        }

        dbAdapter.close();


        RecyclerView recyclerView = (RecyclerView) view.findViewById(R.id.list);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(sectionAdapter);


        return view;
    }

    private List<GaGaeItem> getContactsWithLetter(String year) {
        List<GaGaeItem> alRtn = new ArrayList<>();
        Cursor c=dbAdapter.fetchAllEntryForMonth(year);
        while(c.moveToNext()){
            //String time, String title, String won, String content, String type
            alRtn.add(new GaGaeItem(c.getString(0),"",c.getString(1),"",""));
            System.out.println("c.getString(0)"+c.getString(0));
            System.out.println("c.getString(1)"+c.getString(1));
        }
        return alRtn;
    }



    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onDetach() {
        super.onDetach();

    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
