package com.chas.gagaebu;

import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import io.github.luizgrp.sectionedrecyclerviewadapter.SectionedRecyclerViewAdapter;


/**
 * A fragment representing a list of Items.
 * <p/>

 */
public class ItemFragment extends Fragment {

    /**
     * Mandatory empty constructor for the fragment manager to instantiate the
     * fragment (e.g. upon screen orientation changes).
     */
    ArrayList<GaGaeItem> alString = new ArrayList<>();
    String strDate = "";
    public ItemFragment() {
    }

    // TODO: Customize parameter initialization
    @SuppressWarnings("unused")
    public static ItemFragment newInstance() {
        ItemFragment fragment = new ItemFragment();

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);



    }

    SectionedRecyclerViewAdapter sectionAdapter;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_item_list, container, false);
        getList();
        // Set the adapter
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
        strDate = sdf.format(new Date());
        sectionAdapter = new SectionedRecyclerViewAdapter();


        for(int i=1;i<=31;i++) {
            List<GaGaeItem> contacts = getContactsWithLetter(i);
            int income = 0;
            int expand = 0;

            if (contacts.size() > 0) {
                for(GaGaeItem item : contacts){
                    if(item.getType().equals("1")){
                        income += Integer.parseInt(item.getWon());
                    }else{
                        expand += Integer.parseInt(item.getWon());
                    }
                }
                sectionAdapter.addSection(new ContactsSection(new HeaderItem(String.format("%s-%02d",strDate,i),income,expand), contacts));
            }
        }

        RecyclerView recyclerView = (RecyclerView) view.findViewById(R.id.list);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(sectionAdapter);
        return view;
    }

    private List<GaGaeItem> getContactsWithLetter(int i) {
        List<GaGaeItem> alRtn = new ArrayList<>();
        for(GaGaeItem item : alString){
            if(item.getTime().contains(String.format("%s-%02d",strDate,i))){
                alRtn.add(item);
            }
        }
        return alRtn;
    }

    public void getList(){
        GaGaeDBAdapter dbAdapter = new GaGaeDBAdapter(getContext());
        dbAdapter.open();
        Cursor cursor = dbAdapter.fetchAllEntry();
        alString.clear();
        while(cursor.moveToNext()){
            alString.add(new GaGaeItem(cursor.getString(1),cursor.getString(3),cursor.getString(2),cursor.getString(4),cursor.getString(5)));
        }
        dbAdapter.close();
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onDetach() {
        super.onDetach();

    }



}
