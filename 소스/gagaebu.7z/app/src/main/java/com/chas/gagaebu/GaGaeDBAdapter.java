package com.chas.gagaebu;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;
import android.util.Log;

public class GaGaeDBAdapter {


    private static final String DATABASE_NAME = "gagae.db";
    private static final String DATABASE_TABLE = "tb_gagae";

    public static final int DATABASE_VERSION = 2;

    private static final String DATABASE_CREATE = "create table "
            + DATABASE_TABLE + " (" + GaGaeEntry.GAGAE_IDX
            + " INTEGER AUTO_INCREMENT primary key, " + GaGaeEntry.GAGAE_TIME
            + " DATETIME not null, " + GaGaeEntry.GAGAE_WON
            + " INTEGER not null, " + GaGaeEntry.GAGAE_TITLE
            + " TEXT not null, " + GaGaeEntry.GAGAE_CONTENT
            + " TEXT not null, " + GaGaeEntry.GAGAE_TYPE
            + " INTEGER not null);";
    private static final String TAG = "GAGAEDBAdapter";

    public String[] COLUMNS = new String[]{GaGaeEntry.GAGAE_IDX,
            GaGaeEntry.GAGAE_TIME, GaGaeEntry.GAGAE_WON,GaGaeEntry.GAGAE_TITLE, GaGaeEntry.GAGAE_CONTENT,GaGaeEntry.GAGAE_TYPE
    };
    private String[] CountCOLUMNS = new String[]{"count(idx)"
    };
    private Context mContext;
    private DCTDatabaseHelper mDbHelper;
    private SQLiteDatabase mDb;

    public GaGaeDBAdapter(Context context) {
        mContext = context;
    }

    public GaGaeDBAdapter open() throws SQLException {
        mDbHelper = new DCTDatabaseHelper(mContext);
        mDb = mDbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        if (mDbHelper != null)
            mDbHelper.close();
    }


    public long createEntryGAGAE(String time, String won,String title,String content,String type) {
        ContentValues initialValues = new ContentValues();


        initialValues.put(GaGaeEntry.GAGAE_TIME, time);
        initialValues.put(GaGaeEntry.GAGAE_WON, won);
        initialValues.put(GaGaeEntry.GAGAE_TITLE, title);
        initialValues.put(GaGaeEntry.GAGAE_CONTENT, content);
        initialValues.put(GaGaeEntry.GAGAE_TYPE, type);

        return mDb.insert(DATABASE_TABLE, null, initialValues);
    }

    public long updateEntry(String idx, String time, String won,String title,String content,String type) {
        ContentValues initialValues = new ContentValues();

        initialValues.put(GaGaeEntry.GAGAE_TIME, time);
        initialValues.put(GaGaeEntry.GAGAE_WON, won);
        initialValues.put(GaGaeEntry.GAGAE_TITLE, title);
        initialValues.put(GaGaeEntry.GAGAE_CONTENT, content);
        initialValues.put(GaGaeEntry.GAGAE_TYPE, type);

        return mDb.update(DATABASE_TABLE, initialValues, GaGaeEntry.GAGAE_IDX + " = " + idx, null);

    }


    public Cursor selectIDXEntry(int nIdx) {
        //
        Cursor qu = mDb.query(DATABASE_TABLE, COLUMNS,
                GaGaeEntry.GAGAE_IDX + " = " + nIdx,
                null, null, null, null);

        return qu;

    }

    public Cursor fetchDateEntry(String date) {
        System.out.println("Select * from " + DATABASE_TABLE + " where time LIKE " + date + "%%");
        return mDb.rawQuery("Select * from " + DATABASE_TABLE + " where time LIKE '" + date + "%%'", null);

    }

    public String[] twodateDateEntry(String date) {
        String[] strx = new String[2];
        System.out.println("\"Select * from \"+DATABASE_TABLE+\" where time LIKE '\"+date+\"%% order by idx asc'\"");
        Cursor c1 = mDb.rawQuery("Select * from " + DATABASE_TABLE + " where time LIKE '" + date + "%%' order by idx asc", null);
        Cursor c2 = mDb.rawQuery("Select * from " + DATABASE_TABLE + " where time LIKE '" + date + "%%' order by idx desc", null);
        if (c1.moveToNext()) {
            strx[0] = c1.getString(1);
        }
        if (c2.moveToNext()) {
            strx[1] = c2.getString(1);
        }

        return strx;
    }
    public Cursor fetchAllEntryForMonth() {
        return mDb.rawQuery("Select strftime('%Y-%m', g_datetime) yr_mon,sum(g_won),g_type from " + DATABASE_TABLE + " group by yr_mon,g_type ", null);
    }
    public Cursor fetchAllEntryForMonth(String year) {
        return mDb.rawQuery("Select strftime('%Y-%m', g_datetime) yr_mon,sum(g_won),g_type,strftime('%Y', g_datetime) yr from " + DATABASE_TABLE +" where yr ='"+year +"' group by yr_mon,g_type ", null);
    }

    public Cursor fetchAllEntryForYear() {
        return mDb.rawQuery("Select strftime('%Y', g_datetime) yr,sum(g_won),g_type from " + DATABASE_TABLE + " group by yr,g_type ", null);
    }

    public Cursor fetchAllEntry(int x) {
        return mDb.rawQuery("Select * from " + DATABASE_TABLE + " where time NOT LIKE '"+  1970+"%%' ORDER BY idx desc LIMIT 7 " + "OFFSET " + (x * 7), null);
    }

    public Cursor fetchAllEntry() {

        return mDb.query(DATABASE_TABLE, COLUMNS, null, null, null, null, null);

    }

    public Cursor countAllEntry() {
        //return mDb.rawQuery("Select * from "+DATABASE_TABLE,null);
        return mDb.query(DATABASE_TABLE, COLUMNS, null, null, null, null, null);
    }

    public Cursor fetchAllEntryASC() {
        return mDb.query(DATABASE_TABLE, COLUMNS, null, null, null, null, GaGaeEntry.GAGAE_IDX + " asc");
    }


    public int fetchAllEntryLength() {
        return mDb.query(DATABASE_TABLE, COLUMNS, null, null, null, null, null).getCount();
    }

    public void delIDXEntry(int nIdx) {
        mDb.delete(DATABASE_TABLE, GaGaeEntry.GAGAE_IDX + "= " + nIdx, null);
    }

    private class DCTDatabaseHelper extends SQLiteOpenHelper {

        public DCTDatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(DATABASE_CREATE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
                    + newVersion + ", which will destory all old data");
          //  db.execSQL("ALTER TABLE "+ DATABASE_TABLE +" ADD COLUMN "+ GaGaeEntry.GAGAE_SPEED+"{TEXT}");
             db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
                onCreate(db);
        }

    }


    public class GaGaeEntry implements BaseColumns {
        public static final String GAGAE_IDX = "idx";
        public static final String GAGAE_TIME = "g_datetime";
        public static final String GAGAE_TITLE = "g_title";
        public static final String GAGAE_WON = "g_won";
        public static final String GAGAE_CONTENT = "g_content";
        public static final String GAGAE_TYPE = "g_type";

    }

}
