package com.chas.gagaebu;

/**
 * Created by csw on 2017-06-08.
 */

public class HeaderItem {
    //날짜
    String title;
    //수입
    int income;
    //지출
    int expand;

    public HeaderItem(String title, int income, int expand) {
        this.title = title;
        this.income = income;
        this.expand = expand;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getIncome() {
        return income;
    }

    public void setIncome(int income) {
        this.income = income;
    }

    public int getExpand() {
        return expand;
    }

    public void setExpand(int expand) {
        this.expand = expand;
    }
}
