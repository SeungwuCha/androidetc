package com.chas.gagaebu;

/**
 * Created by csw on 2017-06-08.
 */

public class GaGaeItem {
    String time;
    String title;
    String won;
    String content;
    String type;

    public GaGaeItem(String time, String title, String won, String content, String type) {
        this.time = time;
        this.title = title;
        this.won = won;
        this.content = content;
        this.type = type;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getWon() {
        return won;
    }

    public void setWon(String won) {
        this.won = won;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
