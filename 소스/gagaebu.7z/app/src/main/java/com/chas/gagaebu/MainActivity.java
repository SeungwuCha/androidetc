package com.chas.gagaebu;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

import com.rengwuxian.materialedittext.MaterialEditText;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
//https://github.com/rengwuxian/MaterialEditText
    //날짜 관리 변수
    Calendar cal;
    //날짜 텍스트
    TextView tv_date;
    //날짜 왼쪽 버튼
    Button btn_left;
    //날짜 오른쪽 버튼
    Button btn_right;
    //오늘버튼
    Button btn_today;
    //달력버튼
    Button btn_cal;
    //타이틀
    MaterialEditText et_title;
    //타이틀
    MaterialEditText et_won;
    //타이틀
    MaterialEditText et_content;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        cal = new GregorianCalendar();
        tv_date = (TextView)findViewById(R.id.tv_date);
        btn_left = (Button)findViewById(R.id.btn_left);
        btn_left.setOnClickListener(this);
        btn_right = (Button)findViewById(R.id.btn_right);
        btn_right.setOnClickListener(this);
        btn_today = (Button)findViewById(R.id.btn_today);
        btn_today.setOnClickListener(this);
        btn_cal = (Button)findViewById(R.id.btn_cal);
        btn_cal.setOnClickListener(this);

        et_title = (MaterialEditText)findViewById(R.id.et_title);
        et_won = (MaterialEditText)findViewById(R.id.et_won);
        et_content = (MaterialEditText)findViewById(R.id.et_content);

        getDateText();
    }

    private void getDateText() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String strdate = sdf.format(cal.getTime());
        tv_date.setText(strdate);
    }

    @Override
    public void onClick(View v) {
        if(v ==  btn_left){
            cal.add(Calendar.DATE,-1);
            getDateText();
        }else if(v == btn_right){
            cal.add(Calendar.DATE,+1);
            getDateText();
        }else if(v ==  btn_today){
            //오늘 날짜
            cal = new GregorianCalendar();
            getDateText();
        }else if(v ==  btn_cal){
            DatePickerDialog datePickerDialog = new DatePickerDialog(MainActivity.this,datePickerListener,cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH));
            datePickerDialog.show();
        }
    }

    // DAte Listener Call on date dialog call
    private DatePickerDialog.OnDateSetListener datePickerListener = new DatePickerDialog.OnDateSetListener() {
        // when dialog box is closed, below method will be called.
        public void onDateSet(DatePicker view, int selectedYear, int selectedMonth, int selectedDay) {
            cal.set(selectedYear,selectedMonth,selectedDay);
            getDateText();
        }
    };
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_done) {
            addData();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void addData() {
        String strTitle = et_title.getText().toString();
        String strWon = et_won.getText().toString();
        String strContent = et_content.getText().toString();
        if(strTitle.trim().equals("")){
            et_title.requestFocus();
            Toast.makeText(this,"계정을 입력하세요.",Toast.LENGTH_SHORT).show();
            return;
        }

        if(strWon.trim().equals("")){
            et_won.requestFocus();
            Toast.makeText(this,"금액을 입력하세요.",Toast.LENGTH_SHORT).show();
            return;
        }

        if(strContent.trim().equals("")){
            et_content.requestFocus();
            Toast.makeText(this,"내용을 입력하세요.",Toast.LENGTH_SHORT).show();
            return;
        }

        GaGaeDBAdapter dbAdapter = new GaGaeDBAdapter(this);
        dbAdapter.open();
        long rtn = dbAdapter.createEntryGAGAE(tv_date.getText().toString(),strWon,strTitle,strContent,"1");
        if(rtn>0){
            Toast.makeText(this,"입력에 성공 되었습니다.",Toast.LENGTH_SHORT).show();
            finish();
        }else{
            Toast.makeText(this,"입력에 실패 되었습니다.",Toast.LENGTH_SHORT).show();
        }


    }
}
