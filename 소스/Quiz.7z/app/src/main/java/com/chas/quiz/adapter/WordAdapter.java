package com.chas.quiz.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.chas.quiz.R;
import com.chas.quiz.item.Word;

import java.util.ArrayList;


public class WordAdapter extends BaseAdapter {
	private Context context;
	private LayoutInflater inflater;
	private ArrayList<Word> arSrc;
	private int layout;

	public WordAdapter(Context c, int layout, ArrayList<Word> arSrc) {
		this.context = c;
		this.inflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		this.arSrc = arSrc;
		this.layout = layout;

	}

	@Override
	public int getCount() {
		return arSrc.size();
	}

	@Override
	public Word getItem(int position) {
		return arSrc.get(position);
	}

	@Override
	public long getItemId(int arg0) {
		return 0;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		LVHolder viewHolder;

		if (convertView == null) {
			convertView = inflater.inflate(layout, parent, false);

			viewHolder = new LVHolder();

			viewHolder.tv_data = (TextView) convertView.findViewById(R.id.tv_data);


			convertView.setTag(viewHolder);
		} else {
			viewHolder = (LVHolder) convertView.getTag();
		}


		Word item = arSrc.get(position);

		viewHolder.tv_data.setText(item.getKeyword());




		
		return convertView;
	}



	public class LVHolder {

		TextView tv_data;
	}

	

	



}
