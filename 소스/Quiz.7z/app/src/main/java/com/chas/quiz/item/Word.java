package com.chas.quiz.item;

/**
 * Created by csw on 2017-05-25.
 */

public class Word {
    String idx;
    String keyword;
    String data;
    String r_opinion;
    String people;
    String ground;

    public Word(String idx, String keyword, String data, String r_opinion, String people, String ground) {
        this.idx = idx;
        this.keyword = keyword;
        this.data = data;
        this.r_opinion = r_opinion;
        this.people = people;
        this.ground = ground;
    }

    public String getIdx() {
        return idx;
    }

    public void setIdx(String idx) {
        this.idx = idx;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getR_opinion() {
        return r_opinion;
    }

    public void setR_opinion(String r_opinion) {
        this.r_opinion = r_opinion;
    }

    public String getPeople() {
        return people;
    }

    public void setPeople(String people) {
        this.people = people;
    }

    public String getGround() {
        return ground;
    }

    public void setGround(String ground) {
        this.ground = ground;
    }
}
