package com.chas.quiz.db;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;
import android.util.Log;


public class OpinionDBAdapter {


    private static final String DATABASE_NAME = "opinion.db";
    private static final String DATABASE_TABLE = "\"opinion\"";

    public static final int DATABASE_VERSION = 1;

    private static final String DATABASE_CREATE = "create table "
            + DATABASE_TABLE + " (" + OpinionEntry.OP_IDX
            + " INTEGER primary key, "+ OpinionEntry.OP_KEYWORD
            + " TEXT, "+ OpinionEntry.OP_DATA
            + " TEXT, " + OpinionEntry.OP_R
            + " TEXT, " + OpinionEntry.OP_PEOPLE
            + " TEXT, " + OpinionEntry.OP_GROUND
            + " TEXT);";
    private static final String TAG = "OpinionDBAdapter";

    public String[] COLUMNS = new String[]{OpinionEntry.OP_IDX, OpinionEntry.OP_KEYWORD,
            OpinionEntry.OP_DATA, OpinionEntry.OP_R,OpinionEntry.OP_PEOPLE,OpinionEntry.OP_GROUND
    };
    private String[] CountCOLUMNS = new String[]{"count(idx)"
    };
    private Context mContext;
    private OpinionDatabaseHelper mDbHelper;
    private SQLiteDatabase mDb;

    public OpinionDBAdapter(Context context) {
        mContext = context;
    }

    public OpinionDBAdapter open() throws SQLException {
        try {
            mDbHelper = new OpinionDatabaseHelper(mContext);
            mDb = mDbHelper.getWritableDatabase();
        }catch (Exception e){
            e.printStackTrace();
        }
        return this;
    }

    public void close() {
        if (mDbHelper != null)
            mDbHelper.close();
    }


    public long createEntry(String idx, String keyword, String data,String r_op,String people,String ground) {
        ContentValues initialValues = new ContentValues();

        initialValues.put(OpinionEntry.OP_IDX,idx);
        initialValues.put(OpinionEntry.OP_KEYWORD, keyword);
        initialValues.put(OpinionEntry.OP_DATA, data);
        initialValues.put(OpinionEntry.OP_R, r_op);
        initialValues.put(OpinionEntry.OP_PEOPLE, people);
        initialValues.put(OpinionEntry.OP_GROUND, ground);




        return mDb.insert(DATABASE_TABLE, null, initialValues);
    }

    public long updateEntry(String idx, String keyword, String data,String r_op,String people,String ground) {
        ContentValues initialValues = new ContentValues();


        initialValues.put(OpinionEntry.OP_KEYWORD, keyword);
        initialValues.put(OpinionEntry.OP_DATA, data);
        initialValues.put(OpinionEntry.OP_R, r_op);
        initialValues.put(OpinionEntry.OP_PEOPLE, people);
        initialValues.put(OpinionEntry.OP_GROUND, ground);

        return mDb.update(DATABASE_TABLE, initialValues, OpinionEntry.OP_IDX + " = " + idx, null);

    }


    public Cursor selectIDXEntry(int nIdx) {
        //
        Cursor qu = mDb.query(DATABASE_TABLE, COLUMNS,
                OpinionEntry.OP_IDX + " = " + nIdx,
                null, null, null, null);

        return qu;

    }



    public Cursor fetchAllEntry() {
        return mDb.query(DATABASE_TABLE, COLUMNS, null, null, null, null, null);
    }

    public Cursor countAllEntry() {
        //return mDb.rawQuery("Select * from "+DATABASE_TABLE,null);
        return mDb.query(DATABASE_TABLE, CountCOLUMNS, null, null, null, null, null);
    }

    public Cursor fetchAllEntry(String str) {

        return mDb.rawQuery("Select * from " + DATABASE_TABLE + " where keyword LIKE '" + str + "%%'", null);
    }




    public void delIDXEntry(int nIdx) {
        mDb.delete(DATABASE_TABLE, OpinionEntry.OP_IDX + "= " + nIdx, null);
    }

    private class OpinionDatabaseHelper extends SQLiteOpenHelper {

        public OpinionDatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(DATABASE_CREATE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
                    + newVersion + ", which will destory all old data");
            db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
            onCreate(db);
        }

    }



    public void create(SQLiteDatabase db){




    }


    public class OpinionEntry implements BaseColumns {
        //인덱스
        public static final String OP_IDX = "idx";
        //키워드
        public static final String OP_KEYWORD = "keyword";
        //내용
        public static final String OP_DATA = "data";
        //반댓말
        public static final String OP_R = "r_opinion";
        //관련인물
        public static final String OP_PEOPLE = "people";
        //
        public static final String OP_GROUND = "ground";
        
    }

}
