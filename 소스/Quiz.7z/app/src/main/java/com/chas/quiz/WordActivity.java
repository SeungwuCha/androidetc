package com.chas.quiz;

import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.EditText;
import android.widget.ListView;

import com.chas.quiz.adapter.WordAdapter;
import com.chas.quiz.db.OpinionDBAdapter;
import com.chas.quiz.item.Word;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class WordActivity extends AppCompatActivity {
    OpinionDBAdapter dbAdapter;
    ArrayList<Word> alWord = new ArrayList<>();
    WordAdapter adapter;
    ListView list;
    EditText edit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_word);
        list = (ListView)findViewById(R.id.list);
        edit = (EditText)findViewById(R.id.edit);
        edit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                    getList(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        adapter =  new WordAdapter(this,R.layout.word,alWord);
        list.setAdapter(adapter);
        getList("");

     //   copyDbFile(this,"opinion.db");
    }

    private void getList(String str) {
        dbAdapter =  new OpinionDBAdapter(this);
        dbAdapter.open();
        str = str.trim();
        Cursor c;
        if(str.equals("")) {
             c = dbAdapter.fetchAllEntry();
        }else{
            c = dbAdapter.fetchAllEntry(str);
        }
        alWord.clear();
        while(c.moveToNext()){
            alWord.add(new Word(c.getString(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5)));
        }
        adapter.notifyDataSetChanged();
    }

    public static void copyDbFile(Context context, String dbname) {
        Log.i(context.getClass().getName(), "copyDbFile();");

        File fromFile = new File(Environment.getDataDirectory() + "/data/"+context.getPackageName()+"/databases/"+dbname);
        File toFile = new File(Environment.getExternalStorageDirectory() + "/"+dbname);
        FileOutputStream fos = null;
        BufferedOutputStream bos = null;


        try {

            InputStream is = new FileInputStream(fromFile);

            if (!toFile.exists()) {
                toFile.createNewFile();
            }
            fos = new FileOutputStream(toFile);
            bos = new BufferedOutputStream(fos);

            int read = -1;
            byte[] buffer = new byte[1024];
            while ((read = is.read(buffer, 0, 1024)) != -1) {
                bos.write(buffer, 0, read);
            }
            bos.flush();

            fos.close();
            bos.close();
            is.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
