package com.chas.quiz;

import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity {

    Button btn_word,btn_quiz;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //TODO 버전체크해서 가져올지 체크
        initDbFile(this,"opinion.db");
        btn_word = (Button)findViewById(R.id.btn_word);
        btn_word.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(MainActivity.this,WordActivity.class);
                startActivity(intent);
            }
        });
        btn_quiz = (Button)findViewById(R.id.btn_quiz);
        btn_quiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(MainActivity.this,QuizActivity.class);
                startActivity(intent);
            }
        });
    }

    public static boolean initDbFile(Context context, String dbname) {
        boolean bRtn = false;
        Log.i(context.getClass().getName(), "copyDbFile();");
        AssetManager am = context.getAssets();



        File toFile = new File(Environment.getDataDirectory() + "/data/" + context.getPackageName() + "/databases/" + dbname);

        FileOutputStream fos = null;
        BufferedOutputStream bos = null;


        try {

            InputStream is = am.open(dbname);
            if (!toFile.exists()) {
                toFile.createNewFile();
            }
            fos = new FileOutputStream(toFile);
            bos = new BufferedOutputStream(fos);
            int read = -1;
            byte[] buffer = new byte[1024];
            while ((read = is.read(buffer, 0, 1024)) != -1) {
                bos.write(buffer, 0, read);
            }
            bos.flush();

            fos.close();
            bos.close();
            is.close();
            bRtn = true;

        } catch (IOException e) {
            e.printStackTrace();
        }
        return bRtn;
    }

}
