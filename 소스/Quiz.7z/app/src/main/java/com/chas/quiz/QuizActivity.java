package com.chas.quiz;

import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.chas.quiz.db.OpinionDBAdapter;

public class QuizActivity extends AppCompatActivity {
    Button btn_answer_1,btn_answer_2;
    Button btn_answer_3,btn_answer_4;
    LinearLayout layout_people,layout_r_opinion;
    TextView tv_people,tv_data,tv_r_opinion;
    int answer = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);
        btn_answer_1 = (Button)findViewById(R.id.btn_answer_1);
        btn_answer_2 = (Button)findViewById(R.id.btn_answer_2);
        btn_answer_3 = (Button)findViewById(R.id.btn_answer_3);
        btn_answer_4 = (Button)findViewById(R.id.btn_answer_4);
        layout_people = (LinearLayout)findViewById(R.id.layout_people);
        layout_r_opinion = (LinearLayout)findViewById(R.id.layout_r_opinion);
        tv_people = (TextView)findViewById(R.id.tv_people);
        tv_data = (TextView)findViewById(R.id.tv_data);
        tv_r_opinion = (TextView)findViewById(R.id.tv_r_opinion);
        getData();
    }

    private void getData() {
        //정답을 선정 랜덤함수로
        int answer = (int)((double)Math.random()*(double)4.0)+1;
        //300개 문항에서 랜덤함수로 선택
        int quiz = (int)((double)Math.random()*(double)300.0)+1;

        OpinionDBAdapter dbAdapter = new OpinionDBAdapter(this);
        dbAdapter.open();
        Cursor c = dbAdapter.selectIDXEntry(quiz);
        if(c.moveToNext()){
            tv_data.setText(c.getString(2));
            if(answer == 1){
                getBtnText(btn_answer_1,"① "+c.getString(1));
            }else if(answer ==2){
                getBtnText(btn_answer_2,"② "+c.getString(1));
            }else if(answer ==3){
                getBtnText(btn_answer_3,"③ "+ c.getString(1));
            }else if(answer ==4){
                getBtnText(btn_answer_4,"④ "+ c.getString(1));
            }
            if(c.getString(4)!=null && !c.getString(4).equals("")){
                layout_people.setVisibility(View.VISIBLE);
                tv_people.setText(c.getString(4));
            }else{
                layout_people.setVisibility(View.GONE);
            }
            if(c.getString(3)!=null && !c.getString(3).equals("")){
                layout_r_opinion.setVisibility(View.VISIBLE);
                tv_r_opinion.setText(c.getString(3));
            }else{
                layout_r_opinion.setVisibility(View.GONE);
            }

        }
        c.close();
        //나머지 오답 넣기
        for(int i = 1;i<=4;i++){
            //정답번호는 스킵
            if(i==answer){
                continue;
            }
            quiz = (int)((double)Math.random()*(double)300.0)+1;
            c = dbAdapter.selectIDXEntry(quiz);
            if(c.moveToNext()) {
                if (i == 1) {
                    getBtnText(btn_answer_1, "① "+c.getString(1));
                } else if (i == 2) {
                    getBtnText(btn_answer_2, "② "+c.getString(1));
                } else if (i == 3) {
                    getBtnText(btn_answer_3, "③ "+c.getString(1));
                } else if (i == 4) {
                    getBtnText(btn_answer_4, "④ "+c.getString(1));
                }
            }
            c.close();
        }

    }
    public void getBtnText(Button btn,String text){
        btn.setText(text);
    }
}
