package com.roadpia.ssuryo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    TextView tv_total,tv_a,tv_b,tv_c,tv_d;
    EditText et_total,et_a,et_b,et_c,et_d;
    TextView tv_i_total;
    int total=0,a=0,b=0,c=0,d=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Calendar calendar = Calendar.getInstance();

        initRes();
    }

    private void initRes() {
        tv_total = (TextView)findViewById(R.id.tv_total);
        tv_a = (TextView)findViewById(R.id.tv_a);
        tv_b = (TextView)findViewById(R.id.tv_b);
        tv_c = (TextView)findViewById(R.id.tv_c);
        tv_d = (TextView)findViewById(R.id.tv_d);

        tv_i_total = (TextView)findViewById(R.id.tv_i_total);

        et_total = (EditText) findViewById(R.id.et_total);
        et_total.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                checkTotal(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        et_a = (EditText)findViewById(R.id.et_a);
        et_a.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                checkA(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        et_b = (EditText)findViewById(R.id.et_b);
        et_b.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                checkB(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        et_c = (EditText)findViewById(R.id.et_c);
        et_c.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                checkC(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        et_d = (EditText)findViewById(R.id.et_d);
        et_d.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                checkD(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    private void checkTotal(String charSequence) {
        double seller = 0;
        int insentive = 0;
        try{
            seller = Double.parseDouble(charSequence);
            if(seller >=350000){
                insentive = 2500;
            }else if(seller >=300000){
                insentive = 2000;
            }else if(seller >=250000){
                insentive = 1500;
            }else if(seller >=200000){
                insentive = 1000;
            }else{
                insentive = 0;
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        total = insentive;
        tv_total.setText(String.format("%d",insentive));
        setTotalI();

    }

    private void checkA(String charSequence) {
        double seller = 0;
        int insentive = 0;
        try{
            seller = Double.parseDouble(charSequence);
            if(seller >=65000){
                insentive = 1500;
            }else if(seller >=55000){
                insentive = 1000;
            }else if(seller >=45000){
                insentive = 700;
            }else if(seller >=35000){
                insentive = 500;
            }else{
                insentive = 0;
            }
        }catch (Exception e){
            e.printStackTrace();
        }

        a = insentive;
        tv_a.setText(String.format("%d",insentive));
        setTotalI();

    }
    private void checkB(String charSequence) {
        double seller = 0;
        int insentive = 0;
        try{
            seller = Double.parseDouble(charSequence);
            if(seller >=35000){
                insentive = 1500;
            }else if(seller >=30000){
                insentive = 1000;
            }else if(seller >=25000){
                insentive = 700;
            }else if(seller >=20000){
                insentive = 500;
            }else{
                insentive = 0;
            }
        }catch (Exception e){
            e.printStackTrace();
        }

        b = insentive;
        tv_b.setText(String.format("%d",insentive));
        setTotalI();

    }
    private void checkC(String charSequence) {
        double seller = 0;
        int insentive = 0;
        try{
            seller = Double.parseDouble(charSequence);
            if(seller >=60000){
                insentive = 1500;
            }else if(seller >=50000){
                insentive = 1000;
            }else if(seller >=40000){
                insentive = 700;
            }else if(seller >=30000){
                insentive = 500;
            }else{
                insentive = 0;
            }
        }catch (Exception e){
            e.printStackTrace();
        }

        c = insentive;
        tv_c.setText(String.format("%d",insentive));
        setTotalI();

    }
    private void checkD(String charSequence) {
        double seller = 0;
        int insentive = 0;
        try{
            seller = Double.parseDouble(charSequence);
            if(seller >=35000){
                insentive = 1500;
            }else if(seller >=30000){
                insentive = 1000;
            }else if(seller >25000){
                insentive = 700;
            }else if(seller >20000){
                insentive = 500;
            }else{
                insentive = 0;
            }
        }catch (Exception e){
            e.printStackTrace();
        }

        d = insentive;
        tv_d.setText(String.format("%d",insentive));
        setTotalI();
    }

    public void setTotalI(){
        int totali = total+a+b+c+d;
        tv_i_total.setText(String.format("%d",totali));
    }
}
