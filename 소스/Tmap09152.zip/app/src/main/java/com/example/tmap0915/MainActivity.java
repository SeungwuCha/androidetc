package com.example.tmap0915;


import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tmap0915.db.ScoreDBAdapter;
import com.example.tmap0915.dialog.ScoreDialog;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";


    //점수등록
    private TextView tv_write;
    //달력
    private TextView tv_calendar;
    //볼링일지
    private TextView tv_report;

    //최고점수
    TextView tv_maxScore;
    //평균점수
    TextView tv_avgScore;

    //퍼미션 관련
    private final int MY_PERMISSION_REQUEST_STORAGE = 100;
    /**
     * Application permission 목록, android build target 23
     */
    public static final String[] MANDATORY_PERMISSIONS = {
            "android.permission.READ_EXTERNAL_STORAGE", "android.permission.ACCESS_FINE_LOCATION","android.permission.WRITE_EXTERNAL_STORAGE"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        Button btn_Mapview = (Button) findViewById(R.id.mapview);
        tv_write = findViewById(R.id.tv_write);
        tv_calendar = findViewById(R.id.tv_calender);
        tv_report = findViewById(R.id.tv_report);
        tv_write.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                writeScore();
            }
        });



        tv_calendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CalendarActivity.class);
                startActivity(intent);
            }
        });
        tv_report.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ReportListActivity.class);
                startActivity(intent);
            }
        });



        btn_Mapview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MapView.class);
                startActivity(intent);
            }
        });
        tv_maxScore = findViewById(R.id.tv_maxScore);

        tv_avgScore = findViewById(R.id.tv_avgScore);

        //초기 데이터 설정
        dataSync();

        if (android.os.Build.VERSION.SDK_INT >= 23) {
            checkPermission(MANDATORY_PERMISSIONS);
        }



    }

    public void writeScore(){
        ScoreDialog scoreDialog = new ScoreDialog(this);
        scoreDialog.setClickListener(new ScoreDialog.ClickListener() {
            @Override
            public void setOnClick() {
                dataSync();
            }
        });
        scoreDialog.show();
    }

    private void dataSync() {
        int high=0,sum=0,avgCount =0,avg =0;
        ScoreDBAdapter scoreDBAdapter = new ScoreDBAdapter(this);
        scoreDBAdapter.open();
        Cursor c = scoreDBAdapter.fetchAllEntry();
        while(c.moveToNext()){
            int nData = c.getInt(1);
            //최고기록
            if(nData>high){
                high = nData;
            }
            //합계
            sum += nData;
            //카운트
            avgCount++;
        }
        //평균
        if(avgCount!=0){
            avg = sum/avgCount;
        }
        scoreDBAdapter.close();

        tv_maxScore.setText(String.format("%d",high));
        tv_avgScore.setText(String.format("%d",avg));


    }

    @TargetApi(23)
    private void checkPermission(String[] permissions) {
        requestPermissions(permissions, MY_PERMISSION_REQUEST_STORAGE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSION_REQUEST_STORAGE:
                break;
        }
    }

}