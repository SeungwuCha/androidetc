package com.example.tmap0915;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.example.tmap0915.adapter.ReportAdapter;
import com.example.tmap0915.db.ReportDBAdapter;
import com.example.tmap0915.item.ReportItem;

import java.util.ArrayList;

public class ReportListActivity extends AppCompatActivity {
    //일지리스트
    RecyclerView recyclerView;

    ReportAdapter reportAdapter;
    ArrayList<ReportItem> alitem = new ArrayList<>();

    Button btn_write;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_list);

        recyclerView = findViewById(R.id.recycler);
        reportAdapter = new ReportAdapter(this,alitem);
        recyclerView.setAdapter(reportAdapter);

        btn_write = findViewById(R.id.btn_write);

        btn_write.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ReportListActivity.this,ReportActivity.class);
                startActivity(intent);
            }
        });

        findViewById(R.id.layout_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


    }

    @Override
    protected void onStart() {
        super.onStart();
        getData();
    }

    public void getData(){
        ReportDBAdapter reportDBAdapter = new ReportDBAdapter(this);

        reportDBAdapter.open();

        Cursor c = reportDBAdapter.fetchAllEntry();
        alitem.clear();
        while (c.moveToNext()){
            alitem.add(new ReportItem(c.getString(0),c.getString(1),c.getString(4),c.getInt(3),c.getString(2)));
        }


        reportAdapter.notifyDataSetChanged();
        Log.e("size",alitem.size()+" "+reportAdapter.getItemCount());
    }

}
