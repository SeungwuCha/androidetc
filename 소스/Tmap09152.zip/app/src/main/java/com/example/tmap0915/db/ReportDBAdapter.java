package com.example.tmap0915.db;



import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;
import android.util.Log;

public class ReportDBAdapter {


	private static final String DATABASE_NAME = "Report.db";
	private static final String DATABASE_TABLE = "tb_Report";

	public static final int DATABASE_VERSION = 1;
	private static final String DATABASE_CREATE = "create table "
			+ DATABASE_TABLE + " (" + ReportEntry.Report_IDX
			+ " INTEGER primary key, " +  ReportEntry.Report_TITLE
			+ " TEXT not null, " + ReportEntry.Report_date
			+ " TEXT not null, " + ReportEntry.Report_import
			+ " INTEGER not null, " + ReportEntry.Report_content
			+ " TEXT not null);";
	private static final String TAG = "BoothDBAdapter";

	public String[] COLUMNS = new String[] {ReportEntry.Report_IDX,
			ReportEntry.Report_TITLE, ReportEntry.Report_date, ReportEntry.Report_import,ReportEntry.Report_content
			};
	public String[] COLUMNSDate = new String[] {
			ReportEntry.Report_date,"AVG(s_Report)","count(*)"
	};
	private String[] CountCOLUMNS = new String[] {"count(idx)"
			};
	private Context mContext;
	private DCTDatabaseHelper mDbHelper;
	private SQLiteDatabase mDb;

	public ReportDBAdapter(Context context) {
		mContext = context;
	}

	public ReportDBAdapter open() throws SQLException {
		mDbHelper = new DCTDatabaseHelper(mContext);
		mDb = mDbHelper.getWritableDatabase();
		return this;
	}

	public void close() {
		if(mDbHelper!=null)
			mDbHelper.close();
	}
	
	
	public long createEntry(String strTitle, String strDate,String strImport,String strContent) {
		ContentValues initialValues = new ContentValues();


		initialValues.put(ReportEntry.Report_TITLE, strTitle);
		initialValues.put(ReportEntry.Report_date, strDate);
		initialValues.put(ReportEntry.Report_import, strImport);
		initialValues.put(ReportEntry.Report_content, strContent);
		
		
		return mDb.insert(DATABASE_TABLE, null, initialValues);
	}

	public long updateEntry(String strIdx,String strTitle, String strDate,String strImport,String strContent) {
		ContentValues initialValues = new ContentValues();

		initialValues.put(ReportEntry.Report_IDX, strIdx);
		initialValues.put(ReportEntry.Report_TITLE, strTitle);
		initialValues.put(ReportEntry.Report_date, strDate);
		initialValues.put(ReportEntry.Report_import, strImport);
		initialValues.put(ReportEntry.Report_content, strContent);


		return mDb.update(DATABASE_TABLE,initialValues,ReportEntry.Report_IDX + " = " + strIdx,null);
	}
	


	

	public Cursor selectIDXEntry(int nIdx) {
		//
		Cursor qu = mDb.query(DATABASE_TABLE, COLUMNS,
				ReportEntry.Report_IDX+" = "+nIdx,
				null, null, null, null);
		
		return qu;
		
	}
	public Cursor fetchAllEntry() {
		return mDb.query(DATABASE_TABLE, COLUMNS, null, null, null, null, null);
	}

	
	public Cursor fetchAllEntryDate() {
		return mDb.query(DATABASE_TABLE, COLUMNSDate, null, null, ReportEntry.Report_date, null, null);
	}

	
	
	public int fetchAllEntryLength() {
		return mDb.query(DATABASE_TABLE, COLUMNS, null, null, null, null, null).getCount();
	}
	
	public void delIDXEntry(String nIdx) {
		mDb.delete(DATABASE_TABLE, ReportEntry.Report_IDX+"= "+nIdx, null);
	}

	private class DCTDatabaseHelper extends SQLiteOpenHelper {

		public DCTDatabaseHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			db.execSQL(DATABASE_CREATE);
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
					+ newVersion + ", which will destory all old data");
			db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
			onCreate(db);
		}

	}

	
	public class ReportEntry implements BaseColumns {
		public static final String Report_IDX = "r_idx";
		public static final String Report_TITLE = "r_title";
		public static final String Report_date = "r_date";
		public static final String Report_import = "r_import";
		public static final String Report_content = "r_content";
	}
	
}
