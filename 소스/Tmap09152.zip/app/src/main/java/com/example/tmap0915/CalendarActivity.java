package com.example.tmap0915;

import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;

import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.applandeo.materialcalendarview.CalendarView;
import com.applandeo.materialcalendarview.EventDay;
import com.applandeo.materialcalendarview.listeners.OnCalendarPageChangeListener;
import com.applandeo.materialcalendarview.listeners.OnDayClickListener;
import com.example.tmap0915.db.ScoreDBAdapter;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class CalendarActivity extends AppCompatActivity {

    CalendarView calendarView;
    List<EventDay> events = new ArrayList<>();

    TextView tv_avg,tv_max,tv_count;

    TextView tv_avg_label,tv_max_label,tv_count_label;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_calendar);
        tv_avg = findViewById(R.id.tv_avg);
        tv_max = findViewById(R.id.tv_max);
        tv_count = findViewById(R.id.tv_count);

        tv_avg_label = findViewById(R.id.tv_avg_label);
        tv_max_label = findViewById(R.id.tv_max_label);
        tv_count_label = findViewById(R.id.tv_count_label);

        initCalander();

        findViewById(R.id.layout_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


    }

    private void initCalander() {




        calendarView = (CalendarView) findViewById(R.id.calendarView);




        setEvent();
        setData();


        calendarView.setOnDayClickListener(new OnDayClickListener() {
            @Override
            public void onDayClick(EventDay eventDay) {

            }
        });
        calendarView.setOnForwardPageChangeListener(new OnCalendarPageChangeListener() {
            @Override
            public void onChange() {
              Log.e("day",calendarView.getCurrentPageDate().get(Calendar.MONTH)+""+calendarView.getCurrentPageDate().get(Calendar.YEAR));
                setData();
            }
        });
        calendarView.setOnPreviousPageChangeListener(new OnCalendarPageChangeListener() {
            @Override
            public void onChange() {
                Log.e("day",calendarView.getCurrentPageDate().get(Calendar.MONTH)+""+calendarView.getCurrentPageDate().get(Calendar.YEAR));
                setData();
            }
        });



    }
    public void setEvent(){

        ScoreDBAdapter scoreDBAdapter = new ScoreDBAdapter(this);
        scoreDBAdapter.open();
        Cursor c = scoreDBAdapter.fetchAllEntryDate();
        while(c.moveToNext()){
            String data = c.getString(0);
            int year = Integer.parseInt(data.substring(0,4));
            int month = Integer.parseInt(data.substring(5,7));
            int day = Integer.parseInt(data.substring(8,10));
            int avg = c.getInt(1);
            int count = c.getInt(2);
            addEvent(year,month,day,avg,count);
        }
        scoreDBAdapter.close();

    }

    public void setData(){
        ScoreDBAdapter scoreDBAdapter = new ScoreDBAdapter(this);
        scoreDBAdapter.open();
        String ym = String.format("%04d-%02d",calendarView.getCurrentPageDate().get(Calendar.YEAR),calendarView.getCurrentPageDate().get(Calendar.MONTH)+1);
        Log.e("ym",ym);

        Cursor c = scoreDBAdapter.fetchAllEntryDate2(ym);
        int sumData = 0;
        int maxData = 0;
        int count = 0;
        while(c.moveToNext()){
            int data = c.getInt(1);
            sumData += data;
            if(maxData<data){
                maxData = data;
            }
            count++;
        }

        Log.e("sumData",sumData+" "+maxData+" "+count+" ");
        if(count != 0 && sumData !=0){
            tv_avg.setText(String.format("%d",sumData/count));
            tv_max.setText(String.format("%d",maxData));
            tv_count.setText(String.format("%d",count));
        }else{
            tv_avg.setText(String.format("%d",0));
            tv_max.setText(String.format("%d",maxData));
            tv_count.setText(String.format("%d",count));
        }

        tv_avg_label.setText(String.format("%d월 에버리지",calendarView.getCurrentPageDate().get(Calendar.MONTH)+1));
        tv_max_label.setText(String.format("%d월 HIGH",calendarView.getCurrentPageDate().get(Calendar.MONTH)+1));
        tv_count_label.setText(String.format("%d월 게임수",calendarView.getCurrentPageDate().get(Calendar.MONTH)+1));

    }


    public void addEvent(int year,int month,int date,int value,int game){
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, month-1);
        calendar.set(Calendar.DAY_OF_MONTH, date);
        //  events.add(new EventDay(calendar4, DrawableUtils.getThreeDots(this)));
        events.add(new EventDay(calendar,String.format("%d",value),String.format("%d",game)));
        calendarView.setEvents(events);
    }
}
