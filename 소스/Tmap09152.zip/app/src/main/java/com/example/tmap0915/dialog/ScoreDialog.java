package com.example.tmap0915.dialog;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;

import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.tmap0915.R;
import com.example.tmap0915.db.ScoreDBAdapter;

import java.util.Calendar;


public class ScoreDialog extends Dialog implements View.OnClickListener {

    private Context mContext;
    // 날짜 시간
    private Button btn_date,btn_time;
    //점수
    private EditText et_score;
    //확인 취소
    private Button btn_ok,btn_cancel;



    private ClickListener clickListener = null;

    //이벤트 값
    private int event;

    public ScoreDialog(Context context) {
        super(context);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setBackgroundDrawable((new ColorDrawable(Color.TRANSPARENT)));
        setContentView(R.layout.popup_score);

        mContext = context;

        initRes();
    }

    private void initRes() {
       // tv_message = findViewById(R.id.tv_message);


        Calendar calendar = Calendar.getInstance();
        btn_date = findViewById(R.id.btn_date);
        btn_date.setText(String.format("%04d-%02d-%02d",calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH)+1,calendar.get(Calendar.DAY_OF_MONTH)));
        btn_date.setOnClickListener(this);

        btn_time = findViewById(R.id.btn_time);
        btn_time.setOnClickListener(this);
        btn_time.setText(String.format("%02d:%02d",calendar.get(Calendar.HOUR_OF_DAY),calendar.get(Calendar.MINUTE)));

        et_score = findViewById(R.id.et_score);

        btn_ok = findViewById(R.id.btn_ok);
        btn_ok.setOnClickListener(this);
        btn_cancel = findViewById(R.id.btn_cancel);
        btn_cancel.setOnClickListener(this);
    }






    public void setClickListener(ClickListener clickListener) {
        this.clickListener = clickListener;
    }

    @Override
    public void onClick(View v) {
        if(v == btn_date){
            int year = Integer.parseInt(btn_date.getText().toString().substring(0,4));
            int month = Integer.parseInt(btn_date.getText().toString().substring(5,7))-1;
            int day = Integer.parseInt(btn_date.getText().toString().substring(8,10));
            DatePickerDialog datePickerDialog = new DatePickerDialog(mContext, new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                    btn_date.setText(String.format("%04d-%02d-%02d",year,month+1,dayOfMonth));
                }
            },year,month,day);
            datePickerDialog.show();
        }else if(v== btn_time){
            int hour = Integer.parseInt(btn_time.getText().toString().substring(0,2));
            int min = Integer.parseInt(btn_time.getText().toString().substring(3,5));
            TimePickerDialog timePickerDialog = new TimePickerDialog(mContext, new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                    btn_time.setText(String.format("%02d:%02d",hourOfDay,minute));
                }
            },hour,min,true);
            timePickerDialog.show();
        }else if(v == btn_ok){
            //점수 비어있는지 체크 하고 입력
            if(et_score.getText().toString().trim().equals("")) {
                Toast.makeText(mContext, "점수를 입력 후 확인을 눌러주세요.", Toast.LENGTH_SHORT).show();
                return;
            }
            ScoreDBAdapter scoreDBAdapter = new ScoreDBAdapter(mContext);
            scoreDBAdapter.open();
            ;
            scoreDBAdapter.createEntry(et_score.getText().toString(), btn_date.getText().toString(), btn_time.getText().toString());
            scoreDBAdapter.close();
            clickListener.setOnClick();
            dismiss();

        }else if(v == btn_cancel){
            dismiss();
        }
    }

    public interface ClickListener {
        void setOnClick();
    }


}
