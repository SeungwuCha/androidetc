package com.example.tmap0915.dialog;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.tmap0915.R;
import com.example.tmap0915.ReportActivity;
import com.example.tmap0915.db.ScoreDBAdapter;
import com.example.tmap0915.item.ReportItem;

import java.util.Calendar;


public class ReportListDialog extends Dialog implements View.OnClickListener {

    private Context mContext;


    private Button btn_modify,btn_delete;



    private ClickListener clickListener = null;

    public ReportItem item;

    public ReportListDialog(Context context, ReportItem item) {
        super(context);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setBackgroundDrawable((new ColorDrawable(Color.TRANSPARENT)));
        setContentView(R.layout.popup_report_list);

        getWindow().setGravity(Gravity.BOTTOM);

        mContext = context;
        this.item = item;

        initRes();
    }

    private void initRes() {
        btn_modify = findViewById(R.id.btn_modify);
        btn_modify.setOnClickListener(this);
        btn_delete = findViewById(R.id.btn_delete);
        btn_delete.setOnClickListener(this);
    }






    public void setClickListener(ClickListener clickListener) {
        this.clickListener = clickListener;
    }

    @Override
    public void onClick(View v) {
        if(v == btn_modify){
            Intent intent = new Intent(mContext, ReportActivity.class);

            intent.putExtra("idx",item.getIdx());
            intent.putExtra("title",item.getTitle());
            intent.putExtra("content",item.getContent());
            intent.putExtra("import",item.getImportData());
            mContext.startActivity(intent);
            dismiss();
        }else if(v == btn_delete){
            clickListener.setOnClick();
        }
    }

    public interface ClickListener {
        void setOnClick();
    }


}
