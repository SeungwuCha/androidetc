package com.example.tmap0915;


import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.skt.Tmap.TMapData;
import com.skt.Tmap.TMapGpsManager;
import com.skt.Tmap.TMapMarkerItem;
import com.skt.Tmap.TMapPOIItem;
import com.skt.Tmap.TMapPoint;
import com.skt.Tmap.TMapView;

import java.util.ArrayList;
import java.util.Map;

import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.skt.Tmap.TMapGpsManager;

public class MapView extends AppCompatActivity implements
        TMapGpsManager.onLocationChangedCallback, View.OnClickListener{


    private Context mContext = null;
    private boolean m_bTrackingMode = true;

    private TMapData tmapdata = null;
    private TMapGpsManager tmapgps = null;
    private TMapView tmapview = null;
    private static String mApiKey = "03897778-9adc-441a-a4ea-3b4117f35cd3"; // 발급받은 appKey
    private static int mMarkerID;

    private ArrayList<TMapPoint> m_tmapPoint = new ArrayList<TMapPoint>();
    private ArrayList<String> mArrayMarkerID = new ArrayList<String>();
    private ArrayList<MapPoint> m_mapPoint = new ArrayList<MapPoint>();

    private String bowling;
    private String address;
    private Double lat = null;
    private Double lon = null;

    // TMapView 클래스에 있는 애들을 데려와보려고 했으나 TMapView에서 먼저 호출이 되버리나보다?
    private double latitude1 = 37.338152;
    private double longitude1 = 126.800986;
    private double locationlatitude1 = 37.338152;
    private double locationLongitude1 = 126.800986;
    private Button bt_find;
    private Button bt_fac;


    // 현재위치로 표시될 좌표의 위도 경도 설정
    @Override
    public void onLocationChange(Location location) {
        if (m_bTrackingMode) {
            tmapview.setLocationPoint(location.getLongitude(), location.getLatitude());

        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_map);


        /* 현재위치로 표시되는 좌표의 위도, 경도를 반환 넣었더니 튕겨버림
        TMapView tMapView = new TMapView(this);
        tmapview.setLocationPoint(126.985022, 37.566474);
*/
        mContext = this;

        //버튼 선언
        bt_find = (Button) findViewById(R.id.bt_findadd);
        bt_fac = (Button) findViewById(R.id.bt_findfac);

        //Tmap 각종 객체 선언
        tmapdata = new TMapData(); //POI검색, 경로검색 등의 지도데이터를 관리하는 클래스
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.mapview);
        tmapview = new TMapView(this);

        linearLayout.addView(tmapview);
        tmapview.setSKTMapApiKey(mApiKey);

        // addPoint();
        //showMarkerPoint();

        /* 현위치 아이콘표시 */
        tmapview.setIconVisibility(true);

        // 줌레벨
        tmapview.setZoomLevel(15);

        /* 지도 타입 */
        tmapview.setMapType(TMapView.MAPTYPE_STANDARD);

        /* 언어 설정 */
        tmapview.setLanguage(TMapView.LANGUAGE_KOREAN);


        tmapgps = new TMapGpsManager(MapView.this); //단말의 위치탐색을 위한 클래스
        tmapgps.setMinTime(1000); //위치변경 인식 최소시간설정
        tmapgps.setMinDistance(5); //위치변경 인식 최소거리설정
        tmapgps.setProvider(tmapgps.NETWORK_PROVIDER); //네트워크 기반의 위치탐색
        //tmapgps.setProvider(tmapgps.GPS_PROVIDER); //위성기반의 위치탐색
        tmapgps.OpenGps();

        /*  화면중심을 단말의 현재위치로 이동 */
        tmapview.setTrackingMode(true);
        tmapview.setSightVisible(true);


        tmapview.setOnCalloutRightButtonClickListener(new TMapView.OnCalloutRightButtonClickCallback() {
            @Override
            public void onCalloutRightButton(TMapMarkerItem markerItem) {

                lat = markerItem.latitude;
                lon = markerItem.longitude;

                //1. 위도, 경도로 주소 검색하기
                tmapdata.convertGpsToAddress(37.336670, 126.812251, new TMapData.ConvertGPSToAddressListenerCallback() {
                    @Override
                    public void onConvertToGPSToAddress(String strAddress) {

                    }
                });

                Toast.makeText(MapView.this, "주소 : " + address, Toast.LENGTH_SHORT).show();


            }
        });

        //버튼 리스너 등록
        bt_find.setOnClickListener(this);
        bt_fac.setOnClickListener(this);

        findViewById(R.id.layout_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
 /*   //핀 찍을 data
    public void addPoint() {
        // 강남쪽에 찍음
       // m_mapPoint.add(new MapPoint("볼링", 37.510350, 127.066847));
    }*/

    @Override
    public void onClick(View view) {
        switch (view.getId()) {

            case R.id.bt_findfac:
                getAroundBizPoi();
                break;
        }
    }


/*
    // 주소로 찾기 버튼을 눌러서 볼링장을 검색하니 내 현재위치로 따라오지 않고 서울의 볼링장을 간다..
    // 내 위치에 검색이 되게 한 후에 터치 한번으로 실행되게 해보 흠..
    // 1, 현재 위치로 따라오게 한다
    // 2. 검색어 앞에 내 지역 (선부동) 이 붙게 한다
    // ! 치킨집은 가능한데 볼링장으로 치니 튕겨버린다!
    public void convertToAddress() {
        //다이얼로그 (네모창) 띄워서, 검색창에 입력받음
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("주변 검색");

        final EditText input = new EditText(this);
        builder.setView(input);

        builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                final String strData = input.getText().toString();
                TMapData tmapdata = new TMapData();
                TMapPoint point = tmapview.getCenterPoint();

///
                tmapdata.findAllPOI(strData, new TMapData.FindAllPOIListenerCallback() {
                    @Override
                    public void onFindAllPOI(ArrayList<TMapPOIItem> poiItem) {

                        for (int i = 0; i < 8; i++) {
                            TMapPOIItem item = poiItem.get(i);

                            TMapPoint tpoint = item.getPOIPoint();
                            double Latitude = tpoint.getLatitude();
                            double Longitude = tpoint.getLongitude();

                            TMapPoint mpoint = new TMapPoint(Latitude, Longitude);
                            TMapMarkerItem tItem = new TMapMarkerItem();
                            tItem.setTMapPoint(mpoint);
                            tItem.setName(item.getPOIName().toString());
                            Bitmap bitmap = null;
                            bitmap = BitmapFactory.decodeResource(mContext.getResources(), R.mipmap.ic_launcher_round);
                            tItem.setVisible(TMapMarkerItem.VISIBLE);
                            tItem.setIcon(bitmap);

                            String strID = String.format("pmarker%d", mMarkerID++);
                            tmapview.addMarkerItem(strID, tItem);

                            tItem.setCalloutTitle(item.getPOIName().toString());
                            tItem.setCanShowCallout(true);
                            tItem.setAutoCalloutVisible(true);

                            Bitmap bitmap_i = BitmapFactory.decodeResource(mContext.getResources(), R.mipmap.ic_launcher_round);

                            tItem.setCalloutRightButtonImage(bitmap_i);

                            Log.d("주소로찾기", "POI Name: " + item.getPOIName().toString() + ", " +
                                    "Address: " + item.getPOIAddress().replace("null", "") + ", " +
                                    "Point: " + item.getPOIPoint().toString());
                        }
                    }
                });
            }
        });
        builder.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });


        builder.show();
    }

*/

    public void getAroundBizPoi() {
        // 해당 주소로 화면 이동 tmapview.setCenterPoint(126.2128205, 37.441135);

        TMapPoint point = tmapview.getCenterPoint();
        // findAroundNamePOI 는 편의시설 (예 : 은행, 주차장, 편의점 같은 것 밖에 안돼는거 같다.. )
        // FindAllPOI를 사용했더니 내 위치 기준이 아닌 서울 초기 위치를 기준으로 검색한다
        // 1.볼링장 앞에 내 현재위치 주소를 가져와 검색을 한다
        // 2.지도의 초기 위치를 바꿔준다 (skd를 손댈수는 없다 read only)
        // 시흥 볼링장 = 실패 시흥 볼링장이라고 치니 중앙동에 있는 시흥볼링 1 / 중앙동볼링 4 떠버림
        String s = "경기과학기술대학교";

        tmapdata.findAroundKeywordPOI(point, "볼링", 1, 5,
                new TMapData.FindAroundKeywordPOIListenerCallback() {
                    @Override
                    public void onFindAroundKeywordPOI(ArrayList<TMapPOIItem> poiItem) {

                        for (int i = 0; i < poiItem.size(); i++) {

                            TMapPOIItem item = poiItem.get(i);
                            // 마커의 위 경도 좌표를 설정합니다.
                            TMapPoint tpoint = item.getPOIPoint();

                            double Latitude = tpoint.getLatitude();
                            double Longitude = tpoint.getLongitude();
                            double lap2= 33;
                            // 마커 찍을 좌표
                            TMapPoint mpoint = new TMapPoint(Latitude, Longitude);

                            TMapMarkerItem tItem = new TMapMarkerItem();
                            tItem.setTMapPoint(mpoint);
                            tItem.setName(item.getPOIName().toString());
                            Bitmap bitmap = null;
                            bitmap = BitmapFactory.decodeResource(mContext.getResources(), R.mipmap.ic_launcher_round);
                            tItem.setVisible(TMapMarkerItem.VISIBLE);
                            tItem.setIcon(bitmap);
                            String strID = String.format("pmarker%d", mMarkerID++);
                            tmapview.addMarkerItem(strID, tItem);
                            tItem.setCalloutTitle(item.getPOIName().toString());
                            tItem.setCanShowCallout(true);
                            tItem.setAutoCalloutVisible(true);

                            Bitmap bitmap_i = BitmapFactory.decodeResource(mContext.getResources(), R.mipmap.ic_launcher_round);

                            tItem.setCalloutRightButtonImage(bitmap_i);
                            Log.d(tmapdata + "볼링", "POI Name: " + item.getPOIName() + "," + "Address: "
                                    + item.getPOIAddress().replace("null", ""));
                        }
                    }
                });
    }
}
//public void getAroundBizPoi() {
//    TMapData tmapdata = new TMapData();
//
//    TMapPoint point = tmapview.getCenterPoint();
//
//    tmapdata.findAroundKeywordPOI(point, "볼링", 1, 5,
//            new TMapData.FindAroundKeywordPOIListenerCallback() {
//                @Override
//                public void onFindAroundKeywordPOI(ArrayList<TMapPOIItem> poiItem) {
//
//
//                    for (int i = 0; i < poiItem.size(); i++) {
//                        TMapPOIItem item = poiItem.get(i);
//                        Log.d("편의시설","POI Name: " + item.getPOIName() + "," + "Address: "
//                                + item.getPOIAddress().replace("null", ""));
//                    }
//                }
//            });
//}
//}