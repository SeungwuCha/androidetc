package com.example.tmap0915;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.tmap0915.db.ReportDBAdapter;

import java.text.SimpleDateFormat;
import java.util.Date;

public class ReportActivity extends AppCompatActivity {
    //제목
    EditText et_title;
    //내용
    EditText et_content;
    //중요성
    RatingBar rb_import;

    //등록하기
    TextView tv_report;

    boolean isCheck = false;

    String idx = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);

        et_title = findViewById(R.id.et_title);

        et_content = findViewById(R.id.et_content);

        rb_import = findViewById(R.id.rb_import);

        tv_report = findViewById(R.id.tv_report);

        tv_report.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                write();
            }
        });
        initData();

        findViewById(R.id.layout_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


    }

    private void initData() {
        if(getIntent().getStringExtra("idx")!=null && !getIntent().getStringExtra("idx").equals("")){
            idx = getIntent().getStringExtra("idx");
            et_title.setText(getIntent().getStringExtra("title"));
            et_content.setText(getIntent().getStringExtra("content"));
            rb_import.setRating(getIntent().getIntExtra("import",0));
            tv_report.setText("수정");
            isCheck =true;
        }

    }

    private void write() {
        String title = et_title.getText().toString();
        String content = et_content.getText().toString();
        String importData = rb_import.getRating()+"";
        String date = new SimpleDateFormat("yyyy-MM-dd").format(new Date());

        if(title.trim().equals("")){
            Toast.makeText(this, "제목이 비어있습니다.", Toast.LENGTH_SHORT).show();
            return;
        }
        if(content.trim().equals("")){
            Toast.makeText(this, "내용이 비어있습니다.", Toast.LENGTH_SHORT).show();
            return;
        }
        ReportDBAdapter reportDBAdapter = new ReportDBAdapter(this);
        reportDBAdapter.open();
        if(isCheck) {
            reportDBAdapter.updateEntry(idx,title, date, importData, content);
        }else{
            reportDBAdapter.createEntry(title, date, importData, content);
        }
        reportDBAdapter.close();
        Toast.makeText(this, "등록되었습니다..", Toast.LENGTH_SHORT).show();
        finish();
    }
}
