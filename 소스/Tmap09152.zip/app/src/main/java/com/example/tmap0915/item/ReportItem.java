package com.example.tmap0915.item;

public class ReportItem {
    String idx;
    String title;
    String content;
    int importData;
    String date;

    public ReportItem(String idx, String title, String content, int importData, String date) {
        this.idx = idx;
        this.title = title;
        this.content = content;
        this.importData = importData;
        this.date = date;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getImportData() {
        return importData;
    }

    public void setImportData(int importData) {
        this.importData = importData;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getIdx() {
        return idx;
    }

    public void setIdx(String idx) {
        this.idx = idx;
    }
}


