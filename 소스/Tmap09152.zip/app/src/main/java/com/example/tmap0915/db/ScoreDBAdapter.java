package com.example.tmap0915.db;



import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;
import android.util.Log;

public class ScoreDBAdapter {


	private static final String DATABASE_NAME = "score.db";
	private static final String DATABASE_TABLE = "tb_score";

	public static final int DATABASE_VERSION = 1;
	private static final String DATABASE_CREATE = "create table "
			+ DATABASE_TABLE + " (" + ScoreEntry.Score_IDX
			+ " INTEGER primary key, " +  ScoreEntry.Score_score
			+ " INTEGER not null, " + ScoreEntry.Score_date
			+ " TEXT not null, " + ScoreEntry.Score_time
			+ " TEXT not null);";
	private static final String TAG = "BoothDBAdapter";

	public String[] COLUMNS = new String[] {ScoreEntry.Score_IDX,
			ScoreEntry.Score_score,ScoreEntry.Score_date,ScoreEntry.Score_time
			};
	public String[] COLUMNSDate = new String[] {
			ScoreEntry.Score_date,"AVG(s_score)","count(*)"
	};

	private String[] CountCOLUMNS = new String[] {"count(idx)"
			};
	private Context mContext;
	private DCTDatabaseHelper mDbHelper;
	private SQLiteDatabase mDb;

	public ScoreDBAdapter(Context context) {
		mContext = context;
	}

	public ScoreDBAdapter open() throws SQLException {
		mDbHelper = new DCTDatabaseHelper(mContext);
		mDb = mDbHelper.getWritableDatabase();
		return this;
	}

	public void close() {
		if(mDbHelper!=null)
			mDbHelper.close();
	}
	
	
	public long createEntry(String strScore, String strDate,String strTime) {
		ContentValues initialValues = new ContentValues();


		initialValues.put(ScoreEntry.Score_score, strScore);
		initialValues.put(ScoreEntry.Score_date, strDate);
		initialValues.put(ScoreEntry.Score_time, strTime);
		
		
		return mDb.insert(DATABASE_TABLE, null, initialValues);
	}
	


	

	public Cursor selectIDXEntry(int nIdx) {
		//
		Cursor qu = mDb.query(DATABASE_TABLE, COLUMNS,
				ScoreEntry.Score_IDX+" = "+nIdx,
				null, null, null, null);
		
		return qu;
		
	}
	public Cursor fetchAllEntry() {
		return mDb.query(DATABASE_TABLE, COLUMNS, null, null, null, null, null);
	}

	
	public Cursor fetchAllEntryDate() {
		return mDb.query(DATABASE_TABLE, COLUMNSDate, null, null, ScoreEntry.Score_date, null, null);
	}
	public Cursor fetchAllEntryDate2(String ym) {
		return mDb.query(DATABASE_TABLE, COLUMNS, ScoreEntry.Score_date+" like '"+ym+"%'", null, null, null, null);
	}

	
	
	public int fetchAllEntryLength() {
		return mDb.query(DATABASE_TABLE, COLUMNS, null, null, null, null, null).getCount();
	}
	
	public void delIDXEntry(int nIdx) {
		mDb.delete(DATABASE_TABLE, ScoreEntry.Score_IDX+"= "+nIdx, null);
	}

	private class DCTDatabaseHelper extends SQLiteOpenHelper {

		public DCTDatabaseHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			db.execSQL(DATABASE_CREATE);
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
					+ newVersion + ", which will destory all old data");
			db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
			onCreate(db);
		}

	}

	
	public class ScoreEntry implements BaseColumns {
		public static final String Score_IDX = "s_idx";
		public static final String Score_score = "s_score";
		public static final String Score_date = "s_date";
		public static final String Score_time = "s_time";
	}
	
}
