package com.example.tmap0915.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.tmap0915.R;
import com.example.tmap0915.db.ReportDBAdapter;
import com.example.tmap0915.dialog.ReportListDialog;
import com.example.tmap0915.item.ReportItem;


import java.util.ArrayList;


public class ReportAdapter extends RecyclerView.Adapter<ReportAdapter.MyViewHolder> implements View.OnClickListener {

    public ArrayList<ReportItem> outDataList;
    Context context;

    public ReportAdapter(Context context, ArrayList<ReportItem> outDataList) {
        this.context = context;
        this.outDataList = outDataList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_report,null);
        MyViewHolder viewHolder = new MyViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {


        holder.tv_title.setText(outDataList.get(position).getTitle());
        holder.tv_content.setText(outDataList.get(position).getContent());
        holder.tv_date.setText(outDataList.get(position).getDate());
        holder.rb_import.setRating(outDataList.get(position).getImportData());
        holder.btn_setting.setTag(position);
        holder.btn_setting.setOnClickListener(this);
        /*holder.tv.setTag(position);
        holder.nameTextView.setOnClickListener(this);*/

    }
    @Override
    public void onClick(View view) {
        //아이템 클릭시 세부정보 확인
        int position  = (int) view.getTag();
        ReportListDialog reportListDialog = new ReportListDialog(context,outDataList.get(position));
        reportListDialog.setClickListener(new ReportListDialog.ClickListener() {
            @Override
            public void setOnClick() {
                //삭제작업
                ReportDBAdapter reportDBAdapter = new ReportDBAdapter(context);
                reportDBAdapter.open();
                reportDBAdapter.delIDXEntry(outDataList.get(position).getIdx());
                reportDBAdapter.close();
                outDataList.remove(position);
                notifyDataSetChanged();
                reportListDialog.dismiss();
            }
        });

        reportListDialog.show();
        /*Intent intent = new Intent(context,SubActivity.class);
        intent.putExtra("name",list.get(position).getName());
        intent.putExtra("vendor",list.get(position).getVendor());
        intent.putExtra("etc",list.get(position).toString());
        context.startActivity(intent);*/
    }


    @Override
    public int getItemCount() {
        return outDataList.size();
    }

    public void setList(ArrayList<ReportItem> list) {
        this.outDataList = list;
    }



    public static class MyViewHolder extends RecyclerView.ViewHolder{

        public TextView tv_title,tv_content,tv_date;
        public RatingBar rb_import;
        public Button btn_setting;
        public LinearLayout myLayout;

        Context context;

        public MyViewHolder(View itemView) {
            super(itemView);
            myLayout = (LinearLayout) itemView;

            tv_title = (TextView) itemView.findViewById(R.id.tv_title);
            tv_content = (TextView) itemView.findViewById(R.id.tv_content);
            tv_date = (TextView) itemView.findViewById(R.id.tv_date);
            rb_import  = (RatingBar)itemView.findViewById(R.id.rb_import);
            btn_setting = (Button) itemView.findViewById(R.id.btn_setting);

            context = itemView.getContext();

        }


    }
}