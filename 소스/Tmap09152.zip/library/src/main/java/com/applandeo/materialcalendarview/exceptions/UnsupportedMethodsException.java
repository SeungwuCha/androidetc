package com.applandeo.materialcalendarview.exceptions;

/**
 * Created by Mateusz Kornakiewicz on 09.08.2018.
 */

public class UnsupportedMethodsException extends RuntimeException {
    public UnsupportedMethodsException(String message) {
        super(message);
    }
}
