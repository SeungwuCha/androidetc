package com.web.weblogin;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.web.weblogin.web.SendHttp;

import org.json.JSONObject;

import java.util.HashMap;


public class LoginActivity extends AppCompatActivity  {

    EditText et_id,et_pw;
    Button btn_login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        et_id = (EditText)findViewById(R.id.et_id);
        et_pw = (EditText)findViewById(R.id.et_pw);

        btn_login = (Button)findViewById(R.id.btn_login);
        btn_login.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                setLogin();
            }
        });

    }

    private void setLogin() {
        HashMap<String,String> mParm = new HashMap<>();
        mParm.put("id",et_id.getText().toString());
        mParm.put("pw",et_pw.getText().toString());
        WebTask task = new WebTask();
        task.SetParam(mParm);
        task.execute();
    }


    private class WebTask extends AsyncTask<String, Void, String> {

        HashMap<String, String> mParm = null;





        public void SetParam(HashMap<String, String> parm) {
            mParm = parm;

        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();


        }


        @Override
        protected String doInBackground(String... params) {
            String strRtn = null;



            SendHttp sendhttp = new SendHttp();
            String strUrl = "http://chasw12.dothome.co.kr/join.php";
            System.out.println("strUrl" + strUrl);
            strRtn = sendhttp.postHttpClientToString(strUrl, mParm);

            return strRtn;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            System.out.println("result"+result);
            try {
                JSONObject object = new JSONObject(result);
                int value =  object.getInt("value");
                Log.e("value","abc"+value);
                if(value == 1){
                    Toast.makeText(LoginActivity.this, "로그인 성공", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(LoginActivity.this, "로그인 실패", Toast.LENGTH_SHORT).show();
                }

            } catch (Exception e) {
                e.printStackTrace();
            }


        }
    }

}

