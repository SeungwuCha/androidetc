package com.web.weblogin.web;

import android.util.Log;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;


public class SendHttp {
	private final String TAG = "SendHttp";

	public final int URL_POST_TIME_OUT = 10000;

	private UrlEncodedFormEntity entityRequest;

	/**
	 * POST 방식으로 URL 전송
	 *
	 * @param strUrl
	 * @param strParam
	 * @return
	 */
	public String postHttp(String strUrl, String strParam) {
		String strRetrun = "";

		try {

			Log.d(TAG, strUrl + "?" + strParam);

			URL url = new URL(strUrl);
			HttpURLConnection httpURLCon = (HttpURLConnection) url.openConnection();

			httpURLCon.setDefaultUseCaches(false);
			httpURLCon.setDoInput(true);
			httpURLCon.setDoOutput(true);
			// httpURLCon.addRequestProperty("Connection", "close");
			httpURLCon.setRequestMethod("POST");
			httpURLCon.setRequestProperty("content-type", "application/x-www-form-urlencoded");
			httpURLCon.setConnectTimeout(URL_POST_TIME_OUT);
			httpURLCon.setReadTimeout(URL_POST_TIME_OUT);

			PrintWriter pw = new PrintWriter(new OutputStreamWriter(httpURLCon.getOutputStream(), "UTF-8"));
			pw.write(strParam);
			pw.flush();
			// Log.d("", String.format("[%s]", sb.toString()));

			BufferedReader bf = new BufferedReader(new InputStreamReader(httpURLCon.getInputStream(), "UTF-8"));
			StringBuilder buff = new StringBuilder();
			String line;

			while ((line = bf.readLine()) != null) {
				buff.append(line);
			}
			// Log.d("", buff.toString());

			strRetrun = buff.toString();

			Log.d("", strRetrun);

		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return strRetrun;
	}

	/**
	 * POST 방식으로 URL 전송 ( 파일 첨부 전송 )
	 *
	 * @param strUrl
	 * @param strParam
	 * @param strFilePath
	 * @return
	 */
	public String postHttpAddFile(String strUrl, String strParam, String strFilePath) {
		String strRetrun = "";

		try {

			Log.d(TAG, strUrl + "?" + strParam);

			URL url = new URL(strUrl);
			HttpURLConnection httpURLCon = (HttpURLConnection) url.openConnection();

			httpURLCon.setDefaultUseCaches(false);
			httpURLCon.setDoInput(true);
			httpURLCon.setDoOutput(true);
			// httpURLCon.addRequestProperty("Connection", "close");
			httpURLCon.setRequestMethod("POST");
			// httpURLCon.setRequestProperty("content-type",
			// "application/x-www-form-urlencoded");
			// httpURLCon.setRequestProperty("User-Agent",
			// "SmartDrive Android Client MultiID");
			httpURLCon.setConnectTimeout(URL_POST_TIME_OUT);
			httpURLCon.setReadTimeout(URL_POST_TIME_OUT);

			BufferedOutputStream bos = new BufferedOutputStream(httpURLCon.getOutputStream());

			try {
				byte[] byParam = strParam.getBytes();
				bos.write(byParam, 0, byParam.length);

				Log.d(TAG, "write : " + byParam.length);

				if (strFilePath.length() > 0) {
					int iReadBytes = 0;
					byte[] szBuffer = new byte[102400];
					FileInputStream fis = new FileInputStream(new File(strFilePath));

					do {
						iReadBytes = fis.read(szBuffer);
						if (iReadBytes <= 0)
							break;
						// bos.write(szBuffer, 0, iReadBytes);

						Log.d(TAG, "read : " + iReadBytes);

						bos.write(szBuffer, 0, iReadBytes);

						Log.d(TAG, "write : " + iReadBytes);
					} while (iReadBytes > 0);

					fis.close();
				}

				bos.flush();
				bos.close();
			} catch (Exception e) {
				e.printStackTrace();
			}

			// 응답 받기
			BufferedReader bf = new BufferedReader(new InputStreamReader(httpURLCon.getInputStream(), "UTF-8"));
			StringBuilder buff = new StringBuilder();
			String line;

			while ((line = bf.readLine()) != null) {
				buff.append(line);
			}
			// Log.d("", buff.toString());

			strRetrun = buff.toString();

			Log.d("", strRetrun);

		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return strRetrun;
	}



	public String postHttpClientToString(String strUrl, HashMap<String, String> aryParam) {
		String strRetrun = "";

		try {

			Log.d(TAG, strUrl);

			// HttpParams params = new BasicHttpParams();
			// HttpProtocolParams.setVersion(params, HttpVersion.HTTP_1_1);
			// HttpProtocolParams.setContentCharset(params, "utf-8");
			// HttpClient client = new DefaultHttpClient(params);

			HttpClient client = new DefaultHttpClient();
			// client.getParams().setParameter("http.protocol.content-charset", "UTF-8");

			HttpPost post = new HttpPost(strUrl);
			ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			strUrl += "?";
			for (Entry<String, String> entry : aryParam.entrySet()) {
				//Log.d(TAG, "param : name = " + entry.getKey() + ", val = " + entry.getValue());
				nameValuePairs.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
				strUrl += entry.getKey() + "=" + entry.getValue() + "&";
			}
			// System.out.println("strUrl" + strUrl);
			// MultipartEntity multipart = new MultipartEntity(HttpMultipartMode.BROWSER_COMPATIBLE, null, Charset.forName("UTF-8"));
			Log.d(TAG, strUrl);

			entityRequest = new UrlEncodedFormEntity(nameValuePairs, "UTF-8");
			post.setEntity(entityRequest);


			// 실행 후 응답 받기
			client.getParams().setParameter("http.connection.timeout", URL_POST_TIME_OUT);
			client.getParams().setParameter("http.socket.timeout", URL_POST_TIME_OUT);
			HttpResponse response = client.execute(post);

			// 응답 받은 데이터 String으로 반환
			HttpEntity resEntity = response.getEntity();
			strRetrun = EntityUtils.toString(resEntity, "UTF-8");

			// 응답 받기
			Log.d(TAG, strRetrun);

		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return strRetrun;
	}



	public String getHeaderToString(HttpResponse response, String strName, String strDefault) {
		String strRtn = strDefault;

		Header header = response.getFirstHeader(strName);

		if (header != null) {
			strRtn = header.getValue();
		}

		return strRtn;
	}

	public boolean getHeaderToBoolean(HttpResponse response, String strName, boolean bDefault) {
		boolean bRtn = bDefault;
		String str = getHeaderToString(response, strName, "");
		if (str.equalsIgnoreCase("true"))
			bRtn = true;
		else if (str.equalsIgnoreCase("false"))
			bRtn = false;
		return bRtn;
	}

}
