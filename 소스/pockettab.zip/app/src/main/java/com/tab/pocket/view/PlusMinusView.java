package com.tab.pocket.view;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.tab.pocket.R;


public class PlusMinusView extends LinearLayout implements View.OnClickListener, View.OnLongClickListener {

    Handler mHandler = new Handler() {
        public void handleMessage(Message msg) {
            if(msg.what ==0 ) {
                //Log.e("removeMax",removeMax+" ");
                if(value<2020-removeMax) {
                    value++;  // Value +
                }
                setValue(value);

                mHandler.sendEmptyMessageDelayed(0, 100);
            }else if(msg.what == 1){
                if(value>1) {
                    value--;  //Value -
                }
                setValue(value);

                mHandler.sendEmptyMessageDelayed(1, 100);
            }
        }
    };
    LinearLayout bg;
    TextView tv_value;
    Button btn_plus,btn_minus;
    int value = 5;
    String unit = "sec";

//    BlackViewListener blackViewListener;
    DataListener mDataListener;
    //max value
    int removeMax = 0;



    public PlusMinusView(Context context) {
        super(context);
        initView();
    }

    public PlusMinusView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initView();
    }

    public PlusMinusView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs);
        initView();
    }

    public void setRemoveMaxData(int removeMax){
        //Log.e("setremovemaxData",removeMax+" ");
        this.removeMax = removeMax;
    }



    public void setDataListener(DataListener mDataListener) {
        this.mDataListener = mDataListener;
    }

    private void initView() {
        String infService = Context.LAYOUT_INFLATER_SERVICE;
        LayoutInflater li = (LayoutInflater) getContext().getSystemService(infService);
        View v = li.inflate(R.layout.view_plus_minus, this, false);

        tv_value = (TextView)v.findViewById(R.id.tv_value);
        btn_plus = (Button) v.findViewById(R.id.btn_plus);
        btn_plus.setOnLongClickListener(this);

        btn_plus.setOnClickListener(this);
        btn_minus = (Button) v.findViewById(R.id.btn_minus);
        btn_minus.setOnClickListener(this);
        btn_minus.setOnLongClickListener(this);
        setValue(value);
        addView(v);
    }

    public void setUnit(String unit){
        this.unit = unit;
    }

    public void setValue(int value){
        this.value = value;
        if(mDataListener!=null){
            mDataListener.dataChange(value);
        }
        if(unit.equals("")) {
            tv_value.setText(String.valueOf(value) );
        }else{
            tv_value.setText(String.valueOf(value) + unit);
        }
    }

    public int getValue() {
        return value;
    }

    @Override
    public void onClick(View v) {

//        blackViewListener.delayBlackViewShow();

        if(v == btn_plus){
            if(value<2020-removeMax) {
                value++;
            }
            setValue(value);
            mHandler.removeMessages(0);
        }else{
            if(value>1) {
                value--;
            }
            setValue(value);
            mHandler.removeMessages(1);
        }
    }


    @Override
    public boolean onLongClick(View v) {

//        blackViewListener.delayBlackViewShow();

        if(v ==btn_plus){
            mHandler.sendEmptyMessageDelayed(0,100);
        }else if(v == btn_minus){
            mHandler.sendEmptyMessageDelayed(1,100);
        }
        return false;
    }

    @Override
    public void setEnabled(boolean enabled) {
        super.setEnabled(enabled);
        btn_plus.setEnabled(enabled);
        btn_minus.setEnabled(enabled);
    }



    public interface DataListener{
        public abstract void dataChange(int value);
    }
}

