
package com.tab.pocket.chart;

import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.formatter.IValueFormatter;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.utils.ViewPortHandler;

import java.text.DecimalFormat;

/**
 * This IValueFormatter is just for convenience and simply puts a "%" sign after
 * each value. (Recommeded for PieChart)
 *
 * @author Philipp Jahoda
 */
public class PieFormatter extends ValueFormatter
{

    protected DecimalFormat mFormat;

    public PieFormatter() {
        mFormat = new DecimalFormat("###,###,##0");
    }

    /**
     * Allow a custom decimalformat
     *
     * @param format
     */
    public PieFormatter(DecimalFormat format) {
        this.mFormat = format;
    }


    @Override
    public String getFormattedValue(float value) {
        return mFormat.format(value) ;
    }

}
