package com.tab.pocket.item;

public class GroupMoneyitem {

    int money;
    String type;

    public GroupMoneyitem(String type, int money) {
        this.money = money;
        this.type = type;
    }


    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
