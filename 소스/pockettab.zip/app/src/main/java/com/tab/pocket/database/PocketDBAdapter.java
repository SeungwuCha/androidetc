package com.tab.pocket.database;



import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;
import android.util.Log;

public class PocketDBAdapter {


	private static final String DATABASE_NAME = "pocket.db";
	private static final String DATABASE_TABLE = "tb_pocket";

	public static final int DATABASE_VERSION = 2;


	private static final String DATABASE_CREATE = "create table "
			+ DATABASE_TABLE + " (" + PocketEntry.Pocket_IDX
			+ " INTEGER primary key, " +   PocketEntry.Pocket_date
			+ " TEXT not null, " + PocketEntry.Pocket_time		
			+ " TEXT not null, " + PocketEntry.Pocket_kind
			+ " TEXT not null, " + PocketEntry.Pocket_money
			+ " TEXT not null);";
	private static final String TAG = "PocketDBAdapter";

	public String[] COLUMNS = new String[] {PocketEntry.Pocket_IDX
			, PocketEntry.Pocket_date, PocketEntry.Pocket_time, PocketEntry.Pocket_kind, PocketEntry.Pocket_money
			};
	public String[] COLUMNSSUM = new String[] {"sum(s_money)", PocketEntry.Pocket_kind
	};
	public String[] COLUMNSMAX = new String[] {"count(*)", PocketEntry.Pocket_kind
	};

	private Context mContext;
	private PocketDatabaseHelper mDbHelper;
	private SQLiteDatabase mDb;
	//데이터베이스 초기화
	public PocketDBAdapter(Context context) {
		mContext = context;
	}
	//데이터 베이스 초기화 열기
	public PocketDBAdapter open() throws SQLException {
		mDbHelper = new PocketDatabaseHelper(mContext);
		mDb = mDbHelper.getWritableDatabase();
		return this;
	}

	public void close() {
		if(mDbHelper!=null)
			mDbHelper.close();
	}

	//데이터 추가
	public long createEntry(String date,String time,String kind,String money) {
		ContentValues initialValues = new ContentValues();



		initialValues.put(PocketEntry.Pocket_date, date);
		initialValues.put(PocketEntry.Pocket_time, time);

		initialValues.put(PocketEntry.Pocket_kind, kind);
		initialValues.put(PocketEntry.Pocket_money, money);
		
		return mDb.insert(DATABASE_TABLE, null, initialValues);
	}
	//select * from tb_Pocket GROUP by s_time1,s_date1;


	

	public Cursor selectIDXEntry(int nIdx) {
		//
		Cursor qu = mDb.query(DATABASE_TABLE, COLUMNS,
				PocketEntry.Pocket_IDX+" = "+nIdx,
				null, null, null, null);
		
		return qu;
		
	}
	//데이터 가져오기 메인화면
	public Cursor fetchAllEntry() {
		return mDb.query(DATABASE_TABLE, COLUMNS, null, null, null, null, "s_idx desc");

	}
	//데이터 가져오기 날짜 별
	public Cursor fetchAllEntryForDay(String Date,String kind) {
		return mDb.query(DATABASE_TABLE, COLUMNSSUM, "s_date='"+Date+"' and s_kind='"+kind+"'", null, "s_kind", null, null);

	}
	//데이터 가져오기 연도 별
    public Cursor fetchAllEntryMonth(String date1,String date2,String s_kind) {
        Log.e("date1",date1);
        return mDb.query(DATABASE_TABLE, COLUMNSSUM, "s_date>='"+date1+"' and s_date<='"+date2+"' and s_kind='"+s_kind+"'" , null, "s_kind", null, null);

    }






	private class PocketDatabaseHelper extends SQLiteOpenHelper {

		public PocketDatabaseHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}
		//데이터 베이스 처음 열경우 생성
		@Override
		public void onCreate(SQLiteDatabase db) {
			db.execSQL(DATABASE_CREATE);
		}
		//버전이 업된경우 데이터 지우고 생성
		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
					+ newVersion + ", which will destory all old data");
			db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
			onCreate(db);
		}

	}

	
	public class PocketEntry implements BaseColumns {
		//인덱스
		public static final String Pocket_IDX = "s_idx";
		//날짜
		public static final String Pocket_date = "s_date";
		//시간
		public static final String Pocket_time = "s_time";
		//종류
		public static final String Pocket_kind = "s_kind";
		//금액
		public static final String Pocket_money = "s_money";
	}
	
}
