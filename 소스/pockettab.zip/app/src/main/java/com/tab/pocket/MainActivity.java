package com.tab.pocket;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.tab.pocket.adapter.MoneyAdapter;
import com.tab.pocket.database.PocketDBAdapter;
import com.tab.pocket.dialog.InfoDialog;
import com.tab.pocket.item.Moneyitem;
import com.tab.pocket.view.SelectableBottomNavigationView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private SelectableBottomNavigationView bottomNavigationView;

    private Button btn_expense,btn_income,btn_budget;

    private EditText et_money;
    ArrayList<Moneyitem> moneyitems = new ArrayList<>();

    RecyclerView recycler;
    MoneyAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bottomNavigationView = (SelectableBottomNavigationView) findViewById(R.id.navigation);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                if(menuItem.getItemId() == R.id.navigation_home){

                }else if(menuItem.getItemId()==R.id.navigation_year){
                    Intent intent = new Intent(MainActivity.this,YearActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);

                }else if(menuItem.getItemId()==R.id.navigation_day){
                    Intent intent = new Intent(MainActivity.this,DayActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                }else if(menuItem.getItemId()==R.id.navigation_camera){
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivity(intent);

                }else if(menuItem.getItemId()==R.id.navigation_info){
                    InfoDialog infoDialog = new InfoDialog(MainActivity.this);
                    infoDialog.setClickListener(new InfoDialog.ClickListener() {
                        @Override
                        public void setOnClick() {
                            finish();
                        }
                    });
                    infoDialog.show();
                }
                return false;
            }
        });

        btn_expense = findViewById(R.id.btn_expense);
        btn_income = findViewById(R.id.btn_income);
        btn_budget = findViewById(R.id.btn_budget);

        btn_expense.setOnClickListener(this);
        btn_income.setOnClickListener(this);
        btn_budget.setOnClickListener(this);

        et_money = findViewById(R.id.et_money);

        recycler =  findViewById(R.id.recycler);
        adapter = new MoneyAdapter(this,moneyitems);
        recycler.setAdapter(adapter);
        getListData();
        bottomNavigationView.getMenu().findItem(R.id.navigation_home).setChecked(true);
    }

    @Override
    public void onClick(View view) {
        if(view == btn_expense){
            saveData("Expense");
        }else if(view == btn_income){
            saveData("Income");
        }else if(view ==  btn_budget){
            saveData("Budget");
        }
    }

    private void saveData(String type) {
        PocketDBAdapter pocketDBAdapter = new PocketDBAdapter(this);
        pocketDBAdapter.open();
        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat sdf2 = new SimpleDateFormat("hh:mm:ss");
        if(!et_money.getText().toString().trim().equals("")) {
            pocketDBAdapter.createEntry(sdf1.format(new Date()), sdf2.format(new Date()), type , et_money.getText().toString());
        }else{
            Toast.makeText(this, "Enter Amount.", Toast.LENGTH_SHORT).show();
        }
        pocketDBAdapter.close();
        getListData();
    }

    public void getListData(){
        PocketDBAdapter pocketDBAdapter = new PocketDBAdapter(this);
        pocketDBAdapter.open();
        Cursor c = pocketDBAdapter.fetchAllEntry();
        moneyitems.clear();
        while (c.moveToNext()){
            moneyitems.add(new Moneyitem(c.getString(1),c.getString(2),c.getString(3),c.getString(4)));
            Log.e("money",c.getString(1)+" "+c.getString(2)+" "+c.getString(3)+" "+c.getString(4));
        }
        pocketDBAdapter.close();

        adapter.notifyDataSetChanged();
    }

}
