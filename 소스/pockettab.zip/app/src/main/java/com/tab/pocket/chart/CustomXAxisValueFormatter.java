package com.tab.pocket.chart;

import com.github.mikephil.charting.charts.BarLineChartBase;
import com.github.mikephil.charting.formatter.ValueFormatter;

import java.util.ArrayList;


public class CustomXAxisValueFormatter extends ValueFormatter
{
    public String state = "";
    public ArrayList<String> mDatas = new ArrayList<>();


    private BarLineChartBase<?> chart;

    public CustomXAxisValueFormatter(BarLineChartBase<?> chart) {
        this.chart = chart;
    }


    @Override
    public String getFormattedValue(float value) {

        int days = (int) value;
        String data = "";
        try{
            data = mDatas.get(days);
        }catch (Exception e){

        }
        return data;

    }


}
