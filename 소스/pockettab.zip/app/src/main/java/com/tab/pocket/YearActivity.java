package com.tab.pocket;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.TextView;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.tab.pocket.chart.CustomXAxisValueFormatter;
import com.tab.pocket.database.PocketDBAdapter;
import com.tab.pocket.dialog.InfoDialog;
import com.tab.pocket.view.PlusMinusView;
import com.tab.pocket.view.SelectableBottomNavigationView;

import java.text.SimpleDateFormat;
import java.time.Year;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class YearActivity extends AppCompatActivity {

    private SelectableBottomNavigationView bottomNavigationView;
    private PlusMinusView plusview1;


    private LineChart mChart1;

    String types[] = {"Expense","Income"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_year);

        plusview1 = findViewById(R.id.plusview1);
        plusview1.setUnit("Year");
        Calendar calendar =  Calendar.getInstance();
        plusview1.setValue(calendar.get(Calendar.YEAR));


        plusview1.setDataListener(new PlusMinusView.DataListener() {
            @Override
            public void dataChange(int value) {
              //  plusview1.setRemoveMaxData(value);
                setData(value);
            }
        });

        bottomNavigationView = (SelectableBottomNavigationView) findViewById(R.id.navigation);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                if(menuItem.getItemId() == R.id.navigation_home){
                    Intent intent = new Intent(YearActivity.this,MainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                }else if(menuItem.getItemId()==R.id.navigation_year){


                }else if(menuItem.getItemId()==R.id.navigation_day){
                    Intent intent = new Intent(YearActivity.this,DayActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                }else if(menuItem.getItemId()==R.id.navigation_camera){
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivity(intent);

                }else if(menuItem.getItemId()==R.id.navigation_info){
                    InfoDialog infoDialog = new InfoDialog(YearActivity.this);
                    infoDialog.setClickListener(new InfoDialog.ClickListener() {
                        @Override
                        public void setOnClick() {
                            finish();
                        }
                    });
                    infoDialog.show();
                }
                return false;
            }
        });

        bottomNavigationView.getMenu().findItem(R.id.navigation_year).setChecked(true);
        initChart1();
    }

    private void initChart1() {
        mChart1 = (LineChart) findViewById(R.id.chart1);


        // no description text
        mChart1.getDescription().setEnabled(false);

        // enable touch gestures
        mChart1.setTouchEnabled(true);

        mChart1.setDragDecelerationFrictionCoef(0.9f);

        // enable scaling and dragging
        mChart1.setDragEnabled(false);
        mChart1.setScaleEnabled(false);
        mChart1.setDrawGridBackground(false);
        mChart1.setHighlightPerDragEnabled(false);

        // if disabled, scaling can be done on x- and y-axis separately
        mChart1.setPinchZoom(false);

        // set an alternative background color
        mChart1.setBackgroundColor(Color.WHITE);




        mChart1.animateX(2500);

        setDataX1();
        // get the legend (only possible after setting data)
        Legend l = mChart1.getLegend();
        int year = Calendar.getInstance().get(Calendar.YEAR);
        setData(year);


        // modify the legend ...
        l.setForm(Legend.LegendForm.LINE);

        l.setTextSize(11f);

        l.setTextColor(Color.BLACK);
        l.setVerticalAlignment(Legend.LegendVerticalAlignment.BOTTOM);
        l.setHorizontalAlignment(Legend.LegendHorizontalAlignment.LEFT);
        l.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        l.setDrawInside(false);
//        l.setYOffset(11f);



        YAxis leftAxis = mChart1.getAxisLeft();

        mChart1.getAxisRight().setEnabled(false);
        mChart1.getAxisLeft().setEnabled(true);
        mChart1.getAxisLeft().setAxisMinimum(0);
        mChart1.getAxisRight().setAxisMinimum(0);
        mChart1.getLegend().setEnabled(true);


    }
    public void setDataX1() {
        CustomXAxisValueFormatter xAxisFormatter = new CustomXAxisValueFormatter(mChart1);
        XAxis xAxis = mChart1.getXAxis();
        xAxisFormatter.mDatas.clear();
        Calendar date = Calendar.getInstance();

        xAxisFormatter.mDatas.add("1");
        xAxisFormatter.mDatas.add("2");
        xAxisFormatter.mDatas.add("3");
        xAxisFormatter.mDatas.add("4");
        xAxisFormatter.mDatas.add("5");
        xAxisFormatter.mDatas.add("6");
        xAxisFormatter.mDatas.add("7");
        xAxisFormatter.mDatas.add("8");
        xAxisFormatter.mDatas.add("9");
        xAxisFormatter.mDatas.add("10");
        xAxisFormatter.mDatas.add("11");
        xAxisFormatter.mDatas.add("12");




        xAxis.setDrawGridLines(false);
        xAxis.setGranularity(1f); // only intervals of 1 day
        xAxis.setLabelCount(22);
        xAxis.setValueFormatter(xAxisFormatter);
        xAxis.setTextColor(Color.BLACK);



        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
    }
    SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");

    private void setData(int year) {

        ArrayList<Entry> yVals1 = new ArrayList<Entry>();
        ArrayList<Entry> yVals2 = new ArrayList<Entry>();
        ArrayList<Entry> yVals3 = new ArrayList<Entry>();
        PocketDBAdapter pocketDBAdapter = new PocketDBAdapter(this);
        pocketDBAdapter.open();
        Calendar date = Calendar.getInstance();

        Log.e("year",year+" ");
        for (int i = 0; i < 12; i++) {

            date.set(Calendar.DAY_OF_MONTH, date.getActualMinimum(Calendar.DAY_OF_MONTH));

            date.set(Calendar.MONTH, i);
            date.set(Calendar.YEAR, year);
            Date date1 = date.getTime();
            date.set(Calendar.DAY_OF_MONTH, date.getActualMaximum(Calendar.DAY_OF_MONTH));
            date.set(Calendar.MONTH, i);
            date.set(Calendar.YEAR, year);
            Date date2 = date.getTime();
            Cursor c = pocketDBAdapter.fetchAllEntryMonth(sdf1.format(date1), sdf1.format(date2),types[0]);

            if (c.moveToNext()) {
                yVals1.add(new Entry(i, c.getInt(0)));
            } else {
                yVals1.add(new Entry(i, 0));
            }

        }



        LineDataSet set1;

        if (mChart1.getData() != null &&
                mChart1.getData().getDataSetCount() > 0) {
            mChart1.clear();

        }
        // create a dataset and give it a type
        set1 = new LineDataSet(yVals1, types[0]);

        set1.setAxisDependency(YAxis.AxisDependency.LEFT);
        set1.setColor(Color.rgb(0, 0, 0));
        set1.setCircleColor(Color.rgb(0, 0, 0));

        set1.setLineWidth(2f);

        set1.setCircleRadius(1f);
        set1.setFillAlpha(65);
        set1.setFillColor(Color.rgb(0, 0, 0));
        set1.setHighLightColor(Color.rgb(0, 0, 0));
        set1.setDrawValues(true);
        set1.setDrawCircleHole(false);

        for (int i = 0; i < 12; i++) {

            date.set(Calendar.DAY_OF_MONTH, date.getActualMinimum(Calendar.DAY_OF_MONTH));

            date.set(Calendar.MONTH, i);
            date.set(Calendar.YEAR, year);
            Date date1 = date.getTime();
            date.set(Calendar.DAY_OF_MONTH, date.getActualMaximum(Calendar.DAY_OF_MONTH));
            date.set(Calendar.MONTH, i);
            date.set(Calendar.YEAR, year);
            Date date2 = date.getTime();
            Cursor c = pocketDBAdapter.fetchAllEntryMonth(sdf1.format(date1), sdf1.format(date2),types[1]);

            if (c.moveToNext()) {
                yVals2.add(new Entry(i, c.getInt(0)));
            } else {
                yVals2.add(new Entry(i, 0));
            }

        }

        LineDataSet set2;

        // create a dataset and give it a type
        set2 = new LineDataSet(yVals2, types[1]);

        set2.setAxisDependency(YAxis.AxisDependency.LEFT);
        set2.setColor(Color.rgb(255, 0, 0));
        set2.setCircleColor(Color.rgb(255, 0, 0));

        set2.setLineWidth(2f);

        set2.setCircleRadius(1f);
        set2.setFillAlpha(65);
        set2.setFillColor(Color.rgb(255, 0, 0));
        set2.setHighLightColor(Color.rgb(0, 0, 0));
        set2.setDrawValues(true);
        set2.setDrawCircleHole(false);






        ArrayList<ILineDataSet> dataSets = new ArrayList<ILineDataSet>();
        dataSets.add(set1); // add the datasets
        dataSets.add(set2);





        // create a data object with the datasets
        LineData data = new LineData(dataSets);

        // set data
        mChart1.setData(data);

    }


}
