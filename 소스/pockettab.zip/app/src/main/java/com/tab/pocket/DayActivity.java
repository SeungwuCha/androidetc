package com.tab.pocket;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.TextView;

import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.github.mikephil.charting.utils.MPPointF;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.tab.pocket.chart.PieFormatter;
import com.tab.pocket.database.PocketDBAdapter;
import com.tab.pocket.dialog.InfoDialog;
import com.tab.pocket.item.GroupMoneyitem;
import com.tab.pocket.item.Moneyitem;
import com.tab.pocket.view.SelectableBottomNavigationView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class DayActivity extends AppCompatActivity implements OnChartValueSelectedListener {
    SimpleDateFormat sdf1 =  new SimpleDateFormat("yyyy-MM-dd(E)");
    SimpleDateFormat sdf2 =  new SimpleDateFormat("yyyy-MM-dd");

    TextView tv_date;
    private SelectableBottomNavigationView bottomNavigationView;

    PieChart mChart;

    ArrayList<GroupMoneyitem> alMoneyItem = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_day);

        tv_date= findViewById(R.id.tv_date);

        tv_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dateSel();
            }
        });


        bottomNavigationView = (SelectableBottomNavigationView) findViewById(R.id.navigation);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                if(menuItem.getItemId() == R.id.navigation_home){
                    Intent intent = new Intent(DayActivity.this,MainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                }else if(menuItem.getItemId()==R.id.navigation_year){
                    Intent intent = new Intent(DayActivity.this,YearActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);

                }else if(menuItem.getItemId()==R.id.navigation_day){

                }else if(menuItem.getItemId()==R.id.navigation_camera){
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivity(intent);

                }else if(menuItem.getItemId()==R.id.navigation_info){
                    InfoDialog infoDialog = new InfoDialog(DayActivity.this);
                    infoDialog.setClickListener(new InfoDialog.ClickListener() {
                        @Override
                        public void setOnClick() {
                            finish();
                        }
                    });
                    infoDialog.show();
                }
                return false;
            }
        });

        bottomNavigationView.getMenu().findItem(R.id.navigation_day).setChecked(true);


        initChart();
        initDate();
    }
    public void initDate(){
        Calendar calendar =  Calendar.getInstance();

        tv_date.setText(sdf1.format(calendar.getTime()));
        getListData(sdf2.format(calendar.getTime()));
    }


    //Select Date
    public void dateSel(){
        Calendar calendar =  Calendar.getInstance();
        int year =calendar.get(Calendar.YEAR);
        int month =calendar.get(Calendar.MONTH);
        int day =calendar.get(Calendar.DATE);
        DatePickerDialog dialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                Calendar calendar =  Calendar.getInstance();
                calendar.set(year,month,day);
                tv_date.setText(sdf1.format(calendar.getTime()));
                getListData(sdf2.format(calendar.getTime()));
            }
        },year,month,day);
        dialog.show();


    }

    //Pie Chart
    public void initChart(){
        mChart = (PieChart) findViewById(R.id.chart1);
        mChart.setUsePercentValues(true);
        mChart.getDescription().setEnabled(false);
        mChart.setExtraOffsets(5, 10, 5, 5);

        mChart.setDragDecelerationFrictionCoef(0.95f);

        //No middle
        mChart.setDrawHoleEnabled(false);
        mChart.setHoleRadius(0);
        mChart.setTransparentCircleRadius(0);

        mChart.setDrawCenterText(true);

        mChart.setRotationAngle(0);
        // enable rotation of the chart by touch
        mChart.setRotationEnabled(true);
        mChart.setHighlightPerTapEnabled(true);

        // mChart.setUnit(" €");
        // mChart.setDrawUnitsInChart(true);

        // add a selection listener
        //no Percentage
        mChart.setUsePercentValues(false);
        mChart.setOnChartValueSelectedListener(this);



        //mChart.animateY(1400, Easing.EaseInOutQuad);
    }

    private void setData() {



        ArrayList<PieEntry> entries = new ArrayList<PieEntry>();

        // NOTE: The order of the entries when being added to the entries array determines their position around the center of
        // the chart.
        for (int i = 0; i < alMoneyItem.size() ; i++) {
            entries.add(new PieEntry(alMoneyItem.get(i).getMoney(),
                    alMoneyItem.get(i).getType(),
                    getResources().getDrawable(R.drawable.ic_pie_chart)));
        }

        PieDataSet dataSet = new PieDataSet(entries, "Day Chart");

        dataSet.setDrawIcons(false);

        dataSet.setSliceSpace(3f);
        dataSet.setIconsOffset(new MPPointF(0, 40));
        dataSet.setSelectionShift(5f);

        // add a lot of colors

        ArrayList<Integer> colors = new ArrayList<Integer>();

        for (int c : ColorTemplate.VORDIPLOM_COLORS)
            colors.add(c);

        for (int c : ColorTemplate.JOYFUL_COLORS)
            colors.add(c);

        for (int c : ColorTemplate.COLORFUL_COLORS)
            colors.add(c);



        colors.add(ColorTemplate.getHoloBlue());

        dataSet.setColors(colors);
        //dataSet.setSelectionShift(0f);

        PieData data = new PieData(dataSet);
        data.setValueFormatter(new PieFormatter());
        data.setValueTextSize(11f);
        data.setValueTextColor(Color.WHITE);

        mChart.setData(data);

        // undo all highlights
        mChart.highlightValues(null);

        mChart.invalidate();
    }

    public void getListData(String date){
        PocketDBAdapter pocketDBAdapter = new PocketDBAdapter(this);
        pocketDBAdapter.open();
        Cursor c = pocketDBAdapter.fetchAllEntryForDay(date,"Budget");
        int total = 0;
        alMoneyItem.clear();
        if(c.moveToNext()){
            total = c.getInt(0);
        }

        c = pocketDBAdapter.fetchAllEntryForDay(date,"Expense");
        if (c.moveToNext()) {
            alMoneyItem.add(new GroupMoneyitem(c.getString(1), c.getInt(0)));
            if (total >= c.getInt(0)) {
                alMoneyItem.add(new GroupMoneyitem("Remain", total - c.getInt(0)));
            } else {
                //over budget
                alMoneyItem.add(new GroupMoneyitem("Remain", 0));
            }

        }else{
            alMoneyItem.add(new GroupMoneyitem("Expense", 0));

            alMoneyItem.add(new GroupMoneyitem("Remain", total));

        }

        pocketDBAdapter.close();
        setData();


    }

    @Override
    public void onValueSelected(Entry e, Highlight h) {

    }

    @Override
    public void onNothingSelected() {

    }
}
