package com.tab.pocket.item;

public class Moneyitem {
    String date;
    String time;
    String money;
    String type;

    public Moneyitem(String date, String time, String type, String money) {
        this.date = date;
        this.time = time;
        this.money = money;
        this.type = type;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
