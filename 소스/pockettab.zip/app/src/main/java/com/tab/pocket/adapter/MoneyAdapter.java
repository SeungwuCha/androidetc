package com.tab.pocket.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;


import com.tab.pocket.R;
import com.tab.pocket.item.Moneyitem;

import java.util.ArrayList;


public class MoneyAdapter extends RecyclerView.Adapter<MoneyAdapter.MyViewHolder>  {

    public ArrayList<Moneyitem> outDataList;
    Context context;

    public MoneyAdapter(Context context, ArrayList<Moneyitem> outDataList) {
        this.context = context;
        this.outDataList = outDataList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_money,null);
        MyViewHolder viewHolder = new MyViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {


        holder.tv_type.setText(outDataList.get(position).getType());;
        holder.tv_date.setText(outDataList.get(position).getDate()+" "+outDataList.get(position).getTime());

        holder.tv_money.setText("$"+outDataList.get(position).getMoney());

    }


    @Override
    public int getItemCount() {
        return outDataList.size();
    }

    public void setList(ArrayList<Moneyitem> list) {
        this.outDataList = list;
    }



    public static class MyViewHolder extends RecyclerView.ViewHolder{

        public TextView tv_type,tv_date;
        public TextView tv_money;

        Context context;

        public MyViewHolder(View itemView) {
            super(itemView);


            tv_type = (TextView) itemView.findViewById(R.id.tv_type);

            tv_date = (TextView) itemView.findViewById(R.id.tv_date);
            tv_money = (TextView)itemView.findViewById(R.id.tv_money);
            context = itemView.getContext();

        }


    }
}