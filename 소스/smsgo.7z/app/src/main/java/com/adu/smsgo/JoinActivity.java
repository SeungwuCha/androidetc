package com.adu.smsgo;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.adu.smsgo.web.SendHttp;

import org.json.JSONObject;

import java.util.HashMap;

public class JoinActivity extends AppCompatActivity implements View.OnClickListener {
    EditText et_id,et_pass,et_pass2,et_name,et_email,et_phone;

    Button btn_join;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join);
        initRes();
    }

    private void initRes() {
        et_id = (EditText)findViewById(R.id.et_id);
        et_pass = (EditText)findViewById(R.id.et_pass);
        et_pass2 = (EditText)findViewById(R.id.et_pass_2);
        et_name = (EditText)findViewById(R.id.et_name);
        et_email = (EditText)findViewById(R.id.et_email);
        et_phone = (EditText)findViewById(R.id.et_phone);

        btn_join = (Button)findViewById(R.id.btn_join);
        btn_join.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(view == btn_join){
            if(et_id.getText().toString().trim().equals("")){
                Toast.makeText(this, "아이디가 비었습니다.", Toast.LENGTH_SHORT).show();
            }else if(et_pass.getText().toString().trim().equals("")){
                Toast.makeText(this, "비밀번호가 비었습니다.", Toast.LENGTH_SHORT).show();
            }else if(et_pass2.getText().toString().trim().equals("")){
                Toast.makeText(this, "비밀번호가 비었습니다.", Toast.LENGTH_SHORT).show();
            }else if(et_name.getText().toString().trim().equals("")){
                Toast.makeText(this, "이름이 비었습니다.", Toast.LENGTH_SHORT).show();
            }else if(et_email.getText().toString().trim().equals("")){
                Toast.makeText(this, "이메일이 비었습니다.", Toast.LENGTH_SHORT).show();
            }else if(et_phone.getText().toString().trim().equals("")){
                Toast.makeText(this, "전화번호가 비었습니다.", Toast.LENGTH_SHORT).show();
            }else if(!et_pass2.getText().toString().trim().equals(et_pass.getText().toString().trim())){
                Toast.makeText(this, "비밀번호가 동일하지 않습니다.", Toast.LENGTH_SHORT).show();
            }else {
                setJoin();
            }
        }
    }

    private void setJoin() {
        HashMap<String,String> mParm = new HashMap<>();
        mParm.put("id",et_id.getText().toString());
        mParm.put("password",et_pass.getText().toString());
        mParm.put("name",et_name.getText().toString());
        mParm.put("email",et_email.getText().toString());
        mParm.put("phone",et_phone.getText().toString());
        WebTask task = new WebTask();
        task.SetParam(mParm);
        task.execute();
    }


    private class WebTask extends AsyncTask<String, Void, String> {

        HashMap<String, String> mParm = null;





        public void SetParam(HashMap<String, String> parm) {
            mParm = parm;

        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();


        }


        @Override
        protected String doInBackground(String... params) {
            String strRtn = null;



            SendHttp sendhttp = new SendHttp();
            String strUrl = "http://chasw12.dothome.co.kr/join_table.php";
            System.out.println("strUrl" + strUrl);
            strRtn = sendhttp.postHttpClientToString(strUrl, mParm);

            return strRtn;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            System.out.println("result"+result);
            try {
                JSONObject object = new JSONObject(result);
                int value =  object.getInt("value");
                Log.e("value","abc"+value);
                if(value == 1){
                    Toast.makeText(JoinActivity.this, "회원가입 성공", Toast.LENGTH_SHORT).show();
                    finish();
                }else{
                    Toast.makeText(JoinActivity.this, "회원가입 실패", Toast.LENGTH_SHORT).show();
                }

            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(JoinActivity.this, "회원가입 실패", Toast.LENGTH_SHORT).show();
            }


        }
    }
}
