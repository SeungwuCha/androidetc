package com.adu.smsgo;

import android.content.Context;
import android.content.SharedPreferences;

public class BTDoorSharedpreference {

	final private static String BT = "bt";
	//인증여부
	final private static String PREFKEY_MSG = "message";

	//전화번호
	final private static String PREFKEY_PHONE = "phone";
	final private static String PREFKEY_PHONE2 = "phone2";
	final private static String PREFKEY_PHONE3 = "phone3";

	//시간
	final private static String PREFKEY_TIME = "time";

	//위도
	final private static String PREFKEY_LATITUDE = "latitude";
	//경도
	final private static String PREFKEY_LONGITUDE = "longitude";
	//주소
	final private static String PREFKEY_ADDRESS = "address";


	public static void setSharedPrefMessage(Context context, String value){
		SharedPreferences pref = context.getSharedPreferences(BT, Context.MODE_PRIVATE);
		SharedPreferences.Editor prefEditor = pref.edit();
		prefEditor.putString(PREFKEY_MSG, value);
		prefEditor.commit();
	}

	public static String getSharedPrefMessage(Context context){
		SharedPreferences pref = context.getSharedPreferences(BT, Context.MODE_PRIVATE);
		return pref.getString(PREFKEY_MSG,"");
	}
	public static void setSharedPrefPhone(Context context, String value){
		SharedPreferences pref = context.getSharedPreferences(BT, Context.MODE_PRIVATE);
		SharedPreferences.Editor prefEditor = pref.edit();
		prefEditor.putString(PREFKEY_PHONE, value);
		prefEditor.commit();
	}

	public static String getSharedPrefPhone(Context context){
		SharedPreferences pref = context.getSharedPreferences(BT, Context.MODE_PRIVATE);
		return pref.getString(PREFKEY_PHONE,"");
	}
	public static void setSharedPrefPhone2(Context context, String value){
		SharedPreferences pref = context.getSharedPreferences(BT, Context.MODE_PRIVATE);
		SharedPreferences.Editor prefEditor = pref.edit();
		prefEditor.putString(PREFKEY_PHONE2, value);
		prefEditor.commit();
	}

	public static String getSharedPrefPhone2(Context context){
		SharedPreferences pref = context.getSharedPreferences(BT, Context.MODE_PRIVATE);
		return pref.getString(PREFKEY_PHONE2,"");
	}


	public static void setSharedPrefPhone3(Context context, String value){
		SharedPreferences pref = context.getSharedPreferences(BT, Context.MODE_PRIVATE);
		SharedPreferences.Editor prefEditor = pref.edit();
		prefEditor.putString(PREFKEY_PHONE3, value);
		prefEditor.commit();
	}

	public static String getSharedPrefPhone3(Context context){
		SharedPreferences pref = context.getSharedPreferences(BT, Context.MODE_PRIVATE);
		return pref.getString(PREFKEY_PHONE3,"");
	}

	public static void setSharedPrefTime(Context context, int value){
		SharedPreferences pref = context.getSharedPreferences(BT, Context.MODE_PRIVATE);
		SharedPreferences.Editor prefEditor = pref.edit();
		prefEditor.putInt(PREFKEY_TIME, value);
		prefEditor.commit();
	}

	public static int getSharedPrefTime(Context context){
		SharedPreferences pref = context.getSharedPreferences(BT, Context.MODE_PRIVATE);
		return pref.getInt(PREFKEY_TIME,0);
	}

	public static void setSharedPrefLatitude(Context context, float value){
		SharedPreferences pref = context.getSharedPreferences(BT, Context.MODE_PRIVATE);
		SharedPreferences.Editor prefEditor = pref.edit();
		prefEditor.putFloat(PREFKEY_LATITUDE, value);
		prefEditor.commit();
	}

	public static float getSharedPrefLatitude(Context context){
		SharedPreferences pref = context.getSharedPreferences(BT, Context.MODE_PRIVATE);
		return pref.getFloat(PREFKEY_LATITUDE,0.0f);
	}

	public static void setSharedPrefLongitude(Context context, float value){
		SharedPreferences pref = context.getSharedPreferences(BT, Context.MODE_PRIVATE);
		SharedPreferences.Editor prefEditor = pref.edit();
		prefEditor.putFloat(PREFKEY_LONGITUDE, value);
		prefEditor.commit();
	}

	public static float getSharedPrefLongitude(Context context){
		SharedPreferences pref = context.getSharedPreferences(BT, Context.MODE_PRIVATE);
		return pref.getFloat(PREFKEY_LONGITUDE,0.0f);
	}

	public static void setSharedPrefAddress(Context context, String value){
		SharedPreferences pref = context.getSharedPreferences(BT, Context.MODE_PRIVATE);
		SharedPreferences.Editor prefEditor = pref.edit();
		prefEditor.putString(PREFKEY_ADDRESS, value);
		prefEditor.commit();
	}

	public static String getSharedPrefAddress(Context context){
		SharedPreferences pref = context.getSharedPreferences(BT, Context.MODE_PRIVATE);
		return pref.getString(PREFKEY_ADDRESS,"");
	}

}
