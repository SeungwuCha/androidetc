package com.adu.smsgo;



import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;
import android.util.Log;

public class DataDBAdapter {


	private static final String DATABASE_NAME = "data.db";
	private static final String DATABASE_TABLE = "tb_data";

	public static final int DATABASE_VERSION = 1;


	private static final String DATABASE_CREATE = "create table "
			+ DATABASE_TABLE + " (" + DataEntry.Data_IDX
			+ " INTEGER primary key, " +  DataEntry.Data_time
			+ " Text not null, " + DataEntry.Data_ID
			+ " Text not null, " + DataEntry.Data_gps_x
			+ " DOUBLE not null, " + DataEntry.Data_gps_y
			+ " DOUBLE not null, " + DataEntry.Data_h
			+ " INTEGER not null, " + DataEntry.Data_check
			+ " INTEGER not null);";
	private static final String TAG = "BoothDBAdapter";

	public String[] COLUMNS = new String[] {DataEntry.Data_IDX,
			DataEntry.Data_time, DataEntry.Data_gps_x, DataEntry.Data_gps_y, DataEntry.Data_h};
	private String[] CountCOLUMNS = new String[] {"count(idx)"
			};
	private Context mContext;
	private DatabaseHelper mDbHelper;
	private SQLiteDatabase mDb;

	public DataDBAdapter(Context context) {
		mContext = context;
	}

	public DataDBAdapter open() throws SQLException {
		mDbHelper = new DatabaseHelper(mContext);
		mDb = mDbHelper.getWritableDatabase();
		return this;
	}

	public void close() {
		if(mDbHelper!=null)
			mDbHelper.close();
	}

	
	public long createEntry(String id,String time, String x,String y,String h) {
		ContentValues initialValues = new ContentValues();
		initialValues.put(DataEntry.Data_ID, id);
		initialValues.put(DataEntry.Data_time, time);
		initialValues.put(DataEntry.Data_gps_x, x);
		initialValues.put(DataEntry.Data_gps_y, y);
		initialValues.put(DataEntry.Data_h, h);
		initialValues.put(DataEntry.Data_check, 1);

		
		
		return mDb.insert(DATABASE_TABLE, null, initialValues);
	}
	
	public long updateEntry()  {
		ContentValues initialValues = new ContentValues();

		initialValues.put(DataEntry.Data_check, 2);

		return mDb.update(DATABASE_TABLE, initialValues, DataEntry.Data_check + " = " + 1, null);

	}
	public Cursor selectCheckEntry() {
		//
		Cursor qu = mDb.query(DATABASE_TABLE, COLUMNS,
				DataEntry.Data_check +" = "+1 +" and "+DataEntry.Data_h +" != 0",
				null, null, null, null);

		return qu;

	}
	

	public Cursor selectIDXEntry(String strIdx) {
		//
		Cursor qu = mDb.query(DATABASE_TABLE, COLUMNS,
				DataEntry.Data_IDX +" = "+strIdx,
				null, null, null, null);

		return qu;

	}

	public Cursor selectIDEntry(String id) {
		//
		Cursor qu = mDb.query(DATABASE_TABLE, COLUMNS,
				DataEntry.Data_ID +" = "+id,
				null, null, null, null);

		return qu;

	}


	
	public Cursor fetchAllEntry() {
		return mDb.query(DATABASE_TABLE, COLUMNS, null, null, null, null, null);
	}
	public Cursor fetchAllEntryASC() {
		return mDb.query(DATABASE_TABLE, COLUMNS, null, null, null, null, DataEntry.Data_IDX +" asc");
	}
	
	
	public int fetchAllEntryLength() {
		return mDb.query(DATABASE_TABLE, COLUMNS, null, null, null, null, null).getCount();
	}
	
	public void delIDXEntry(String strIdx) {
		mDb.delete(DATABASE_TABLE, DataEntry.Data_IDX +"= "+strIdx, null);
	}
	public void delAllEntry() {
		mDb.delete(DATABASE_TABLE, null, null);
	}

	private class DatabaseHelper extends SQLiteOpenHelper {

		public DatabaseHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			db.execSQL(DATABASE_CREATE);

		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
					+ newVersion + ", which will destory all old data");
			db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);

		}

	}




	//시간
	//GPS위치_X
	//GPS위치_Y
	//심박수
	//ID

	
	public class DataEntry implements BaseColumns {
		public static final String Data_IDX = "idx";
		public static final String Data_ID = "Data_id";
		public static final String Data_time = "time";
		public static final String Data_gps_x = "gps_x";
		public static final String Data_gps_y = "gps_y";
		public static final String Data_h = "h";
		public static final String Data_check = "data_check";



	}
	
}
