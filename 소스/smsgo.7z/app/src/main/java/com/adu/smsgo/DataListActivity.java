package com.adu.smsgo;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;

import com.adu.smsgo.list.Data;
import com.adu.smsgo.list.DataAdapter;

import java.util.ArrayList;

public class DataListActivity extends AppCompatActivity implements View.OnClickListener {
    DataDBAdapter dbAdapter;
    DataAdapter adapter;
    ArrayList<Data> alData = new ArrayList<>();
    ListView list;
    RelativeLayout layout_back,layout_clear;
    ImageView iv_clear;
    boolean isClear = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_list);
        initRes();
        getData();
    }

    private void getData() {
        dbAdapter = new DataDBAdapter(this);
        dbAdapter.open();
        Cursor c = dbAdapter.fetchAllEntryASC();
        while(c.moveToNext()){
            alData.add(0,new Data(c.getString(1),c.getString(2),c.getString(3),c.getString(4)));
        }
        dbAdapter.close();
        adapter.notifyDataSetChanged();
    }

    private void initRes() {
        list = (ListView)findViewById(R.id.list);
        adapter =  new DataAdapter(this,R.layout.item_data,alData);
        list.setAdapter(adapter);
        layout_back = (RelativeLayout)findViewById(R.id.layout_back);
        layout_back.setOnClickListener(this);
        layout_clear = (RelativeLayout)findViewById(R.id.layout_clear);
        layout_clear.setOnClickListener(this);
        iv_clear = (ImageView)findViewById(R.id.iv_clear);
    }

    @Override
    public void onClick(View view) {
        if(view == layout_back){
            finish();
        }else if(view == layout_clear){
            if(!isClear) {
                dbAdapter = new DataDBAdapter(this);
                dbAdapter.open();
                dbAdapter.delAllEntry();
                dbAdapter.close();
                alData.clear();
                adapter.notifyDataSetChanged();
                iv_clear.setBackgroundResource(R.drawable.ic_reload);
                isClear = true;
            }else{
                getData();
                iv_clear.setBackgroundResource(R.drawable.ic_clear);
                isClear = false;
            }
        }
    }
}
