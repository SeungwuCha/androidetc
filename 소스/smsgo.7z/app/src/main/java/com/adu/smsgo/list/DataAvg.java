package com.adu.smsgo.list;

/**
 * Created by cha's on 2017-09-24.
 */

public class DataAvg {
    String time;

    String h;

    public DataAvg(String time, String h) {
        this.time = time;

        this.h = h;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }



    public String getH() {
        return h;
    }

    public void setH(String h) {
        this.h = h;
    }
}
