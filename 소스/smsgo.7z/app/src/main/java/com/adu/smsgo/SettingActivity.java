package com.adu.smsgo;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;

import java.util.Calendar;

public class SettingActivity extends AppCompatActivity implements View.OnClickListener {

    EditText et_message, et_phone,et_phone2,et_phone3;
    RadioGroup rg;
    RadioButton radio1, radio2, radio3, radio4;
    Button btn_store;
    RelativeLayout layout_back;
    AlarmManager _am;

    int[] times = {1, 2, 6, 12};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        initRes();
        getData();

        _am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
    }

    private void getData() {
        et_message.setText(BTDoorSharedpreference.getSharedPrefMessage(this));
        et_phone.setText(BTDoorSharedpreference.getSharedPrefPhone(this));
        et_phone2.setText(BTDoorSharedpreference.getSharedPrefPhone2(this));
        et_phone3.setText(BTDoorSharedpreference.getSharedPrefPhone3(this));
        setRadio(BTDoorSharedpreference.getSharedPrefTime(this));

    }

    private void initRes() {
        et_message = (EditText) findViewById(R.id.et_message);
        et_phone = (EditText) findViewById(R.id.et_phone1);
        et_phone2 = (EditText) findViewById(R.id.et_phone2);
        et_phone3 = (EditText) findViewById(R.id.et_phone3);

        rg = (RadioGroup) findViewById(R.id.rg);

        radio1 = (RadioButton) findViewById(R.id.radio1);
        radio2 = (RadioButton) findViewById(R.id.radio2);
        radio3 = (RadioButton) findViewById(R.id.radio3);
        radio4 = (RadioButton) findViewById(R.id.radio4);

        btn_store = (Button) findViewById(R.id.btn_store);
        btn_store.setOnClickListener(this);
        layout_back = (RelativeLayout)findViewById(R.id.layout_back);
        layout_back.setOnClickListener(this);
    }

    public void setRadio(int i) {

        radio1.setChecked(i == 0);
        radio2.setChecked(i == 1);
        radio3.setChecked(i == 2);
        radio4.setChecked(i == 3);
    }

    @Override
    public void onClick(View view) {
        if (view == btn_store) {
            AlertDialog.Builder dialog = new AlertDialog.Builder(this);
            dialog.setMessage("저장되었습니다.");
            dialog.show();
            BTDoorSharedpreference.setSharedPrefMessage(this, et_message.getText().toString());
            BTDoorSharedpreference.setSharedPrefPhone(this, et_phone.getText().toString());
            BTDoorSharedpreference.setSharedPrefPhone2(this, et_phone2.getText().toString());
            BTDoorSharedpreference.setSharedPrefPhone3(this, et_phone3.getText().toString());
            if (radio1.isChecked()) {
                BTDoorSharedpreference.setSharedPrefTime(this, 0);
            } else if (radio2.isChecked()) {
                BTDoorSharedpreference.setSharedPrefTime(this, 1);
            } else if (radio3.isChecked()) {
                BTDoorSharedpreference.setSharedPrefTime(this, 2);
            } else if (radio4.isChecked()) {
                BTDoorSharedpreference.setSharedPrefTime(this, 3);
            }
            registAlarm();
        }else if(view ==  layout_back){
            finish();
        }
    }

    private void registAlarm() {
        cancelAlarm();

        boolean isRepeat = false;


        // 알람 등록
        Intent intent = new Intent(this, AlarmReceiver.class);

        long triggerTime = 0;
        long intervalTime = times[BTDoorSharedpreference.getSharedPrefTime(this)] * 60 * 60 * 1000;// 시간단위

        PendingIntent pending = getPendingIntent(intent);

        triggerTime = setTriggerTime();

        _am.setRepeating(AlarmManager.RTC_WAKEUP, triggerTime, intervalTime, pending);


    }

    private long setTriggerTime() {
        // current Time
        long atime = System.currentTimeMillis();
        // timepicker
        Calendar curTime = Calendar.getInstance();

        curTime.set(Calendar.SECOND, 0);
        curTime.set(Calendar.MILLISECOND, 0);
        long btime = curTime.getTimeInMillis();
        long triggerTime = btime;
        if (atime > btime)
            triggerTime += 1000 * 60 * 60 * 1;

        return triggerTime;
    }

    private PendingIntent getPendingIntent(Intent intent) {
        PendingIntent pIntent = PendingIntent.getBroadcast(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        return pIntent;
    }

    private void cancelAlarm() {
        Intent intent = new Intent(this, AlarmReceiver.class);
        PendingIntent pending = getPendingIntent(intent);
        this._am.cancel(pending);
    }

}
