package com.adu.smsgo.bluetooth;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.content.res.AssetManager;
import android.os.Environment;
import android.util.Base64;
import android.util.Log;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

public class Util_Data {




	public static void LogToHexString(String strTag, byte[] buf, int nLen) {
		String strRcvData = "Hex [" + String.valueOf(nLen) + "] ";
		for ( int i = 0; i < nLen; ++i )
		{
			strRcvData += String.format("%02x ", buf[i]);
			//strRcvData += Integer.toHexString(buf[i] & 0x000000FF) + ", ";
		}
		Log.d(strTag, strRcvData);
	}
	public static String ToHexString(byte[] buf, int nLen) {
		String strRcvData = "";
		for ( int i = 0; i < nLen; ++i )
		{
			strRcvData += String.format("%02x ", buf[i]);
			//strRcvData += Integer.toHexString(buf[i] & 0x000000FF) + ", ";
		}
		return strRcvData;
	}
	/**
	 * SDCard 에 파일 쓰기
	 *
	 * @param fileName
	 * @param content
	 * @throws IOException
	 *             , FileNotFoundException , Exception
	 */
	public static void writeSDcard(String fileName, String content) throws IOException, FileNotFoundException, Exception {
		File file = new File(Environment.getExternalStorageDirectory() + "/" + fileName);
		file.setExecutable(true);
		file.setReadable(true);
		file.setWritable(true);
		/*if(file.exists()){
			file.delete();
		}*/
		System.out.println("filexxx : "+file.getPath());
		BufferedWriter buf = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file, true),"MS949"));
		buf.write(content);

		buf.close();


	}

	private void getAppKeyHash(Context context) {
		try {
			PackageInfo info = context.getPackageManager().getPackageInfo(context.getPackageName(), PackageManager.GET_SIGNATURES);
			for (Signature signature : info.signatures) {
				MessageDigest md;
				md = MessageDigest.getInstance("SHA");
				md.update(signature.toByteArray());
				String something = new String(Base64.encode(md.digest(), 0));
				Log.d("Hash key", something);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Log.e("name not found", e.toString());
		}
	}



	public static void copyDbFile(Context context, String dbname) {
		Log.i(context.getClass().getName(), "copyDbFile();");
		AssetManager am = context.getAssets();



		//File toFile = new File(Environment.getDataDirectory() + "/data/"+context.getPackageName()+"/databases/"+dbname);
		File fromFile = new File(Environment.getDataDirectory() + "/data/"+context.getPackageName()+"/databases/"+dbname);
		File toFile = new File(Environment.getExternalStorageDirectory() + "/"+dbname);
	//	File toFile = new File(Environment.getDataDirectory() + "/data/"+context.getPackageName()+"/databases/"+dbname);
//		File fromFile = new File(Environment.getExternalStorageDirectory() + "/"+dbname);
		FileOutputStream fos = null;
		BufferedOutputStream bos = null;
//		BufferedInputStream bis = null;

		try {
			// checkFile("SSM_TEMP.db", "SSM_TEMP.db", db);
			//InputStream is = am.open("temple_0812.db");

			 InputStream is = new FileInputStream(fromFile);

		//	 InputStream bis = new FileInputStream(is);
			//bis = new BufferedInputStream(is);


			if (!toFile.exists()) {
				toFile.createNewFile();
			}
				fos = new FileOutputStream(toFile);
				bos = new BufferedOutputStream(fos);

				int read = -1;
				byte[] buffer = new byte[1024];
				while ((read = is.read(buffer, 0, 1024)) != -1) {
					bos.write(buffer, 0, read);
				}
				bos.flush();

				fos.close();
				bos.close();
				is.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public static void copyDbFile2(Context context, String dbname) {
		Log.i(context.getClass().getName(), "copyDbFile();");
		AssetManager am = context.getAssets();



		//File toFile = new File(Environment.getDataDirectory() + "/data/"+context.getPackageName()+"/databases/"+dbname);
		File toFile = new File(Environment.getDataDirectory() + "/data/"+context.getPackageName()+"/databases/"+dbname);
		File fromFile = new File(Environment.getExternalStorageDirectory() + "/"+dbname);
		//	File toFile = new File(Environment.getDataDirectory() + "/data/"+context.getPackageName()+"/databases/"+dbname);
//		File fromFile = new File(Environment.getExternalStorageDirectory() + "/"+dbname);
		FileOutputStream fos = null;
		BufferedOutputStream bos = null;
//		BufferedInputStream bis = null;

		try {
			// checkFile("SSM_TEMP.db", "SSM_TEMP.db", db);
			//InputStream is = am.open("temple_0812.db");

			InputStream is = new FileInputStream(fromFile);

			//	 InputStream bis = new FileInputStream(is);
			//bis = new BufferedInputStream(is);


			if (!toFile.exists()) {
				toFile.createNewFile();
			}
			fos = new FileOutputStream(toFile);
			bos = new BufferedOutputStream(fos);

			int read = -1;
			byte[] buffer = new byte[1024];
			while ((read = is.read(buffer, 0, 1024)) != -1) {
				bos.write(buffer, 0, read);
			}
			bos.flush();

			fos.close();
			bos.close();
			is.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	/**
	 * SDCard 에 파일 쓰기
	 *
	 * @param content
	 * @throws IOException
	 *             , FileNotFoundException , Exception
	 */
	public static void writeSDcard2(String content) throws IOException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			String fileName = sdf.format(new Date())+".txt";
			File file = new File(Environment.getExternalStorageDirectory() + "/" + fileName);
			file.setExecutable(true);
			file.setReadable(true);
			file.setWritable(true);
		/*if(file.exists()){
			file.delete();
		}*/
			System.out.println("filexxx : " + file.getPath());
			BufferedWriter buf = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file, true), "MS949"));
			buf.write(content);

			buf.close();



	}


	public static void writeSDcard2RS(String content) throws IOException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		String fileName = sdf.format(new Date())+"rssi.txt";
		File file = new File(Environment.getExternalStorageDirectory() + "/" + fileName);
		file.setExecutable(true);
		file.setReadable(true);
		file.setWritable(true);
		/*if(file.exists()){
			file.delete();
		}*/
		//System.out.println("filexxx : " + file.getPath());
		BufferedWriter buf = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file, true), "MS949"));
		buf.write(content);

		buf.close();



	}

}
