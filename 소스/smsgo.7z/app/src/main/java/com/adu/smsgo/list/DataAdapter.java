package com.adu.smsgo.list;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;


import com.adu.smsgo.R;

import java.util.ArrayList;


public class DataAdapter extends BaseAdapter {
	private Context context;
	private LayoutInflater inflater;
	private ArrayList<Data> arSrc;
	private int layout;

	public DataAdapter(Context c, int layout, ArrayList<Data> arSrc) {
		this.context = c;
		this.inflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		this.arSrc = arSrc;
		this.layout = layout;

	}

	@Override
	public int getCount() {
		return arSrc.size();
	}

	@Override
	public Data getItem(int position) {
		return arSrc.get(position);
	}

	@Override
	public long getItemId(int arg0) {
		return 0;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		LVHolder viewHolder;

		if (convertView == null) {
			convertView = inflater.inflate(layout, parent, false);

			viewHolder = new LVHolder();
			viewHolder.tv_time = (TextView) convertView.findViewById(R.id.tv_time);
			viewHolder.tv_gps_x = (TextView) convertView.findViewById(R.id.tv_gps_x);
			viewHolder.tv_gps_y = (TextView) convertView.findViewById(R.id.tv_gps_y);
			viewHolder.tv_h = (TextView) convertView.findViewById(R.id.tv_h);


			convertView.setTag(viewHolder);
		} else {
			viewHolder = (LVHolder) convertView.getTag();
		}

		Data item = arSrc.get(position);


		viewHolder.tv_time.setText(item.getTime());
		viewHolder.tv_gps_x.setText("위도 : "+item.getGps_x());
		viewHolder.tv_gps_y.setText("경도 :  "+item.getGps_y());
		viewHolder.tv_h.setText("심박수 : "+item.getH());

		return convertView;
	}



	public class LVHolder {
		TextView tv_time,tv_h,tv_gps_x,tv_gps_y;
	}

	

	



}
