package com.adu.smsgo;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class AlarmActivity extends AppCompatActivity implements View.OnClickListener {
    Button btn_youtube,btn_alarm_off;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarm);
        btn_youtube = (Button)findViewById(R.id.btn_youtube);
        btn_youtube.setOnClickListener(this);
        btn_alarm_off = (Button)findViewById(R.id.btn_alarm_off);
        btn_alarm_off.setOnClickListener(this);
        setAlarmOn();
    }
    public void setAlarmOn(){
        Intent intent = new Intent("android.alarm.go");
        intent.setPackage("com.adu.smsgo");
        startService(intent);
    }
    public void setAlarmOff(){
        Intent intent = new Intent("android.alarm.go");
        intent.setPackage("com.adu.smsgo");
        stopService(intent);
        MainActivity.isAlarm =false;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        setAlarmOff();
    }

    @Override
    public void onClick(View view) {
        if(view == btn_alarm_off){
            setAlarmOff();
        }else {
            if (view == btn_youtube) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://youtu.be/WneG3XhBayc")));
            }
        }

    }
}
