package com.adu.smsgo;



import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;
import android.util.Log;

public class DataAVGDBAdapter {


	private static final String DATABASE_NAME = "data_avg.db";
	private static final String DATABASE_TABLE = "tb_data_avg";

	public static final int DATABASE_VERSION = 1;


	private static final String DATABASE_CREATE = "create table "
			+ DATABASE_TABLE + " (" + DataEntry.Data_IDX
			+ " INTEGER primary key, " +  DataEntry.Data_time
			+ " Text not null, "  + DataEntry.Data_ID
			+ " Text not null, "  + DataEntry.Data_h
			+ " INTEGER not null);";
	private static final String TAG = "BoothDBAdapter";

	public String[] COLUMNS = new String[] {DataEntry.Data_IDX,
			DataEntry.Data_time, DataEntry.Data_h};
	private String[] CountCOLUMNS = new String[] {"count(idx)"
			};
	private Context mContext;
	private DatabaseHelper mDbHelper;
	private SQLiteDatabase mDb;

	public DataAVGDBAdapter(Context context) {
		mContext = context;
	}

	public DataAVGDBAdapter open() throws SQLException {
		mDbHelper = new DatabaseHelper(mContext);
		mDb = mDbHelper.getWritableDatabase();
		return this;
	}

	public void close() {
		if(mDbHelper!=null)
			mDbHelper.close();
	}

	
	public long createEntry(String id,String time,String h) {
		ContentValues initialValues = new ContentValues();

		initialValues.put(DataEntry.Data_time, time);
		initialValues.put(DataEntry.Data_ID, id);

		initialValues.put(DataEntry.Data_h, h);


		
		
		return mDb.insert(DATABASE_TABLE, null, initialValues);
	}
	


	

	public Cursor selectIDXEntry(String strIdx) {
		//
		Cursor qu = mDb.query(DATABASE_TABLE, COLUMNS,
				DataEntry.Data_IDX +" = "+strIdx,
				null, null, null, null);

		return qu;

	}
	public Cursor fetchAllEntryDESC(String strId) {
		//
		Cursor qu = mDb.query(DATABASE_TABLE, COLUMNS,
				DataEntry.Data_ID +" = '"+strId+"'",
				null, null, null, DataEntry.Data_IDX +" desc");

		return qu;

	}



	
	public Cursor fetchAllEntry() {
		return mDb.query(DATABASE_TABLE, COLUMNS, null, null, null, null, null);
	}
	public Cursor fetchAllEntryDESC() {
		return mDb.query(DATABASE_TABLE, COLUMNS, null, null, null, null, DataEntry.Data_IDX +" desc");
	}
	
	
	public int fetchAllEntryLength() {
		return mDb.query(DATABASE_TABLE, COLUMNS, null, null, null, null, null).getCount();
	}
	
	public void delIDXEntry(String strIdx) {
		mDb.delete(DATABASE_TABLE, DataEntry.Data_IDX +"= "+strIdx, null);
	}
	public void delAllEntry() {
		mDb.delete(DATABASE_TABLE, null, null);
	}

	private class DatabaseHelper extends SQLiteOpenHelper {

		public DatabaseHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			db.execSQL(DATABASE_CREATE);

		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
					+ newVersion + ", which will destory all old data");
			db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);

		}

	}




	//시간
	//GPS위치_X
	//GPS위치_Y
	//심박수

	
	public class DataEntry implements BaseColumns {
		public static final String Data_IDX = "idx";
		public static final String Data_time = "time";
		public static final String Data_h = "h";
		public static final String Data_ID = "Data_id";



	}
	
}
