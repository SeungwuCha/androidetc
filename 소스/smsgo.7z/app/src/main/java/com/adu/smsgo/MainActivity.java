package com.adu.smsgo;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.adu.smsgo.bluetooth.Constants;
import com.adu.smsgo.service.BTCTemplateService;
import com.adu.smsgo.service.Messenger;
import com.gun0912.tedpermission.PermissionListener;
import com.gun0912.tedpermission.TedPermission;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements View.OnClickListener,LocationListener {
    public final static String TAG = "MAIN";


    private ActivityHandler mActivityHandler;

    TextView tv_data;
    ImageView iv_bt,iv_data;
    RelativeLayout layout_bt;
    RelativeLayout layout_setting;
    TextView tv_date;

    Button btn_check_list,btn_check;

    boolean isConn = false;
    public static boolean isAlarm = false;

    LocationManager locationManager;
    boolean isGPSEnabled,isNetworkEnabled;
    Location location;
    Handler handler = new Handler();
    Runnable r = new Runnable() {
        @Override
        public void run() {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd aa hh:mm");
            tv_date.setText(sdf.format(new Date()));
            handler.postDelayed(r, 1000);
          }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        checkPermission();
        mActivityHandler = new ActivityHandler();
        initRes();
        initLocation();
        doStartService();
        handler.post(r);

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        doStopService();
        handler.removeCallbacks(r);
    }

    private BTCTemplateService mService;
    /**
     * Service connection
     */
    private ServiceConnection mServiceConn = new ServiceConnection() {

        public void onServiceConnected(ComponentName className, IBinder binder) {
            Log.d(TAG, "Activity - Service connected");

            mService = ((BTCTemplateService.ServiceBinder) binder).getService();
            mService.connectDevice("HC-06");
            // Activity couldn't work with mService until connections are made
            // So initialize parameters and settings here. Do not initialize while running onCreate()
            initialize();
        }

        public void onServiceDisconnected(ComponentName className) {
            mService = null;
        }
    };

    /**
     * Start service if it's not running
     */
    private void doStartService() {
        Log.d(TAG, "# Activity - doStartService()");
        startService(new Intent(this, BTCTemplateService.class));
        bindService(new Intent(this, BTCTemplateService.class), mServiceConn, Context.BIND_AUTO_CREATE);
    }

    /**
     * Stop the service
     */
    private void doStopService() {
        Log.d(TAG, "# Activity - doStopService()");
        mService.finalizeService();
        stopService(new Intent(this, BTCTemplateService.class));
    }

    @Override
    protected void onStart() {
        super.onStart();
        isAlarm = false;
    }

    /**
     * Initialization / Finalization
     */
    private void initialize() {
        Log.d(TAG, "# Activity - initialize()");
        mService.setupService(mActivityHandler);

        // If BT is not on, request that it be enabled.
        // RetroWatchService.setupBT() will then be called during onActivityResult
        if (!mService.isBluetoothEnabled()) {
            Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableIntent, Constants.REQUEST_ENABLE_BT);
        }


        // Use below timer if you want scheduled job
        //mRefreshTimer = new Timer();
        //mRefreshTimer.schedule(new RefreshTimerTask(), 5*1000);
    }

    private void initRes() {
        layout_setting = (RelativeLayout) findViewById(R.id.layout_setting);
        layout_setting.setOnClickListener(this);

        layout_bt = (RelativeLayout) findViewById(R.id.layout_bt);
        layout_bt.setOnClickListener(this);

        iv_bt = (ImageView) findViewById(R.id.iv_bt);
        iv_data = (ImageView)findViewById(R.id.iv_data);
        iv_data.setOnClickListener(this);
        tv_data = (TextView) findViewById(R.id.tv_data);
        tv_data.setOnClickListener(this);

        tv_date = (TextView)findViewById(R.id.tv_date);

        btn_check_list = (Button) findViewById(R.id.btn_check_list);
        btn_check_list.setOnClickListener(this);
        btn_check = (Button)findViewById(R.id.btn_check);
        btn_check.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        if (view == layout_setting) {
            Intent intent = new Intent(MainActivity.this, SettingActivity.class);
            startActivity(intent);
        } else if (view == layout_bt) {
            if (!isConn) {
                if (mService != null) {
                    mService.connectDevice("HC-06");
                }
            }
        }else if(view == tv_data || view == iv_data){
            Intent intent = new Intent(MainActivity.this, DataListActivity.class);
            startActivity(intent);
        }else if(view == btn_check_list){
            Intent intent = new Intent(MainActivity.this, DataAVGListActivity.class);
            intent.putExtra("id",getIntent().getStringExtra("id"));
            startActivity(intent);
        }else if(view ==  btn_check){
            DataDBAdapter dbAdapter = new DataDBAdapter(this);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            dbAdapter.open();

            Cursor c = dbAdapter.selectCheckEntry();
            int count = 0;
            int sum = 0;
            while(c.moveToNext()){
                sum+= c.getInt(4);
                count++;
            }
            dbAdapter.updateEntry();
            if(count != 0){
                DataAVGDBAdapter dataAVGDBAdapter = new DataAVGDBAdapter(this);
                dataAVGDBAdapter.open();

                dataAVGDBAdapter.createEntry(getIntent().getStringExtra("id"),sdf.format(new Date()),(sum/count)+"");
                dataAVGDBAdapter.close();
            }
            dbAdapter.close();
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        getAddress(this,location.getLatitude(),location.getLongitude());
    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {

    }

    @Override
    public void onProviderEnabled(String s) {

    }

    @Override
    public void onProviderDisabled(String s) {

    }

    /*****************************************************
     *	Handler, Callback, Sub-classes
     ******************************************************/

    public class ActivityHandler extends Handler {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                // Receives BT state messages from service
                // and updates BT state UI
                case Constants.MESSAGE_BT_STATE_INITIALIZED:
                    if (iv_bt != null) {
                        iv_bt.setBackgroundResource(R.drawable.ic_bluetooth_disabled);
                        isConn = false;
                    }
                    break;
                case Constants.MESSAGE_BT_STATE_LISTENING:
                    if (iv_bt != null) {
                        iv_bt.setBackgroundResource(R.drawable.ic_bluetooth_disabled);
                        isConn = false;
                    }
                    break;
                case Constants.MESSAGE_BT_STATE_CONNECTING:
                    if (iv_bt != null) {
                        iv_bt.setBackgroundResource(R.drawable.ic_bluetooth_disabled);
                        isConn = false;
                    }
                    break;
                case Constants.MESSAGE_BT_STATE_CONNECTED:
                    if (iv_bt != null) {
                        iv_bt.setBackgroundResource(R.drawable.ic_bluetooth_on);
                        isConn = true;
                    }
                    if (mService != null) {
                        String deviceName = mService.getDeviceName();
                        if (deviceName != null) {
                            System.out.println("deviceName" + deviceName + "connected");

                        }
                    }
                    break;
                case Constants.MESSAGE_BT_STATE_ERROR:

                    break;

                // BT Command status
                case Constants.MESSAGE_CMD_ERROR_NOT_CONNECTED:

                    break;

                ///////////////////////////////////////////////
                // When there's incoming packets on bluetooth
                // do the UI works like below
                ///////////////////////////////////////////////
                case Constants.MESSAGE_READ_CHAT_DATA:
                    if (msg.obj != null) {
                        byte data = (byte) msg.obj;
                        System.out.println("data" +data);
                        if (tv_data != null) {
                            tv_data.setText("BPM : " + data);
                        }
                        if(data == (byte)0){
                            if(!isAlarm){
                                Messenger messenger = new Messenger(MainActivity.this);
                                if(!BTDoorSharedpreference.getSharedPrefPhone(MainActivity.this).equals(""))
                                    messenger.sendMessageTo(BTDoorSharedpreference.getSharedPrefPhone(MainActivity.this),BTDoorSharedpreference.getSharedPrefMessage(MainActivity.this));
                                if(!BTDoorSharedpreference.getSharedPrefPhone2(MainActivity.this).equals(""))
                                    messenger.sendMessageTo(BTDoorSharedpreference.getSharedPrefPhone2(MainActivity.this),BTDoorSharedpreference.getSharedPrefMessage(MainActivity.this));
                                if(!BTDoorSharedpreference.getSharedPrefPhone3(MainActivity.this).equals(""))
                                     messenger.sendMessageTo(BTDoorSharedpreference.getSharedPrefPhone3(MainActivity.this),BTDoorSharedpreference.getSharedPrefMessage(MainActivity.this));
                                String message = "";
                                message += "위도:"+BTDoorSharedpreference.getSharedPrefLatitude(MainActivity.this);
                                message += "경도:"+BTDoorSharedpreference.getSharedPrefLongitude(MainActivity.this);
                                message += BTDoorSharedpreference.getSharedPrefAddress(MainActivity.this);
                                if(!BTDoorSharedpreference.getSharedPrefPhone(MainActivity.this).equals(""))
                                    messenger.sendMessageTo(BTDoorSharedpreference.getSharedPrefPhone(MainActivity.this),message);
                                if(!BTDoorSharedpreference.getSharedPrefPhone2(MainActivity.this).equals(""))
                                    messenger.sendMessageTo(BTDoorSharedpreference.getSharedPrefPhone2(MainActivity.this),message);
                                if(!BTDoorSharedpreference.getSharedPrefPhone3(MainActivity.this).equals(""))
                                    messenger.sendMessageTo(BTDoorSharedpreference.getSharedPrefPhone3(MainActivity.this),message);


                                Intent intent = new Intent(MainActivity.this,AlarmActivity.class);
                                startActivity(intent);
                                isAlarm = true;
                            }

                        }
                        DataDBAdapter dbAdapter = new DataDBAdapter(MainActivity.this);
                        dbAdapter.open();
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                        dbAdapter.createEntry(getIntent().getStringExtra("id"),sdf.format(new Date()),BTDoorSharedpreference.getSharedPrefLatitude(MainActivity.this)+"",BTDoorSharedpreference.getSharedPrefLongitude(MainActivity.this)+"",data+"");
                        dbAdapter.close();
                    }
                    break;

                default:
                    break;
            }

            super.handleMessage(msg);
        }
    }    // End of class ActivityHandler

    /**
     * 위도,경도로 주소구하기
     *
     * @param lat
     * @param lng
     * @return 주소
     */
    public String getAddress(Context mContext, double lat, double lng) {
        String nowAddress = "현재 위치를 확인 할 수 없습니다.";
        Geocoder geocoder = new Geocoder(mContext, Locale.KOREA);
        List<Address> address;
        try {
            if (geocoder != null) {
                //세번째 파라미터는 좌표에 대해 주소를 리턴 받는 갯수로
                //한좌표에 대해 두개이상의 이름이 존재할수있기에 주소배열을 리턴받기 위해 최대갯수 설정
                address = geocoder.getFromLocation(lat, lng, 1);

                if (address != null && address.size() > 0) {
                    // 주소 받아오기
                    String currentLocationAddress = address.get(0).getAddressLine(0).toString();
                    nowAddress = currentLocationAddress;
                    BTDoorSharedpreference.setSharedPrefLatitude(this,(float)lat);
                    BTDoorSharedpreference.setSharedPrefLongitude(this,(float)lng);
                    BTDoorSharedpreference.setSharedPrefAddress(this,currentLocationAddress);

                }
            }

        } catch (IOException e) {
            Toast.makeText(mContext, "주소를 가져 올 수 없습니다.", Toast.LENGTH_LONG).show();

            e.printStackTrace();
        }
        return nowAddress;
    }

    private void initLocation() {
        locationManager = (LocationManager) this
                .getSystemService(LOCATION_SERVICE);

        // getting GPS status
        isGPSEnabled = locationManager
                .isProviderEnabled(LocationManager.GPS_PROVIDER);

        // getting network status
        isNetworkEnabled = locationManager
                .isProviderEnabled(LocationManager.NETWORK_PROVIDER);

        getLocation();
    }
    public Location getLocation() {
        try {
            if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                return null;
            }

            if (!isGPSEnabled) {
                // no network provider is enabled
            } else {

                if (isNetworkEnabled) {
                    locationManager.requestLocationUpdates(
                            LocationManager.NETWORK_PROVIDER,
                            1000,
                            1, this);
                    Log.d("Network", "Network Enabled");

                }
                if (locationManager != null) {
                    location = locationManager
                            .getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                    if (location != null) {
                        setlatlong(location);
                    }
                }
                // if GPS Enabled get lat/long using GPS Services
                if (isGPSEnabled) {
                    if (location == null) {
                        locationManager.requestLocationUpdates(
                                LocationManager.GPS_PROVIDER,
                                1000,
                                1, this);
                        Log.d("GPS", "GPS Enabled");
                    }
                }
                if (locationManager != null) {
                    location = locationManager
                            .getLastKnownLocation(LocationManager.GPS_PROVIDER);
                    if (location != null) {
                        setlatlong(location);
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return location;
    }

    private void setlatlong(Location location) {
        getAddress(this,location.getLatitude(),location.getLongitude());
    }

    public void checkPermission(){
        TedPermission.with(this)
                .setPermissionListener(permissionlistener)
                .setDeniedMessage("If you reject permission,you can not use this service\n\nPlease turn on permissions at [Setting] > [Permission]")
                .setPermissions(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.SEND_SMS)
                .check();
    }

    PermissionListener permissionlistener = new PermissionListener() {
        @Override
        public void onPermissionGranted() {
         //   Toast.makeText(MainActivity.this, "Permission Granted", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onPermissionDenied(ArrayList<String> deniedPermissions) {
            Toast.makeText(MainActivity.this, "Permission Denied\n" + deniedPermissions.toString(), Toast.LENGTH_SHORT).show();
        }


    };

}
