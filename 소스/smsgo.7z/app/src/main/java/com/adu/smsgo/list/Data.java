package com.adu.smsgo.list;

/**
 * Created by cha's on 2017-09-24.
 */

public class Data {
    String time;
    String gps_x;
    String gps_y;
    String h;

    public Data(String time, String gps_x, String gps_y, String h) {
        this.time = time;
        this.gps_x = gps_x;
        this.gps_y = gps_y;
        this.h = h;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getGps_x() {
        return gps_x;
    }

    public void setGps_x(String gps_x) {
        this.gps_x = gps_x;
    }

    public String getGps_y() {
        return gps_y;
    }

    public void setGps_y(String gps_y) {
        this.gps_y = gps_y;
    }

    public String getH() {
        return h;
    }

    public void setH(String h) {
        this.h = h;
    }
}
