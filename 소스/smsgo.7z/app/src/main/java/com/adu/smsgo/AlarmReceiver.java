package com.adu.smsgo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.widget.Toast;

import com.adu.smsgo.service.Messenger;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class AlarmReceiver extends BroadcastReceiver
{
    @Override
    public void onReceive(Context context, Intent intent)
    {
        //TODO SMS보내기
        Messenger sms = new Messenger(context) ;

        String message = "";
        message += "위도:"+BTDoorSharedpreference.getSharedPrefLatitude(context);
        message += "경도:"+BTDoorSharedpreference.getSharedPrefLongitude(context);
        message += BTDoorSharedpreference.getSharedPrefAddress(context);
        if(!BTDoorSharedpreference.getSharedPrefPhone2(context).equals(""))
         sms.sendMessageTo(BTDoorSharedpreference.getSharedPrefPhone2(context),message);

        if(!BTDoorSharedpreference.getSharedPrefPhone3(context).equals(""))
            sms.sendMessageTo(BTDoorSharedpreference.getSharedPrefPhone3(context),message);
    }



}