package com.alarm.timetable.view;

import android.content.Context;
import android.util.TypedValue;


import android.util.TypedValue;
import android.view.View;



public class ViewUtil {
	public static float dipToPx(Context context, float dip) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dip, context.getResources().getDisplayMetrics());
	}
	

}
