package com.alarm.timetable.view;

import com.alarm.timetable.view.TimeTableView.DAY;
import com.alarm.timetable.view.TimeTableView.TIME;

public class TimeInfo {
	String name;
	private DAY day;
	private TIME time;
	private int color;
	private int index;

	public TimeInfo(String name, DAY day, TIME time, int color, int index) {
		this.name = name;
		this.day = day;
		this.time = time;
		this.color = color;
		this.index = index;
	}

	public DAY getDay() {
		return day;
	}

	public void setDay(DAY day) {
		this.day = day;
	}

	public TIME getTime() {
		return time;
	}

	public void setTime(TIME time) {
		this.time = time;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getColor() {
		return color;
	}

	public void setColor(int color) {
		this.color = color;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}
}
