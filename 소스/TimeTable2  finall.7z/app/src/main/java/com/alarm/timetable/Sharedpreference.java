package com.alarm.timetable;

import android.content.Context;
import android.content.SharedPreferences;



public class Sharedpreference {

	final private static String PREFNAME_TIMETABLE = "TimeTable";

	final private static String PREFKEY_IDX = "index_IDX";

	final private static String PREFKEY_ALARM_IDX = "alarm_IDX";
	public static int getSharedPrefAlarmIDX(Context context){
		SharedPreferences pref = context.getSharedPreferences(PREFNAME_TIMETABLE, Context.MODE_PRIVATE);
		return pref.getInt(PREFKEY_ALARM_IDX,-1);
	}
	public static void setSharedPrefAlarmIDX(Context context, int value){
		SharedPreferences pref = context.getSharedPreferences(PREFNAME_TIMETABLE, Context.MODE_PRIVATE);
		SharedPreferences.Editor prefEditor = pref.edit();
		prefEditor.putInt(PREFKEY_ALARM_IDX, value);
		prefEditor.commit();
	}



	public static int getSharedPrefIDX(Context context){
		SharedPreferences pref = context.getSharedPreferences(PREFNAME_TIMETABLE, Context.MODE_PRIVATE);
		return pref.getInt(PREFKEY_IDX,0);
	}
	public static void setSharedPrefIDX(Context context, int value){
		SharedPreferences pref = context.getSharedPreferences(PREFNAME_TIMETABLE, Context.MODE_PRIVATE);
		SharedPreferences.Editor prefEditor = pref.edit();
		prefEditor.putInt(PREFKEY_IDX, value);
		prefEditor.commit();
	}



}
