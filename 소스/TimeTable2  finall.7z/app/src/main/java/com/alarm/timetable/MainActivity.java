package com.alarm.timetable;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;

import com.alarm.timetable.view.TimeInfo;
import com.alarm.timetable.view.TimeTableView;

import java.util.ArrayList;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    TimeTableView tableView;
    Activity activity;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        activity = this;
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.add);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AddDialog addDialog = new AddDialog(activity);
                addDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialogInterface) {
                        getData();
                        getAlarm();
                    }
                });
                addDialog.show();

            }
        });
        tableView = (TimeTableView)findViewById(R.id.tableView);
        tableView.setClickListener(new TimeTableView.clickListener() {
            @Override
            public void onClick(TimeTableView.DAY day, TimeTableView.TIME time) {
                TimeInfoDBAdapter dbAdapter = new TimeInfoDBAdapter(MainActivity.this);
                dbAdapter.open();
                final Cursor c = dbAdapter.selectEntry(day.name(),time.name());
                Log.e("day.name(),time.name()",day.name()+" "+time.name());
                if(c.moveToNext()){
                    Log.e("day.name(),time.name()",day.name()+" "+time.name()+"true" + c.getInt(0));
                    final SelectDialog selectDialog = new SelectDialog(MainActivity.this,c.getInt(0));
                    selectDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                        @Override
                        public void onDismiss(DialogInterface dialogInterface) {
                            if(selectDialog.nCancel == 0){
                                ModifyDialog modifyDialog = new ModifyDialog(MainActivity.this,c.getInt(0));
                                modifyDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                                    @Override
                                    public void onDismiss(DialogInterface dialogInterface) {
                                        getData();
                                        getAlarm();
                                    }
                                });
                                modifyDialog.show();
                            }else if(selectDialog.nCancel == 1 ){
                                getData();
                                getClearAlarm();
                                getAlarm();
                            }
                        }
                    });
                    selectDialog.show();

                }else{
                    Log.e("day.name(),time.name()",day.name()+" "+time.name()+"false");
                }
            }
        });
        getData();
        getAlarm();
        /*AlarmManager alarmMgr = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent("com.alarm.timetable.ALARM_START");
        intent.putExtra("type",1);
        PendingIntent pi = PendingIntent.getBroadcast(this, 0, intent, 0);
        alarmMgr.setExact(AlarmManager.RTC, System.currentTimeMillis()+10000, pi);*/
    }

    private void getClearAlarm() {
        Alarm alarm = new Alarm();
        alarm.clear(this);
    }

    //알람설정
    private void getAlarm() {
        TimeInfoDBAdapter dbAdapter = new TimeInfoDBAdapter(this);
        dbAdapter.open();
        Calendar c = Calendar.getInstance();
        int day = c.get(Calendar.DAY_OF_WEEK);
        int time = c.get(Calendar.HOUR_OF_DAY);
        day -= 2;
        if(day==-1){
            day = 6;
        }
        Log.e("timeValue",time+"");
        time -= 8;
        if(time>9){
            time = 9;
        }
        int timeValue =day*10+time;

        Log.e("timeValue",timeValue+"");
        Cursor cursor = dbAdapter.selectAlarmEntry(timeValue,Sharedpreference.getSharedPrefIDX(this));
        Alarm alarm = new Alarm();

        if(cursor.moveToNext()){
            Log.e("timeValue",true+"");
            TimeTableView.DAY dayItem= TimeTableView.DAY.valueOf(cursor.getString(1));
            TimeTableView.TIME timeItem = TimeTableView.TIME.valueOf(cursor.getString(2));
            Log.e("timeValuexx",true+""+dayItem.getNumber()+" "+timeItem.ordinal()+8+" "+cursor.getString(2)+" "+cursor.getString(1)+" "+cursor.getInt(6));
            Sharedpreference.setSharedPrefAlarmIDX(this,cursor.getInt(0));
            alarm.setAlarm(this,dayItem.getNumber(),timeItem.ordinal()+8,cursor.getInt(5));
        }else{
            cursor = dbAdapter.fetchAlarmAllEntry();
            if(cursor.moveToNext()){
                Log.e("timeValue",true+"");
                TimeTableView.DAY dayItem= TimeTableView.DAY.valueOf(cursor.getString(1));
                TimeTableView.TIME timeItem = TimeTableView.TIME.valueOf(cursor.getString(2));
                Log.e("timeValuexx",true+""+dayItem.getNumber()+" "+timeItem.ordinal()+8+" "+cursor.getString(2)+" "+cursor.getString(1)+" "+cursor.getInt(6));
                Sharedpreference.setSharedPrefAlarmIDX(this,cursor.getInt(0));
                alarm.setAlarm(this,dayItem.getNumber(),timeItem.ordinal()+8,cursor.getInt(5));
            }
            Log.e("timeValue",false+"");
        }

        dbAdapter.close();
    }

    private void getData() {
        tableView.clearAllSector();
        ArrayList<TimeInfo> alTime = new ArrayList<>();
        TimeInfoDBAdapter dbAdapter = new TimeInfoDBAdapter(this);
        dbAdapter.open();
        Cursor c = dbAdapter.fetchAllEntry();
        while (c.moveToNext()){
            TimeTableView.DAY day = TimeTableView.DAY.valueOf(c.getString(1));
            TimeTableView.TIME time = TimeTableView.TIME.valueOf(c.getString(2));
            alTime.add(new TimeInfo(c.getString(3),day,time,c.getInt(4),c.getInt(0)));
        }
       /* alTime.add(new TimeInfo("abc",TimeTableView.DAY.MON, TimeTableView.TIME._900, Color.RED,1));
        alTime.add(new TimeInfo("abc",TimeTableView.DAY.MON, TimeTableView.TIME._1000,Color.RED,1));
        alTime.add(new TimeInfo("abc2",TimeTableView.DAY.FRI, TimeTableView.TIME._900,Color.GREEN,2));
        alTime.add(new TimeInfo("abc2",TimeTableView.DAY.FRI, TimeTableView.TIME._1000,Color.GREEN,2));*/
        tableView.addTimeInfo(alTime);
        dbAdapter.close();
    }




}
