package com.alarm.timetable;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import java.util.Calendar;

/**
 * Created by cha's on 2017-10-07.
 */

public class Alarm {
    private static final long A_WEEK = 1000 * 60 * 60 * 24 * 7;

    public void setAlarm(Context context, int day, int hour, int type) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        //월부터 시작이므로 2증가후 7일경우 1로 변경
        //월부터 0시작~6까지(일)
        day += 2;
        if (day == 8) {
            day = 1;
        }
        calendar.set(Calendar.DAY_OF_WEEK, day);
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, 0);
    /*calendar.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
    calendar.set(Calendar.HOUR_OF_DAY, 0);
    calendar.set(Calendar.MINUTE, 36);*/
        //Intent intent = new Intent(context, AlarmReceiver.class);
        Intent intent = new Intent("com.alarm.timetable.ALARM_START");
        intent.putExtra("type", type);
        PendingIntent pi = PendingIntent.getBroadcast(context, 0, intent, 0);
        AlarmManager alarmMgr = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        // alarmMgr.cancel(pi);
        System.out.println("time" + calendar.get(Calendar.DAY_OF_MONTH) + " " + calendar.get(Calendar.HOUR_OF_DAY));
        if(System.currentTimeMillis() > calendar.getTimeInMillis()){
            calendar.setTimeInMillis(calendar.getTimeInMillis()+A_WEEK);
        }
        alarmMgr.setExact(AlarmManager.RTC, calendar.getTimeInMillis(), pi);

    }
    public void clear(Context context){
        Intent intent = new Intent("com.alarm.timetable.ALARM_START");
        PendingIntent pi = PendingIntent.getBroadcast(context, 0, intent, 0);
        AlarmManager am = (AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        am.cancel(pi);
    }
}
