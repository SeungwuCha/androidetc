package com.alarm.timetable;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.alarm.timetable.view.TimeTableView;

import java.util.Calendar;

public class AlarmActivity extends AppCompatActivity {
    public static int type = 0;
    TextView tv_title;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarm);
        type = getIntent().getIntExtra("type",-1);
        System.out.println("type"+type);
        tv_title = (TextView)findViewById(R.id.tv_title);
        TimeInfoDBAdapter dbAdapter = new TimeInfoDBAdapter(AlarmActivity.this);
        dbAdapter.open();
        Cursor c = dbAdapter.selectIDXEntry(Sharedpreference.getSharedPrefAlarmIDX(AlarmActivity.this));

        c.moveToNext();
        tv_title.setText(c.getString(3));
        Intent intent = new Intent("android.alarm.go");
        intent.setPackage("com.alarm.timetable");
        startService(intent);
        getAlarm();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Intent intent = new Intent("android.alarm.go");
        intent.setPackage("com.alarm.timetable");
        stopService(intent);
    }
    //알람설정
    private void getAlarm() {
        TimeInfoDBAdapter dbAdapter = new TimeInfoDBAdapter(this);
        dbAdapter.open();
        Calendar c = Calendar.getInstance();
        int day = c.get(Calendar.DAY_OF_WEEK);
        int time = c.get(Calendar.HOUR_OF_DAY);
        day -= 2;
        if(day==-1){
            day = 6;
        }
        Log.e("timeValue",time+"");
        time -= 8;
        if(time>9){
            time = 9;
        }
        int timeValue =day*10+time;

        Log.e("timeValue",timeValue+"");
        Cursor cursor = dbAdapter.selectAlarmEntry(timeValue,Sharedpreference.getSharedPrefIDX(this));
        Alarm alarm = new Alarm();

        if(cursor.moveToNext()){
            Log.e("timeValue",true+"");
            TimeTableView.DAY dayItem= TimeTableView.DAY.valueOf(cursor.getString(1));
            TimeTableView.TIME timeItem = TimeTableView.TIME.valueOf(cursor.getString(2));
            Log.e("timeValuexx",true+""+dayItem.getNumber()+" "+timeItem.ordinal()+8+" "+cursor.getString(2)+" "+cursor.getString(1)+" "+cursor.getInt(6));
            Sharedpreference.setSharedPrefAlarmIDX(this,cursor.getInt(0));
            alarm.setAlarm(this,dayItem.getNumber(),timeItem.ordinal()+8,cursor.getInt(5));
        }else{
            cursor = dbAdapter.fetchAlarmAllEntry();
            if(cursor.moveToNext()){
                Log.e("timeValue",true+"");
                TimeTableView.DAY dayItem= TimeTableView.DAY.valueOf(cursor.getString(1));
                TimeTableView.TIME timeItem = TimeTableView.TIME.valueOf(cursor.getString(2));
                Log.e("timeValuexx",true+""+dayItem.getNumber()+" "+timeItem.ordinal()+8+" "+cursor.getString(2)+" "+cursor.getString(1)+" "+cursor.getInt(6));
                Sharedpreference.setSharedPrefAlarmIDX(this,cursor.getInt(0));
                alarm.setAlarm(this,dayItem.getNumber(),timeItem.ordinal()+8,cursor.getInt(5));
            }
            Log.e("timeValue",false+"");
        }

        dbAdapter.close();
    }
}
