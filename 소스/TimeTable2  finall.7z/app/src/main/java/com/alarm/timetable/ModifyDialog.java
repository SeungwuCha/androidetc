package com.alarm.timetable;

import android.app.Activity;
import android.app.Dialog;
import android.database.Cursor;
import android.graphics.Color;

import android.support.annotation.ColorInt;
import android.support.v7.widget.AppCompatRadioButton;
import android.support.v7.widget.AppCompatSpinner;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.media.AudioManager;//****************************************************소리모드
import android.content.Context;//************************************ 소리모드

import com.alarm.timetable.view.TimeTableView;
import com.pes.androidmaterialcolorpickerdialog.ColorPicker;
import com.pes.androidmaterialcolorpickerdialog.ColorPickerCallback;
//***********************화면 4에 해당 (수정 화면)********************************
public class ModifyDialog extends Dialog implements View.OnClickListener {
	private Activity mContext; //제목
	private EditText name;		//제목 내용

	Button btn_color;		// 색깔

	AppCompatRadioButton radio1,radio2,radio3,radio4;

	int day = 0;
	int ncolor = Color.BLACK;  // 수정시 default 값 (black)
	int idx = 0;


	public ModifyDialog(Activity context, int idx) {
		super(context);
		mContext = context;
		this.idx = idx;
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.modify_dialog);
		TimeInfoDBAdapter dbAdapter = new TimeInfoDBAdapter(mContext);
		dbAdapter.open();
		Cursor c = dbAdapter.selectIDXEntry(idx);
		name = (EditText)findViewById(R.id.add_dialog_name);
		c.moveToNext();
		name.setText(c.getString(3));

		btn_color = (Button)findViewById(R.id.btn_color);
		btn_color.setBackgroundColor(c.getInt(4));
		btn_color.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				final ColorPicker cp = new ColorPicker(mContext, 255, 0, 0, 0);
				cp.setCallback(new ColorPickerCallback() {
					@Override
					public void onColorChosen(@ColorInt int color) {

						btn_color.setBackgroundColor(color);
						ncolor =  color;
						cp.dismiss();
					}
				});

				cp.show();

			}
		});

		int n = c.getInt(5);

		radio1 = (AppCompatRadioButton)findViewById(R.id.radio1);
		radio1.setChecked(n == 0);
		radio2 = (AppCompatRadioButton)findViewById(R.id.radio2);
		radio2.setChecked(n == 1);
		radio3 = (AppCompatRadioButton)findViewById(R.id.radio3);
		radio3.setChecked(n == 2);
		radio4 = (AppCompatRadioButton)findViewById(R.id.radio4);
		radio4.setChecked(n == 3);



		findViewById(R.id.add_dialog_check).setOnClickListener(this);
		findViewById(R.id.add_dialog_exit).setOnClickListener(this);
		dbAdapter.close();

	}

	@Override
	public void onClick(View v) {
		switch(v.getId()) {
			case R.id.add_dialog_check://저장 버튼
				setSave();//저장
				dismiss();
				break;
			case R.id.add_dialog_exit:// 취소 버튼
				dismiss();
				break;
		}
	}

	private void setSave() {//저장

		TimeInfoDBAdapter dbAdapter = new TimeInfoDBAdapter(mContext);
		dbAdapter.open();
		dbAdapter.updateEntry2(idx,name.getText().toString(),ncolor,getRadioState());  //제목 내용, 색깔. 디바이스 모드
		dbAdapter.close();
	}

	private int getRadioState() { //디바이스 모드
		if(radio1.isChecked()){
			return 0;
		}else if(radio2.isChecked()){
			return 1;
		}else if(radio3.isChecked()){
			return 2;
		}

		return 3;
	}



}