package com.alarm.timetable;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.os.Vibrator;

//import android.media.AudioManager;  //이거추가함*************************

public class AlarmService extends Service {
	//private AudioManager myAudioManager; //이거 추가
	private static final String TAG = "AlarmService";
	private MediaPlayer player; // 미디어 플레이어 (알림음 재생)
	private Vibrator vibrator; // 진동 효과
	private boolean isRunning = true; // 진동 효과 플래그

	private int time = 0;
	public static int type = 0;

	@Override
	public IBinder onBind(Intent intent) {

		return null;
	}

	@Override
	public void onCreate() {
		//myAudioManager.setRingerMode(AudioManager.RINGER_MODE_VIBRATE);//*********************
		super.onCreate();

		/*vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
		time = 0;
		try {
			player = MediaPlayer.create(this, R.raw.alarm);

			player.setLooping(true);
			if(AlarmActivity.type == 0) {
				player.start();
			}
		} catch (Exception e) {
			player = null;
		}

		Thread triggerService = new Thread(new Runnable() {

			@Override
			public void run() {
				while (isRunning) {
					try {
						time++;
						//1분후 자동 종료



						if (time >= 30) {
							try {
								// 알람 꺼주기
								Intent intent = new Intent("android.alarm.go");
								intent.setPackage("com.alarm.timetable");
								stopService(intent);
							} catch (Exception e) {

							}

						}
						if(AlarmActivity.type == 1) {
							vibrator.vibrate(1000);
						}
						Thread.sleep(2000);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		});

		triggerService.start();*/
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		if (null != player) {
			player.stop();
			player.release();
			player = null;
		}
		isRunning = false;
		time = 0;
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {

		time = 0;
		System.out.println("type"+type);
		AudioManager am;
		am= (AudioManager) getBaseContext().getSystemService(Context.AUDIO_SERVICE);
		if(type==2) {
			am.setRingerMode(AudioManager.RINGER_MODE_SILENT);
		}else if(type==1){
			am.setRingerMode(AudioManager.RINGER_MODE_VIBRATE);
		}else{
			am.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
		}
		return super.onStartCommand(intent, flags, startId);

	}



}
