package com.alarm.timetable;

import android.app.Activity;

import android.app.Dialog;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Color;
import android.support.annotation.ColorInt;
import android.support.v7.widget.AppCompatRadioButton;
import android.support.v7.widget.AppCompatSpinner;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.media.AudioManager;//****************************************************소리모드


import com.alarm.timetable.view.TimeInfo;
import com.alarm.timetable.view.TimeTableView;
import com.pes.androidmaterialcolorpickerdialog.ColorPicker;
import com.pes.androidmaterialcolorpickerdialog.ColorPickerCallback;

public class AddDialog extends Dialog implements View.OnClickListener {


	private Activity mContext;
	private EditText name;
	private EditText time1;
	private EditText time2;
	private EditText group;



	Button btn_color;

	AppCompatRadioButton radio1,radio2,radio3,radio4;
	AppCompatSpinner spinner;
	int day = 0;
	int ncolor = Color.BLACK;

	public AddDialog(Activity context) {

		super(context);
		mContext = context;
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.add_dialog);

		name = (EditText)findViewById(R.id.add_dialog_name);
		time1 = (EditText)findViewById(R.id.add_dialog_time1);
		time2 = (EditText)findViewById(R.id.add_dialog_time2);

		btn_color = (Button)findViewById(R.id.btn_color);
		btn_color.setBackgroundColor(Color.BLACK);
		btn_color.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				final ColorPicker cp = new ColorPicker(mContext, 255, 0, 0, 0);
				cp.setCallback(new ColorPickerCallback() {
					@Override
					public void onColorChosen(@ColorInt int color) {

						btn_color.setBackgroundColor(color);
						ncolor =  color;
						cp.dismiss();
					}
				});
				cp.show();
			}
		});
		spinner = (AppCompatSpinner)findViewById(R.id.spinner);
		spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
				day = i;
			}

			@Override
			public void onNothingSelected(AdapterView<?> adapterView) {

			}
		});

		radio1 = (AppCompatRadioButton)findViewById(R.id.radio1);
		radio2 = (AppCompatRadioButton)findViewById(R.id.radio2);
		radio3 = (AppCompatRadioButton)findViewById(R.id.radio3);
		radio4 = (AppCompatRadioButton)findViewById(R.id.radio4);




		findViewById(R.id.add_dialog_check).setOnClickListener(this);
		findViewById(R.id.add_dialog_exit).setOnClickListener(this);

	}


	@Override
	public void onClick(View v) {
		switch(v.getId()) {
			case R.id.add_dialog_check:
				if(time1.getText().toString().trim().equals("")){
					Toast.makeText(mContext, "시작 시간을 입력하세요.", Toast.LENGTH_SHORT).show();
				}else if(time2.getText().toString().trim().equals("")){
					Toast.makeText(mContext, "종료 시간을 입력하세요.", Toast.LENGTH_SHORT).show();
				}else {
					int nTime1 = Integer.parseInt(time1.getText().toString().trim());
					int nTime2 = Integer.parseInt(time2.getText().toString().trim());
					if(nTime1 < 9 || nTime1 >= 19 ){	//시작시간 예외처리
						Toast.makeText(mContext, "시작 시간을 잘못입력했습니다.", Toast.LENGTH_SHORT).show();
					}else if(nTime2 < 10 || nTime2 >= 19){	//종료시간 예외처리
						Toast.makeText(mContext, "종료 시간을 잘못입력했습니다.", Toast.LENGTH_SHORT).show();
					}else if(nTime1>nTime2) {      // 시작 시간 > 종료시간
						Toast.makeText(mContext, "시작 시간이 종료 시간보다 큽니다.", Toast.LENGTH_SHORT).show();
					}else if(nTime1==nTime2){
						Toast.makeText(mContext, "시작 시간과 종료 시간이 같습니다.", Toast.LENGTH_SHORT).show();
					}
					else {
						setSave(nTime1,nTime2);
						dismiss();
					}
				}
				break;
			case R.id.add_dialog_exit:
				dismiss();
				break;
		}
	}

	private void setSave(int time1, int time2) {


		TimeInfoDBAdapter dbAdapter = new TimeInfoDBAdapter(mContext);
		dbAdapter.open();
		String strday = TimeTableView.DAY.values()[day].name();
		Toast.makeText(mContext, ""+strday, Toast.LENGTH_SHORT).show();
		int nIdx = Sharedpreference.getSharedPrefIDX(mContext) + 1;
		int nRadio = getRadioState();
		for(int time = time1; time < time2;time++){
			String strTime = TimeTableView.TIME.values()[time-8].name();
			Cursor c = dbAdapter.selectEntry(strday,strTime);
			if(c.moveToNext()){
				dbAdapter.updateEntry(nIdx,strday,strTime,name.getText().toString(),ncolor,nRadio,day*10+time-8);

			}else{
				dbAdapter.createEntry(nIdx,strday,strTime,name.getText().toString(),ncolor,nRadio,day*10+time-8);
			}
			Log.e("strDay",strday);
			Log.e("strTime",strTime);
		}
		Sharedpreference.setSharedPrefIDX(mContext,nIdx);
		dbAdapter.close();
	}

	private int getRadioState() {
		if(radio1.isChecked()){	//소리

			return 0;
		}else if(radio2.isChecked()){ //진동

			return 1;
		}else if(radio3.isChecked()){//무음

			return 2;
		}
		return 3;
	}


}