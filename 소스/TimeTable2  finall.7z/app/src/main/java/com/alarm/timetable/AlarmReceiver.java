package com.alarm.timetable;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Created by csw on 2017-11-08.
 */

public class AlarmReceiver extends BroadcastReceiver{
    @Override
    public void onReceive(Context context, Intent intent) {
        Intent mServiceIntent = new Intent(context,AlarmService.class);
        System.out.println("intent.getIntExtra(\"type\",0)"+intent.getIntExtra("type",0));
        AlarmService.type = intent.getIntExtra("type",0);
        context.startService(mServiceIntent);
    }
}
