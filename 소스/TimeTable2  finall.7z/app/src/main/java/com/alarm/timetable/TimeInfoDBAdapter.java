package com.alarm.timetable;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;
import android.util.Log;

import com.alarm.timetable.view.TimeInfo;

public class TimeInfoDBAdapter {


    private static final String DATABASE_NAME = "timeinfo.db";
    private static final String DATABASE_TABLE = "tb_timeinfo";

    public static final int DATABASE_VERSION = 1;

    private static final String DATABASE_CREATE = "create table "
            + DATABASE_TABLE + " (" + TimeInfoEntry.TimeInfo_IDX
            + " INTEGER, "+ TimeInfoEntry.TimeInfo_DAY
            + " TEXT, "+ TimeInfoEntry.TimeInfo_TIME
            + " TEXT, "+ TimeInfoEntry.TimeInfo_NAME
            + " TEXT, "+ TimeInfoEntry.TimeInfo_COLOR
            + " INTEGER, "+ TimeInfoEntry.TimeInfo_ALARM
            + " INTEGER, "+ TimeInfoEntry.TimeInfo_TIMEVALUE
            + " INTEGER);";
    private static final String TAG = "TimeInfoDBAdapter";

    public String[] COLUMNS = new String[]{TimeInfoEntry.TimeInfo_IDX, TimeInfoEntry.TimeInfo_DAY,
            TimeInfoEntry.TimeInfo_TIME,TimeInfoEntry.TimeInfo_NAME, TimeInfoEntry.TimeInfo_COLOR,TimeInfoEntry.TimeInfo_ALARM, TimeInfoEntry.TimeInfo_TIMEVALUE
    };
    private String[] CountCOLUMNS = new String[]{"count(idx)"
    };
    private Context mContext;
    private TimeInfoDatabaseHelper mDbHelper;
    private SQLiteDatabase mDb;

    public TimeInfoDBAdapter(Context context) {
        mContext = context;
    }

    public TimeInfoDBAdapter open() throws SQLException {
        mDbHelper = new TimeInfoDatabaseHelper(mContext);
        mDb = mDbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        if (mDbHelper != null)
            mDbHelper.close();
    }


    public long createEntry(int idx, String day, String time, String name,int color,int alarm,int timeValue) {
        ContentValues initialValues = new ContentValues();
        initialValues.put(TimeInfoEntry.TimeInfo_IDX,String.valueOf(idx));
        initialValues.put(TimeInfoEntry.TimeInfo_DAY,day);
        initialValues.put(TimeInfoEntry.TimeInfo_TIME,time);
        initialValues.put(TimeInfoEntry.TimeInfo_NAME,name);
        initialValues.put(TimeInfoEntry.TimeInfo_COLOR,color);
        initialValues.put(TimeInfoEntry.TimeInfo_ALARM,alarm);
        initialValues.put(TimeInfoEntry.TimeInfo_TIMEVALUE,timeValue);

        return mDb.insert(DATABASE_TABLE, null, initialValues);
    }

    public long updateEntry(int idx, String day, String time, String name,int color,int alarm,int timeValue) {
        ContentValues initialValues = new ContentValues();
        initialValues.put(TimeInfoEntry.TimeInfo_IDX,String.valueOf(idx));
        initialValues.put(TimeInfoEntry.TimeInfo_DAY,day);
        initialValues.put(TimeInfoEntry.TimeInfo_TIME,time);
        initialValues.put(TimeInfoEntry.TimeInfo_NAME,name);
        initialValues.put(TimeInfoEntry.TimeInfo_COLOR,color);
        initialValues.put(TimeInfoEntry.TimeInfo_ALARM,alarm);
        initialValues.put(TimeInfoEntry.TimeInfo_TIMEVALUE,timeValue);

        return mDb.update(DATABASE_TABLE, initialValues, TimeInfoEntry.TimeInfo_IDX + " = " + idx, null);

    }

    public long updateEntry2(int idx, String name,int color,int alarm) {
        ContentValues initialValues = new ContentValues();
        initialValues.put(TimeInfoEntry.TimeInfo_IDX,String.valueOf(idx));
        initialValues.put(TimeInfoEntry.TimeInfo_NAME,name);
        initialValues.put(TimeInfoEntry.TimeInfo_COLOR,color);
        initialValues.put(TimeInfoEntry.TimeInfo_ALARM,alarm);


        return mDb.update(DATABASE_TABLE, initialValues, TimeInfoEntry.TimeInfo_IDX + " = " + idx, null);

    }


    public Cursor selectIDXEntry(int nIdx) {
        //
        Cursor qu = mDb.query(DATABASE_TABLE, COLUMNS,
                TimeInfoEntry.TimeInfo_IDX + " = " + nIdx,
                null, null, null, null);

        return qu;

    }

    public Cursor selectEntry(String day,String time) {
        //
        Cursor qu = mDb.query(DATABASE_TABLE, COLUMNS,
                TimeInfoEntry.TimeInfo_DAY + " = '" + day+"' and "+TimeInfoEntry.TimeInfo_TIME + " = '" + time+"'",
                null, null, null, null);

        return qu;

    }

    public Cursor selectAlarmEntry(int timevalue,int nIdx) {
        //
        Cursor qu = mDb.query(DATABASE_TABLE, COLUMNS,
                TimeInfoEntry.TimeInfo_TIMEVALUE + " > " + timevalue +" and "+TimeInfoEntry.TimeInfo_IDX + " != " + nIdx +" and "+TimeInfoEntry.TimeInfo_ALARM + " != " + 3 ,
                null, null, null, TimeInfoEntry.TimeInfo_TIMEVALUE+" asc");

        return qu;

    }


    public Cursor fetchAllEntry(int x) {
        return mDb.rawQuery("Select * from " + DATABASE_TABLE + " ORDER BY idx desc LIMIT 12 " + "OFFSET " + (x * 12), null);
    }

    public Cursor fetchAllEntry() {
        //return mDb.rawQuery("Select * from "+DATABASE_TABLE,null);
        return mDb.query(DATABASE_TABLE, COLUMNS, null, null, null, null, TimeInfoEntry.TimeInfo_TIMEVALUE+" asc");
    }

    public Cursor fetchAlarmAllEntry() {
        //return mDb.rawQuery("Select * from "+DATABASE_TABLE,null);
        return mDb.query(DATABASE_TABLE, COLUMNS, null, null, TimeInfoEntry.TimeInfo_ALARM+ "!= 3", null, TimeInfoEntry.TimeInfo_TIMEVALUE+" asc");
    }

    public Cursor countAllEntry() {
        //return mDb.rawQuery("Select * from "+DATABASE_TABLE,null);
        return mDb.query(DATABASE_TABLE, CountCOLUMNS, null, null, null, null, null);
    }




    public int fetchAllEntryLength() {
        return mDb.query(DATABASE_TABLE, COLUMNS, null, null, null, null, null).getCount();
    }

    public void delIDXEntry(int nIdx) {
        mDb.delete(DATABASE_TABLE, TimeInfoEntry.TimeInfo_IDX + "= " + nIdx, null);
    }

    private class TimeInfoDatabaseHelper extends SQLiteOpenHelper {

        public TimeInfoDatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(DATABASE_CREATE);

        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
                    + newVersion + ", which will destory all old data");
            db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
            onCreate(db);
        }

    }





    public class TimeInfoEntry implements BaseColumns {
        //인덱스
        public static final String TimeInfo_IDX = "idx";
        //요일
        public static final String TimeInfo_DAY = "TimeInfo_day";
        //시간
        public static final String TimeInfo_TIME = "TimeInfo_time";
        //내용
        public static final String TimeInfo_NAME = "TimeInfo_name";
        //색상
        public static final String TimeInfo_COLOR = "TimeInfo_color";
        //알람값
        public static final String TimeInfo_ALARM = "TimeInfo_alarm";
        //
        public static final String TimeInfo_TIMEVALUE = "TimeInfo_timevalue";

    }

}
