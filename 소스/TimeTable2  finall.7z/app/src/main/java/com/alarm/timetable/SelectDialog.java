package com.alarm.timetable;

import android.app.Activity;
import android.app.Dialog;
import android.database.Cursor;

import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.pes.androidmaterialcolorpickerdialog.ColorPicker;
import com.pes.androidmaterialcolorpickerdialog.ColorPickerCallback;

//	화면3에 해당
public class SelectDialog extends Dialog implements View.OnClickListener {
	private Activity mContext;

	TextView tv_title;//제목
	Button btn_modify,btn_del,btn_cancel;// 수정, 삭제 , 취소 기능
	int idx = 0;
	int nCancel =  0;

	public SelectDialog(Activity context, int idx) {
		super(context);
		mContext = context;
		this.idx = idx;
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.select_dialog);
		TimeInfoDBAdapter dbAdapter = new TimeInfoDBAdapter(mContext);
		dbAdapter.open();
		Cursor c = dbAdapter.selectIDXEntry(idx);
		c.moveToNext();
		tv_title = (TextView)findViewById(R.id.tv_title);
		tv_title.setText(c.getString(3));
		btn_modify = (Button)findViewById(R.id.btn_modify);
		btn_modify.setOnClickListener(this);
		btn_del =  (Button)findViewById(R.id.btn_del);
		btn_del.setOnClickListener(this);
		btn_cancel = (Button)findViewById(R.id.btn_cancel);
		btn_cancel.setOnClickListener(this);



	}

	@Override
	public void onClick(View v) {  //클릭 이벤트시
		switch(v.getId()) {
			case R.id.btn_modify:  //수정
				nCancel = 0;
				dismiss(); // 화면3 다이얼로그를 종료
				break;
			case R.id.btn_del:		 //삭제
				nCancel = 1;
				setDel();  //삭제함수
				dismiss(); // 화면3 다이얼로그를 종료
				break;
			case R.id.btn_cancel:   //취소
				nCancel = 2;
				dismiss(); // 화면3 다이얼로그를 종료
				break;
		}
	}

	private void setDel() { //삭제 함수
		TimeInfoDBAdapter dbAdapter = new TimeInfoDBAdapter(mContext);
		dbAdapter.open();
		dbAdapter.delIDXEntry(idx);
		dbAdapter.close();
	}






}