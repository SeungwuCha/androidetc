package com.cloth.control;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;
import android.util.Log;

public class PresentDBAdapter {


    private static final String DATABASE_NAME = "data_present.db";
    private static final String DATABASE_TABLE = "tb_data_present";

    public static final int DATABASE_VERSION = 1;


    /*//인덱스
    public static final String Data_IDX = "idx";
    // 회차
    public static final String Data_NO = "data_no";
    // 	회차출력메세지1(사은품)
    public static final String Data_NO_P = "data_no_p";
    // 	회차출력메세지2(브로슈어)
    public static final String Data_NO_B = "data_no_b";
    // 	1회 구매금액
    public static final String Data_NO_WON = "data_no_won";
    // 	1회구매금액별출력메세지(사은품)
    public static final String Data_NO_WON_P = "data_no_won_p";
    // 	누적구매수량
    public static final String Data_TOTAL_NO = "data_total_no";
    // 	누적구매 수량별출력메세지
    public static final String Data_TOTAL_NO_M = "data_total_no_m";
    // 	누적구매금액
    public static final String Data_TOTAL_WON = "data_total_won";
    // 	누적구매 금액별출력메세지
    public static final String Data_TOTAL_WON_M = "data_total_won_m";
    // 	X일
    public static final String Data_DATE = "data_date";
    // 	금액
    public static final String Data_DATE_WON = "data_date_won";
    // 	X일내 재주문시 금액별 출력 메시지1
    public static final String Data_DATE_MESSAGE = "data_date_m";*/
    private static final String DATABASE_CREATE = "create table "
            + DATABASE_TABLE + " (" + DataEntry.Data_IDX
            + " INTEGER AUTO_INCREMENT primary key, " + DataEntry.Data_NO
            + " INTEGER, " + DataEntry.Data_NO_P
            + " TEXT, " + DataEntry.Data_NO_B
            + " TEXT, " + DataEntry.Data_NO_WON
            + " INTEGER, " + DataEntry.Data_NO_WON_P
            + " TEXT, " + DataEntry.Data_TOTAL_NO
            + " INTEGER, " + DataEntry.Data_TOTAL_NO_M
            + " TEXT, " + DataEntry.Data_TOTAL_WON
            + " INTEGER, " + DataEntry.Data_TOTAL_WON_M
            + " TEXT, " + DataEntry.Data_DATE
            + " TEXT, " + DataEntry.Data_DATE_WON
            + " INTEGER, " + DataEntry.Data_DATE_MESSAGE
            + " TEXT);";
    private static final String TAG = "DrivingDBAdapter";

    public String[] COLUMNS = new String[]{DataEntry.Data_IDX, DataEntry.Data_NO,
            DataEntry.Data_NO_P, DataEntry.Data_NO_B, DataEntry.Data_NO_WON, DataEntry.Data_NO_WON_P, DataEntry.Data_TOTAL_NO, DataEntry.Data_TOTAL_NO_M, DataEntry.Data_TOTAL_WON
            , DataEntry.Data_TOTAL_WON_M, DataEntry.Data_DATE, DataEntry.Data_DATE_WON, DataEntry.Data_DATE_MESSAGE
    };

    private String[] CountCOLUMNS = new String[]{"count(idx)"
    };
    private Context mContext;
    private DCTDatabaseHelper mDbHelper;
    private SQLiteDatabase mDb;

    public PresentDBAdapter(Context context) {
        mContext = context;
    }

    public PresentDBAdapter open() throws SQLException {
        mDbHelper = new DCTDatabaseHelper(mContext);
        mDb = mDbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        if (mDbHelper != null)
            mDbHelper.close();
    }

    public long createEntry(String no,String no_p,String no_b,String no_won,String no_won_p,String total_no,String total_no_m,String total_won,String total_won_m,String date,String datewon,String date_m) {
        ContentValues initialValues = new ContentValues();

        initialValues.put(DataEntry.Data_NO, no);
        initialValues.put(DataEntry.Data_NO_P, no_p);
        initialValues.put(DataEntry.Data_NO_B, no_b);
        initialValues.put(DataEntry.Data_NO_WON, no_won);
        initialValues.put(DataEntry.Data_NO_WON_P, no_won_p);
        initialValues.put(DataEntry.Data_TOTAL_NO, total_no);
        initialValues.put(DataEntry.Data_TOTAL_NO_M, total_no_m);
        initialValues.put(DataEntry.Data_TOTAL_WON, total_won);
        initialValues.put(DataEntry.Data_TOTAL_WON_M, total_won_m);
        initialValues.put(DataEntry.Data_DATE, date);
        initialValues.put(DataEntry.Data_DATE_WON, datewon);
        initialValues.put(DataEntry.Data_DATE_MESSAGE, date_m);



        return mDb.insert(DATABASE_TABLE, null, initialValues);
    }


    public Cursor selectNOEntry(int NO) {
        //

        Cursor qu = mDb.query(DATABASE_TABLE, COLUMNS,
                DataEntry.Data_NO + " >= " + NO,
                null, null, null, DataEntry.Data_IDX+" asc");

        return qu;

    }
    public Cursor selectThisMoneyEntry(int money) {
        //

        Cursor qu = mDb.query(DATABASE_TABLE, COLUMNS,
                DataEntry.Data_NO_WON + " <= " + money,
                null, null, null, DataEntry.Data_NO_WON+" desc");

        return qu;

    }

    public Cursor selectTotalEntry(int agototal,int total) {
        //

        Cursor qu = mDb.query(DATABASE_TABLE, COLUMNS,
                DataEntry.Data_TOTAL_NO + " >= " + agototal +" and "+DataEntry.Data_TOTAL_NO + " <= " + total,
                null, null, null, DataEntry.Data_TOTAL_NO+" asc");

        return qu;

    }

    public Cursor selectTotalMoneyEntry(int agototalmoney,int totalMoney) {
        //

        Cursor qu = mDb.query(DATABASE_TABLE, COLUMNS,
                DataEntry.Data_TOTAL_WON + " >= " + agototalmoney +" and "+DataEntry.Data_TOTAL_WON + " <= " + totalMoney,
                null, null, null, DataEntry.Data_TOTAL_NO+" asc");

        return qu;

    }

    public Cursor selectReSellEntry(int day,int money) {
        //

        Cursor qu = mDb.query(DATABASE_TABLE, COLUMNS,
                DataEntry.Data_DATE + " >= " + day +" and "+DataEntry.Data_DATE_WON + " <= " + money+" and "+DataEntry.Data_DATE + " <= " + 30 ,
                null, null, null, DataEntry.Data_DATE+" asc ,"+DataEntry.Data_DATE_WON+" desc"  );

        return qu;

    }


   /* public Cursor selectEntry(String songjangno) {
        //
        Cursor qu = mDb.query(DATABASE_TABLE, COLUMNS,
                DataEntry.Data_SONGJANGNO + " = '" + songjangno+"'",
                null, null, null, null);

        return qu;

    }*/




    public Cursor selectIdxEntry(int nIdx) {
        //
        Cursor qu = mDb.query(DATABASE_TABLE, COLUMNS,
                DataEntry.Data_IDX + " = " + nIdx,
                null, null, null, null);

        return qu;

    }

    public Cursor fetchDateEntry(String date) {
        return mDb.rawQuery("Select * from " + DATABASE_TABLE + " where time LIKE '" + date + "%%'", null);
    }


    public Cursor fetchAllEntry() {
        //return mDb.rawQuery("Select * from "+DATABASE_TABLE,null);
        return mDb.query(DATABASE_TABLE, COLUMNS, null, null, null, null, null);
    }


    public int fetchAllEntryLength() {
        return mDb.query(DATABASE_TABLE, COLUMNS, null, null, null, null, null).getCount();
    }
    public void delALLEntry() {
        mDb.delete(DATABASE_TABLE,null, null);
    }

    public void delIDXEntry(int nIdx) {
        mDb.delete(DATABASE_TABLE, DataEntry.Data_IDX + "= " + nIdx, null);
    }

    private class DCTDatabaseHelper extends SQLiteOpenHelper {

        public DCTDatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(DATABASE_CREATE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
                    + newVersion + ", which will destory all old data");
            db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
            onCreate(db);
        }

    }


    public class DataEntry implements BaseColumns {
        //인덱스
        public static final String Data_IDX = "idx";
        // 회차
        public static final String Data_NO = "data_no";
        // 	회차출력메세지1(사은품)
        public static final String Data_NO_P = "data_no_p";
        // 	회차출력메세지2(브로슈어)
        public static final String Data_NO_B = "data_no_b";
        // 	1회 구매금액
        public static final String Data_NO_WON = "data_no_won";
        // 	1회구매금액별출력메세지(사은품)
        public static final String Data_NO_WON_P = "data_no_won_p";
        // 	누적구매수량
        public static final String Data_TOTAL_NO = "data_total_no";
        // 	누적구매 수량별출력메세지
        public static final String Data_TOTAL_NO_M = "data_total_no_m";
        // 	누적구매금액
        public static final String Data_TOTAL_WON = "data_total_won";
        // 	누적구매 금액별출력메세지
        public static final String Data_TOTAL_WON_M = "data_total_won_m";
        // 	X일
        public static final String Data_DATE = "data_date";
        // 	금액
        public static final String Data_DATE_WON = "data_date_won";
        // 	X일내 재주문시 금액별 출력 메시지1
        public static final String Data_DATE_MESSAGE = "data_date_m";


    }
}