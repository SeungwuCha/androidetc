package com.cloth.control;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.media.AudioManager;
import android.media.SoundPool;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.Html;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.gun0912.tedpermission.PermissionListener;
import com.gun0912.tedpermission.TedPermission;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;
import java.util.regex.Pattern;

import jxl.Sheet;
import jxl.Workbook;
import jxl.format.Alignment;
import jxl.format.Border;
import jxl.format.BorderLineStyle;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;



public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    public ArrayList<Map<String, Object>> data = new ArrayList<Map<String, Object>>();
    EditText edit;
    Button btn_keyboard;
    //출고모드,박스모드
    LinearLayout layout_out, layout_box;
    public static final int STATE_NONE = 0;
    public static final int STATE_BOX = 1;
    public static final int STATE_PRODUCT = 2;
    public static final int STATE_BOX2 = 3;
    int state = STATE_NONE;
    ArrayList<DataItem> alDateItem = new ArrayList<>();
    ArrayList<ProductItem> alProductItem = new ArrayList<>();
    ListView listView;
    DataAdapter adapter;

    String box = "";
    String product = "";

    TextView tv_name;
    TextView tv_id;
    TextView tv_phone1;
    TextView tv_phone2;
    TextView tv_addr;
    TextView tv_count;
    TextView tv_purchase;
    TextView tv_total_money;
    TextView tv_count_avg;
    TextView tv_purchase_avg;
    TextView tv_total_this;
    TextView tv_money_this;
    //제품리스트
    ListView list_product;
    DataProductAdapter dataProductAdapter;

    //선물 리스트
    ListView list_present;
    PresentAdapter presentAdapter;
    ArrayList<PresentItem> alPresent = new ArrayList<>();

    //입력음
    SoundPool mPool;
    int mDDok;
    int mErr;

    Button btn_mode;
    Toolbar toolbar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        checkPermission();
        initRes();
        copyDbFile(this,"data_product.db");


    }

    private void initRes() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle(R.string.app_name);
        setSupportActionBar(toolbar);






        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        SpannableStringBuilder str = new SpannableStringBuilder("기본모드");
        str.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.BOLD), 0, str.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        getSupportActionBar().setTitle(str);
        toolbar.setTitleTextColor(getResources().getColor(R.color.white));
        edit = (EditText) findViewById(R.id.edit);
        edit.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if ((keyCode == KeyEvent.KEYCODE_ENTER)) {
                    System.out.println("key action" + "enter");
                    nextAction(edit.getText().toString());
                    return true;
                }

                return false;
            }
        });
        edit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if(edit.getText().toString().length() >=16){
                    edit.setText("");
                    mPool.play(mErr,1,1,0,0,1);
                }
            }
        });
        layout_out = (LinearLayout) findViewById(R.id.layout_out);

        layout_box = (LinearLayout) findViewById(R.id.layout_box);
        listView = (ListView) findViewById(R.id.list);
        adapter = new DataAdapter(this, alDateItem);
        listView.setAdapter(adapter);
        listView.setTranscriptMode(ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);

        tv_name = (TextView) findViewById(R.id.tv_name);
        tv_id = (TextView) findViewById(R.id.tv_id);
        tv_phone1 = (TextView) findViewById(R.id.tv_phone1);
        tv_phone2 = (TextView) findViewById(R.id.tv_phone2);
        tv_addr = (TextView) findViewById(R.id.tv_addr);
        tv_count = (TextView) findViewById(R.id.tv_count);
        tv_purchase = (TextView) findViewById(R.id.tv_purchase);
        tv_total_money = (TextView) findViewById(R.id.tv_total_money);
        tv_count_avg = (TextView) findViewById(R.id.tv_count_avg);
        tv_purchase_avg = (TextView) findViewById(R.id.tv_purchase_avg);
        tv_total_this = (TextView) findViewById(R.id.tv_total_this);
        tv_money_this = (TextView) findViewById(R.id.tv_money_this);

        list_product = (ListView) findViewById(R.id.list_product);
        dataProductAdapter = new DataProductAdapter(this, alProductItem);
        list_product.setAdapter(dataProductAdapter);
        list_product.setTranscriptMode(ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
        list_present = (ListView) findViewById(R.id.list_present);
        presentAdapter = new PresentAdapter(this, alPresent);
        list_present.setAdapter(presentAdapter);
        list_present.setTranscriptMode(ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);

        btn_keyboard = (Button) findViewById(R.id.btn_keyboard);
        btn_keyboard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                InputMethodManager imm = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
                if (imm.isAcceptingText()) {
                    imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);
                } else {
                    imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, InputMethodManager.HIDE_IMPLICIT_ONLY);
                }
            }
        });
        btn_mode = (Button)findViewById(R.id.btn_mode);
        btn_mode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(state == STATE_BOX){
                    state = STATE_BOX2;
                    SpannableStringBuilder str = new SpannableStringBuilder("재고실사모드 "+box);
                    str.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.BOLD), 0, str.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                    getSupportActionBar().setTitle(str);
                    toolbar.setTitleTextColor(getResources().getColor(R.color.yellow));

                }else if(state == STATE_BOX2){
                    state = STATE_BOX;
                    SpannableStringBuilder str = new SpannableStringBuilder("재고입력모드 "+box);
                    str.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.BOLD), 0, str.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                    getSupportActionBar().setTitle(str);
                    toolbar.setTitleTextColor(getResources().getColor(R.color.white));
                }
                setMode(state);
            }
        });

        mPool = new SoundPool(1, AudioManager.STREAM_MUSIC, 0);
        mDDok = mPool.load(this, R.raw.open_800, 1);
        mErr = mPool.load(this,R.raw.error,1);
        setMode(state);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

       /* long diff = 0;
        try {
            diff = System.currentTimeMillis() - sdf.parse("2017-11-10").getTime();
            ;
        } catch (ParseException e) {
            e.printStackTrace();
        }
        int day = (int)(diff / (24 * 60 * 60 * 1000));
        if(day>30){
            finish();
        }*/



    }


    public void setMode(int state) {
        btn_mode.setVisibility(state == STATE_BOX || state == STATE_BOX2 ? View.VISIBLE : View.GONE);
        layout_box.setVisibility(state == STATE_BOX || state == STATE_BOX2 ? View.VISIBLE : View.GONE);
        layout_out.setVisibility(state == STATE_PRODUCT ? View.VISIBLE : View.GONE);
    }

    private void nextAction(String strText) {
        System.out.println("state : " + state + " " + strText);
        if (state == STATE_NONE) {
            if (strText.length() == 0) {

            } else if (strText.length() == 4 || strText.length() == 5) {
                boolean flag = Pattern.matches("^\\d{1,2}-\\d{2}$", strText);
                if (flag) {
                    box = strText;
                    state = STATE_BOX;
                    setMode(state);
                    SpannableStringBuilder str = new SpannableStringBuilder("재고입력모드 "+box);
                    str.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.BOLD), 0, str.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                    getSupportActionBar().setTitle(str);
                    toolbar.setTitleTextColor(getResources().getColor(R.color.white));

                    edit.setText("");
                } else {
                    Toast.makeText(this, "바코드를 정확히 입력하세요.", Toast.LENGTH_SHORT).show();
                }
            } else if (strText.length() == 12) {
                try {
                    //  Integer.parseInt(strText);
                    product = strText;
                    state = STATE_PRODUCT;
                    setMode(state);
                    getProductData();

                    SpannableStringBuilder str = new SpannableStringBuilder("출고모드 - "+product);
                    str.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.BOLD), 0, str.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                    getSupportActionBar().setTitle(str);
                    toolbar.setTitleTextColor(getResources().getColor(R.color.white));
                    edit.setText("");
                } catch (Exception e) {
                    Toast.makeText(this, "바코드를 정확히 입력하세요.", Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            } else {
                Toast.makeText(this, "바코드를 정확히 입력하세요.", Toast.LENGTH_SHORT).show();
            }
        } else if (state == STATE_BOX) {
            if (strText.length() == 0) {

            } else if (strText.equals(box)) {
                boolean flag = Pattern.matches("^\\d{1,2}-\\d{2}$", strText);
                if (flag) {
                    box = strText;
                    state = STATE_NONE;
                    setMode(state);
                    SpannableStringBuilder str = new SpannableStringBuilder("입력모드");
                    str.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.BOLD), 0, str.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                    getSupportActionBar().setTitle(str);
                    toolbar.setTitleTextColor(getResources().getColor(R.color.white));
                    DataDBAdapter dataDBAdapter = new DataDBAdapter(this);
                    dataDBAdapter.open();
                    for (int i = 0; i < alDateItem.size(); i++) {
                        if (dataDBAdapter.selectEntry(alDateItem.get(i).getNo())) {
                            dataDBAdapter.updateEntry(alDateItem.get(i).getBox(), alDateItem.get(i).getNo());
                        } else {
                            dataDBAdapter.createEntry(alDateItem.get(i).getBox(), alDateItem.get(i).getNo());
                        }
                    }
                    dataDBAdapter.close();
                    edit.setText("");
                    alDateItem.clear();
                    adapter.notifyDataSetChanged();
                } else {
                    Toast.makeText(this, "바코드를 정확히 입력하세요.", Toast.LENGTH_SHORT).show();
                }
            } else if (strText.length() == 8) {
                try {
                    state = STATE_BOX;
                    product = strText;
                    edit.setText("");
                    boolean isExist = isBoxData(strText);
                    if(isExist){
                        mPool.play(mErr, 1, 1, 0, 1, 1);
                    }else {
                        DataDBAdapter dataDBAdapter = new DataDBAdapter(this);
                        dataDBAdapter.open();
                        String strState = "";

                        if (dataDBAdapter.selectEntry(product)) {
                            strState = "(기존)";
                        } else {
                            strState = "(신규)";
                        }

                        dataDBAdapter.close();
                        alDateItem.add(new DataItem(strState,box, product));
                        adapter.notifyDataSetChanged();
                        if (alDateItem.size() % 10 == 0) {
                            mPool.play(mDDok, 1, 1, 0, 1, 1);
                        } else if (alDateItem.size() % 5 == 0) {
                            mPool.play(mDDok, 1, 1, 0, 0, 1);
                        }
                    }
                } catch (Exception e) {
                    Toast.makeText(this, "바코드를 정확히 입력하세요.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "바코드를 정확히 입력하세요.", Toast.LENGTH_SHORT).show();
            }
        } else if (state == STATE_BOX2) {
            if (strText.length() == 0) {

            } else if (strText.equals(box)) {
                boolean flag = Pattern.matches("^\\d{1,2}-\\d{2}$", strText);
                if (flag) {
                    box = strText;
                    state = STATE_NONE;
                    setMode(state);
                    SpannableStringBuilder str = new SpannableStringBuilder("입력모드");
                    str.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.BOLD), 0, str.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                    getSupportActionBar().setTitle(str);
                    toolbar.setTitleTextColor(getResources().getColor(R.color.white));
                    DataDBAdapter dataDBAdapter = new DataDBAdapter(this);
                    dataDBAdapter.open();
                    dataDBAdapter.delEntry(box);

                    for (int i = 0; i < alDateItem.size(); i++) {
                        if (dataDBAdapter.selectEntry(alDateItem.get(i).getNo())) {
                            dataDBAdapter.updateEntry(alDateItem.get(i).getBox(), alDateItem.get(i).getNo());
                        } else {
                            dataDBAdapter.createEntry(alDateItem.get(i).getBox(), alDateItem.get(i).getNo());
                        }
                    }
                    dataDBAdapter.close();
                    edit.setText("");
                    alDateItem.clear();
                    adapter.notifyDataSetChanged();
                } else {
                    Toast.makeText(this, "바코드를 정확히 입력하세요.", Toast.LENGTH_SHORT).show();
                }
            } else if (strText.length() == 8) {
                try {
                    state = STATE_BOX2;
                    product = strText;
                    edit.setText("");
                    boolean isExist = isBoxData(strText);
                    if(isExist){
                        mPool.play(mErr, 1, 1, 0, 1, 1);
                    }else {
                        DataDBAdapter dataDBAdapter = new DataDBAdapter(this);
                        dataDBAdapter.open();
                        String strState = "";
                        if (dataDBAdapter.selectEntry(product)) {
                            strState = "(기존)";
                        } else {
                            strState = "(신규)";
                        }
                        dataDBAdapter.close();
                        alDateItem.add(new DataItem(strState,box, product));
                        adapter.notifyDataSetChanged();
                        if (alDateItem.size() % 10 == 0) {
                            mPool.play(mDDok, 1, 1, 0, 1, 1);
                        } else if (alDateItem.size() % 5 == 0) {
                            mPool.play(mDDok, 1, 1, 0, 0, 1);
                        }
                    }
                } catch (Exception e) {
                    Toast.makeText(this, "바코드를 정확히 입력하세요.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "바코드를 정확히 입력하세요.", Toast.LENGTH_SHORT).show();
            }
        } else if (state == STATE_PRODUCT) {
            if (strText.length() == 0) {

            } else if (strText.length() == 8) {
                DataDBAdapter dataDBAdapter = new DataDBAdapter(this);
                dataDBAdapter.open();
                Cursor c = dataDBAdapter.selectEntry2(strText);
                if (c.moveToNext()) {
                    boolean isExist = isProductData(strText);
                    if(isExist){
                        mPool.play(mErr, 1, 1, 0, 1, 1);
                    }else {
                        alProductItem.add(new ProductItem(product, c.getString(1), strText));
                        System.out.println("c.getString()" + c.getString(2) + " " + c.getString(1));
                        dataProductAdapter.notifyDataSetChanged();
                        edit.setText("");
                        if (alProductItem.size() % 10 == 0) {
                            mPool.play(mDDok, 1, 1, 0, 1, 1);
                        } else if (alProductItem.size() % 5 == 0) {
                            mPool.play(mDDok, 1, 1, 0, 0, 1);
                        }
                    }

                } else {
                    Toast.makeText(this, "바코드를 정확히 입력하세요.", Toast.LENGTH_SHORT).show();
                }
            } else if (strText.equals(product)) {
                Data2DBAdapter data2DBAdapter = new Data2DBAdapter(this);
                data2DBAdapter.open();
                for (ProductItem item : alProductItem) {
                    data2DBAdapter.createEntry(item.getProduct(), item.getNo());
                }
                SpannableStringBuilder str = new SpannableStringBuilder("입력모드");
                str.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.BOLD), 0, str.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                getSupportActionBar().setTitle(str);
                toolbar.setTitleTextColor(getResources().getColor(R.color.white));
                alProductItem.clear();
                dataProductAdapter.notifyDataSetChanged();
                data2DBAdapter.close();
                edit.setText("");
                state = STATE_NONE;
                setMode(state);


            } else {
                Toast.makeText(this, "바코드를 정확히 입력하세요.", Toast.LENGTH_SHORT).show();
            }
        }


    }

    private boolean isBoxData(String strText) {
        boolean isRtn = false;
        for(int i=0;i<alDateItem.size();i++){
            if(alDateItem.get(i).getNo().equals(strText)){
                isRtn = true;
                break;
            }
        }
        return isRtn;
    }

    private boolean isProductData(String strText) {
        boolean isRtn = false;
        for(int i=0;i<alProductItem.size();i++){
            if(alProductItem.get(i).getNo().equals(strText)){
                isRtn = true;
                break;
            }
        }
        return isRtn;
    }


    private void getProductData() {
        ProductDBAdapter dbAdapter = new ProductDBAdapter(this);
        dbAdapter.open();
        Cursor c = dbAdapter.selectEntry(product);
        initProductData();

        if (c.moveToNext()) {

            //1,2,3,4,8
            String name = c.getString(1);
            String name2 = c.getString(2);
            String phone1 = c.getString(3);
            String phone2 = c.getString(4);
            String addr = c.getString(8);
            String id = c.getString(13);
            String date = c.getString(14);
            String state = c.getString(15);
            //고객명
            tv_name.setText(name2);
            //아이디
            tv_id.setText(id);
            //연락처1
            tv_phone1.setText(phone1);
            //연락처2
            tv_phone2.setText(phone2);
            //주소
            tv_addr.setText(addr);
            //기존 구매수량
            //tv_count;=>ok
            // 총 구매 횟수
            //tv_purchase =>ok
            //기존 구매 금액
            //tv_total_money;
            //회당 평균 구매 수량
            //tv_count_avg;
            //회당 평균 구매 금액
            //tv_purchase_avg;
            //금회 구매 수량
            //tv_total_this;
            //금회 구매 금액
            //tv_money_this;
            int money = 0;
            money = c.getInt(9);
            while (c.moveToNext()) {
                money += c.getInt(9);
            }
            tv_total_this.setText("" + c.getCount());
            tv_money_this.setText("" + money);
            Cursor cAllCount = dbAdapter.selectCountEntry2(name, name2, phone1, phone2, addr);
            int totalcount = cAllCount.getCount();
            int totalmoney = 0;
            while (cAllCount.moveToNext()) {
                totalmoney += cAllCount.getInt(9);
            }
            Cursor cCount = dbAdapter.selectCountEntry(name, name2, phone1, phone2, addr);

            System.out.println("cCount" + cCount.getCount());

            int total = 0;
            int count = 0;

            while (cCount.moveToNext()) {
                total = cCount.getInt(0);
                count = cCount.getInt(1);
                System.out.println("total"+total+" count"+count);

            }
            if (cCount.moveToFirst()) {
                total = cCount.getInt(0);
                count = cCount.getInt(1);
                //int count = cCount.getInt(2);
                System.out.println("cCount" + count + " " + total + " ");
                tv_purchase.setText("" + cCount.getCount());
                tv_total_money.setText("" + total);
                tv_count_avg.setText(totalcount / cCount.getCount() + "");
                tv_purchase_avg.setText(totalmoney / cCount.getCount() + "");
            }
            tv_count.setText("" + (cAllCount.getCount()-c.getCount()));

            tv_total_money.setText("" + (totalmoney-money));
            Cursor clastDay = dbAdapter.selectCountEntry3(name, name2, phone1, phone2, addr, product);
            int day = 100;
            if (clastDay.moveToNext()) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

                long diff = 0;
                try {
                    diff = System.currentTimeMillis() - sdf.parse(clastDay.getString(14)).getTime();
                    System.out.println("clastDay.getString(14)" + clastDay.getString(14));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                day = (int) (diff / (24 * 60 * 60 * 1000));

                getPresentData(cCount.getCount(), money, count, totalcount, totalmoney, day);

            }



            //
            //
            /*



            */
        }
    }

    private void initProductData() {
        tv_name.setText("알수없음");
        tv_id.setText("");
        tv_phone1.setText("");
        tv_phone2.setText("");
        tv_addr.setText("");
        tv_count.setText("");
        tv_purchase.setText("");
        tv_total_money.setText("");
        tv_count_avg.setText("");
        tv_purchase_avg.setText("");
        tv_total_this.setText("");
        tv_money_this.setText("");
        alPresent.clear();
        presentAdapter.notifyDataSetChanged();
        setListViewHeightBasedOnChildren(list_present, this);
    }

    public void getPresentData(int no, int money, int count, int total, int totalMoney, int day) {
        PresentDBAdapter dbAdapter = new PresentDBAdapter(this);
        dbAdapter.open();

        Cursor cNo = dbAdapter.selectNOEntry(no);
        alPresent.clear();
        if (cNo.moveToNext()) {
            alPresent.add(new PresentItem(String.format("%d회차 구매 사은품 ▶ %s", no, cNo.getString(2))));
            alPresent.add(new PresentItem(String.format("%d회차 구매 브로슈어 ▶ %s", no, cNo.getString(3))));
            System.out.println("구매고고" + cNo.getCount() + cNo.getString(1));
        }
        Cursor cthisMoney = dbAdapter.selectThisMoneyEntry(money);
        if (cthisMoney.moveToNext()) {
            if (!cthisMoney.getString(5).equals(""))
                alPresent.add(new PresentItem(String.format("금회 구매금액 %d 사은품 ▶ %s", money, cthisMoney.getString(5))));
        }
        Cursor ctotal = dbAdapter.selectTotalEntry(total - count, total);
        while (ctotal.moveToNext()) {
            alPresent.add(new PresentItem(String.format("누적수량 %d 사은품 ▶ %s", total, ctotal.getString(7))));
        }
        Cursor ctotalMoney = dbAdapter.selectTotalMoneyEntry(totalMoney - money, totalMoney);
        while (ctotalMoney.moveToNext()) {
            alPresent.add(new PresentItem(String.format("누적구매 금액 %d 출력메시지 ▶ %s", totalMoney, ctotalMoney.getString(9))));
        }

        Cursor cReSell = dbAdapter.selectReSellEntry(day, money);
        System.out.println("day" + day + " " + money);
        if (cReSell.moveToNext()) {
            alPresent.add(new PresentItem(String.format("%d일이내 재주문 %d이상 출력메시지 ▶ %s", cReSell.getInt(10), cReSell.getInt(11), cReSell.getString(12))));
        }
        presentAdapter.notifyDataSetChanged();
        setListViewHeightBasedOnChildren(list_present, this);

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            if (state == STATE_NONE) {
                super.onBackPressed();
            } else {
                Toast.makeText(this, "일반모드로 변경후 종료 바랍니다.", Toast.LENGTH_SHORT).show();
            }

        }
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.get_box) {
            AlertDialog.Builder dialog = new AlertDialog.Builder(this);
            dialog.setTitle("박스가져오기");
            dialog.setMessage("박스정보를 가져오시겠습니까?");
            dialog.setPositiveButton("예", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                    new BoxTask().execute();
                }
            });
            dialog.setNegativeButton("아니오", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {

                }
            });
            dialog.show();
        } else if (id == R.id.out_box) {
            AlertDialog.Builder dialog = new AlertDialog.Builder(this);
            dialog.setTitle("박스내보오기");
            dialog.setMessage("현재 박스정보를 내보내시겠습니까?");
            dialog.setPositiveButton("예", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                    write2();
                }
            });
            dialog.setNegativeButton("아니오", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {

                }
            });
            dialog.show();
        } else if (id == R.id.get_order) {
            AlertDialog.Builder dialog = new AlertDialog.Builder(this);
            dialog.setTitle("주문내역가져오기");
            dialog.setMessage("주문내역을 가져오시겠습니까?");
            dialog.setPositiveButton("예", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                    new OrderTask().execute();
                }
            });
            dialog.setNegativeButton("아니오", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {

                }
            });
            dialog.show();
        } else if (id == R.id.get_output) {
            AlertDialog.Builder dialog = new AlertDialog.Builder(this);
            dialog.setTitle("출력메시지");
            dialog.setMessage("출력메시지를 가져오시겠습니까?");
            dialog.setPositiveButton("예", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                    new OutputTask().execute();
                }
            });
            dialog.setNegativeButton("아니오", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {

                }
            });
            dialog.show();
        }else if(id == R.id.get_go){
            if(state == STATE_BOX){
                state = STATE_BOX2;
                SpannableStringBuilder str = new SpannableStringBuilder("재고실사모드 "+box);
                str.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.BOLD), 0, str.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                getSupportActionBar().setTitle(str);

                toolbar.setTitleTextColor(getResources().getColor(R.color.yellow));
            }else if(state == STATE_BOX2){
                state = STATE_BOX;
                SpannableStringBuilder str = new SpannableStringBuilder("재고입력모드 "+box);
                str.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.BOLD), 0, str.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                getSupportActionBar().setTitle(str);
                toolbar.setTitleTextColor(getResources().getColor(R.color.white));
            }
            setMode(state);
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public void checkPermission() {
        TedPermission.with(this)
                .setPermissionListener(permissionlistener)
                .setDeniedMessage("If you reject permission,you can not use this service\n\nPlease turn on permissions at [Setting] > [Permission]")
                .setPermissions(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                .check();
    }

    PermissionListener permissionlistener = new PermissionListener() {
        @Override
        public void onPermissionGranted() {
            //    Toast.makeText(MainActivity.this, "Permission Granted", Toast.LENGTH_SHORT).show();

            //  getDataOrder();
            // write();
        }

        @Override
        public void onPermissionDenied(ArrayList<String> deniedPermissions) {
            Toast.makeText(MainActivity.this, "Permission Denied\n" + deniedPermissions.toString(), Toast.LENGTH_SHORT).show();
        }


    };

    public void write() {

        try {
            System.out.println("getData Start Excel Write");
            // WorkBook 생성
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmm");
            File fDir = new File(Environment.getExternalStorageDirectory()+"/control/");
            if(!fDir.exists()){
                fDir.mkdirs();
            }
            File f = new File(Environment.getExternalStorageDirectory() + "/control/box" + sdf.format(new Date()) + ".xls");
            WritableWorkbook wb = Workbook.createWorkbook(f);

            // WorkSheet 생성
            WritableSheet sh = wb.createSheet("sheet0", 0);
            WritableSheet sh2 = wb.createSheet("sheet1", 1);

            // 열넓이 설정 (열 위치, 넓이)
           /* sh.setColumnView(0, 20);
            sh.setColumnView(1, 20);
            sh.setColumnView(2, 15);
            sh.setColumnView(3, 50);*/


            // 셀형식
            WritableCellFormat textFormat = new WritableCellFormat();
            // 생성
            textFormat.setAlignment(Alignment.LEFT);
            // 테두리
            textFormat.setBorder(Border.ALL, BorderLineStyle.THIN);

            int row = 0;

            Label label;

            // 헤더
            label = new jxl.write.Label(0, row, "재고", textFormat);
            sh.addCell(label);

            label = new jxl.write.Label(1, row, "BOX", textFormat);
            sh.addCell(label);


            row++;
            DataDBAdapter dbAdapter = new DataDBAdapter(this);
            dbAdapter.open();
            Cursor c = dbAdapter.fetchAllEntry();

            while (c.moveToNext()) {
                label = new jxl.write.Label(0, row, (String) c.getString(1),
                        textFormat);
                sh.addCell(label);

                // 링크
                label = new jxl.write.Label(1, row, (String) c.getString(2),
                        textFormat);
                sh.addCell(label);

                row++;
            }
            row = 0;
            Data2DBAdapter dbAdapter2 = new Data2DBAdapter(this);
            dbAdapter2.open();
            c = dbAdapter2.fetchAllEntry();
            label = new jxl.write.Label(0, row, "송장번호", textFormat);
            sh2.addCell(label);

            label = new jxl.write.Label(1, row, "출하품", textFormat);
            sh2.addCell(label);
            while (c.moveToNext()) {
                label = new jxl.write.Label(0, row, (String) c.getString(2),
                        textFormat);
                sh2.addCell(label);

                // 링크
                label = new jxl.write.Label(1, row, (String) c.getString(1),
                        textFormat);
                sh2.addCell(label);

                row++;
            }


            // WorkSheet 쓰기
            wb.write();

            // WorkSheet 닫기
            wb.close();
            System.out.println("getData Save Excel Done");


        } catch (Exception ex) {
            System.out.println(ex);
            ex.printStackTrace();
        }
    }

    public void write2() {

        try {
            System.out.println("getData Start Excel Write");
            // WorkBook 생성
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmm");
            File fDir = new File(Environment.getExternalStorageDirectory()+"/control/");
            if(!fDir.exists()){
                fDir.mkdirs();
            }
            File f = new File(Environment.getExternalStorageDirectory() + "/control/box" + sdf.format(new Date()) + ".xls");
            WritableWorkbook wb = Workbook.createWorkbook(f);

            // WorkSheet 생성
            WritableSheet sh = wb.createSheet("sheet0", 0);
            WritableSheet sh2 = wb.createSheet("sheet1", 1);

            // 열넓이 설정 (열 위치, 넓이)
           /* sh.setColumnView(0, 20);
            sh.setColumnView(1, 20);
            sh.setColumnView(2, 15);
            sh.setColumnView(3, 50);*/


            // 셀형식
            WritableCellFormat textFormat = new WritableCellFormat();
            // 생성
            textFormat.setAlignment(Alignment.LEFT);
            // 테두리
            textFormat.setBorder(Border.ALL, BorderLineStyle.THIN);

            int row = 0;

            Label label;


            // 헤더
            label = new jxl.write.Label(0, row, "재고", textFormat);
            sh.addCell(label);

            label = new jxl.write.Label(1, row, "BOX", textFormat);
            sh.addCell(label);


            row++;
            DataDBAdapter dbAdapter = new DataDBAdapter(this);
            dbAdapter.open();
            Cursor c = dbAdapter.fetchAllEntry();

            while (c.moveToNext()) {
                label = new jxl.write.Label(0, row, (String) c.getString(1),
                        textFormat);
                sh.addCell(label);

                // 링크
                label = new jxl.write.Label(1, row, (String) c.getString(2),
                        textFormat);
                sh.addCell(label);

                row++;
            }
            row = 0;
            Data2DBAdapter dbAdapter2 = new Data2DBAdapter(this);
            dbAdapter2.open();
            c = dbAdapter2.fetchAllEntry();
            label = new jxl.write.Label(0, row, "송장번호", textFormat);
            sh2.addCell(label);

            label = new jxl.write.Label(1, row, "출하품", textFormat);
            sh2.addCell(label);

            while (c.moveToNext()) {
                label = new jxl.write.Label(0, row, (String) c.getString(2),
                        textFormat);
                sh2.addCell(label);

                // 링크
                label = new jxl.write.Label(1, row, (String) c.getString(1),
                        textFormat);
                sh2.addCell(label);

                row++;
            }


            // WorkSheet 쓰기
            wb.write();

            // WorkSheet 닫기
            wb.close();
            System.out.println("getData Save Excel Done");
            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_SUBJECT, "");
            intent.putExtra(Intent.EXTRA_STREAM, Uri.parse("file://" + f.getPath()));
            intent.putExtra(Intent.EXTRA_TEXT, "box내보내기");
            intent.setData(Uri.parse("mailto:"));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            startActivity(intent);

        } catch (Exception ex) {
            System.out.println(ex);
            ex.printStackTrace();
        }

    }

    public void getData() {
        File file = new File(Environment.getExternalStorageDirectory() + "/box.xls");
        System.out.println("getData Start");
        try {

            // 엑셀파일 워크북 객체 생성
            Workbook workbook = Workbook.getWorkbook(file);

            // 시트 지정
            Sheet sheet = workbook.getSheet(0);

            // 행 길이
            int endIdx = sheet.getColumn(1).length - 1;

            System.out.println("getData Start" + endIdx);
            DataDBAdapter dataAdapter = new DataDBAdapter(this);
            dataAdapter.open();
            dataAdapter.ALLDEL();
            for (int i = 1; i <= endIdx; i++) {

                // 첫번째 열(A)
                String no = sheet.getCell(0, i).getContents();

                // 두번째 열(B)
                String box = sheet.getCell(1, i).getContents();
                dataAdapter.createEntry(no, box);

            }
            System.out.println("getData End");

            // 시트 지정
            sheet = workbook.getSheet(1);

            // 행 길이
            endIdx = sheet.getColumn(1).length - 1;

            System.out.println("getData Start" + endIdx);
            Data2DBAdapter data2Adapter = new Data2DBAdapter(this);
            data2Adapter.open();
            data2Adapter.ALLDEL();
            for (int i = 1; i <= endIdx; i++) {

                // 첫번째 열(A)
                String no = sheet.getCell(0, i).getContents();

                // 두번째 열(B)
                String box = sheet.getCell(1, i).getContents();
                data2Adapter.createEntry(no, box);

            }
            System.out.println("getData End");

        } catch (BiffException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }


    public void getDataOrder() {
        File file = new File(Environment.getExternalStorageDirectory() + "/주문내역.xls");
        System.out.println("getData Start");
        ProductDBAdapter productDBAdapter = new ProductDBAdapter(this);
        productDBAdapter.open();
        productDBAdapter.delALLEntry();
        try {

            // 엑셀파일 워크북 객체 생성
            Workbook workbook = Workbook.getWorkbook(file);

            // 시트 지정
            Sheet sheet = workbook.getSheet(0);

            // 행 길이
            int endIdx = sheet.getColumn(1).length - 1;

            System.out.println("getData Start" + endIdx);
            for (int i = 1; i <= endIdx; i++) {
                /*구매자명31
구매자전화번호32
구매자휴대폰번호33
수령자명34
수령자전화번호35
수령자휴대폰번호36
주문일6
배송지주소38
판매가21
판매사이트주문번호11
판매사이트상품코드12
송장번호41
구매자 ID 30
주문일 6
상태 10
*/
                // 구매자명
                String name = sheet.getCell(31, i).getContents();
                // 수령자명
                String name2 = sheet.getCell(34, i).getContents();
                // 구매자 전화번호
                String phone1 = sheet.getCell(32, i).getContents();
                // 구매자 휴대전화
                String phone2 = sheet.getCell(33, i).getContents();
                // 수령자 전화번호
                String phone3 = sheet.getCell(35, i).getContents();
                // 수령자 휴대전화
                String phone4 = sheet.getCell(36, i).getContents();
                // 주문일
                String date = sheet.getCell(6, i).getContents();
                // 주소
                String addr = sheet.getCell(38, i).getContents();
                // 판매가
                String won = sheet.getCell(21, i).getContents();
                // 주문번호
                String no = sheet.getCell(11, i).getContents();
                // 상품코드
                String code = sheet.getCell(12, i).getContents();
                // 송장번호
                String songjangno = sheet.getCell(41, i).getContents();
                String cid = sheet.getCell(30, i).getContents();
                String cdate = sheet.getCell(6, i).getContents();
                String cstate = sheet.getCell(10, i).getContents();
                productDBAdapter.createEntry(name, name2, phone1, phone2, phone3, phone4, date, addr, won, no, code, songjangno, cid, cdate, cstate);


                //  System.out.println("getname"+ name+"i");


            }
            System.out.println("getData End");
            productDBAdapter.close();
        } catch (BiffException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    public void getOutput() {
        File file = new File(Environment.getExternalStorageDirectory() + "/출력메세지조건.xls");
        System.out.println("getOutData Start");
        PresentDBAdapter presentDBAdapter = new PresentDBAdapter(this);
        presentDBAdapter.open();
        presentDBAdapter.delALLEntry();
        try {

            // 엑셀파일 워크북 객체 생성
            Workbook workbook = Workbook.getWorkbook(file);

            // 시트 지정
            Sheet sheet = workbook.getSheet(0);

            // 행 길이
            int endIdx = sheet.getColumn(0).length - 1;

            System.out.println("getData Start" + endIdx);
            for (int i = 1; i <= endIdx; i++) {
                //회차
                String Data_NO = sheet.getCell(0, i).getContents().substring(0, sheet.getCell(0, i).getContents().length() - 2);
                System.out.println("data_no" + Data_NO);
                //회차 출력메시지1(사은품)
                String Data_NO_P = sheet.getCell(1, i).getContents();
                //회차 출력메시지2(브로슈어)
                String Data_NO_B = sheet.getCell(2, i).getContents();
                //1회 구매금액
                String Data_NO_WON = sheet.getCell(3, i).getContents();
                //1회 구매금액별 출력메시지(사은품)
                String Data_NO_WON_P = sheet.getCell(4, i).getContents();
                //누적구매수량
                String Data_TOTAL_NO = sheet.getCell(5, i).getContents();
                //누적구매 수량별 출력메시지
                String Data_TOTAL_NO_M = sheet.getCell(6, i).getContents();
                //누적구매금액
                String Data_TOTAL_WON = sheet.getCell(7, i).getContents();
                //누적구매금액별 출력메시지
                String Data_TOTAL_WON_M = sheet.getCell(8, i).getContents();
                //x일
                String Data_DATE = sheet.getCell(9, i).getContents();
                //금액
                String Data_DATE_WON = sheet.getCell(10, i).getContents();
                //x일내 금액별 출력메시지1
                String Data_DATE_MESSAGE = sheet.getCell(11, i).getContents();

                presentDBAdapter.createEntry(Data_NO, Data_NO_P, Data_NO_B, Data_NO_WON, Data_NO_WON_P, Data_TOTAL_NO, Data_TOTAL_NO_M, Data_TOTAL_WON, Data_TOTAL_WON_M, Data_DATE, Data_DATE_WON, Data_DATE_MESSAGE);


                //  System.out.println("getname"+ name+"i");


            }
            System.out.println("getData End");
            presentDBAdapter.close();
        } catch (BiffException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    private class OutputTask extends AsyncTask<String, Void, String> {
        LodingDialog mLoding = new LodingDialog(MainActivity.this, "로딩중");
        String mStrCmd = "";


        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            if (mLoding != null) {
                mLoding.dismiss();
                mLoding.show();
                mLoding.setCancelable(false);
            }
        }


        @Override
        protected String doInBackground(String... params) {
            String strRtn = null;

            getOutput();

            return strRtn;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            if (mLoding != null) {
                mLoding.dismiss();
                mLoding = null;
            }


        }
    }

    private class OrderTask extends AsyncTask<String, Void, String> {
        LodingDialog mLoding = new LodingDialog(MainActivity.this, "로딩중");
        String mStrCmd = "";


        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            if (mLoding != null) {
                mLoding.dismiss();
                mLoding.show();
                mLoding.setCancelable(false);
            }
        }


        @Override
        protected String doInBackground(String... params) {
            String strRtn = null;

            getDataOrder();

            return strRtn;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            if (mLoding != null) {
                mLoding.dismiss();
                mLoding = null;
            }


        }
    }

    private class BoxTask extends AsyncTask<String, Void, String> {
        LodingDialog mLoding = new LodingDialog(MainActivity.this, "로딩중");
        String mStrCmd = "";


        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            if (mLoding != null) {
                mLoding.dismiss();
                mLoding.show();
                mLoding.setCancelable(false);
            }
        }


        @Override
        protected String doInBackground(String... params) {
            String strRtn = null;
            write();
            getData();


            return strRtn;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            if (mLoding != null) {
                mLoding.dismiss();
                mLoding = null;
            }


        }
    }

    public static void setListViewHeightBasedOnChildren(ListView listView, Context context) {
        ListAdapter listAdapter = listView.getAdapter();
        if (listAdapter == null) {
            // pre-condition
            return;
        }

        int totalHeight = 0;

        int desiredWidth = View.MeasureSpec.makeMeasureSpec(listView.getWidth(), View.MeasureSpec.AT_MOST);
        for (int i = 0; i < listAdapter.getCount(); i++) {
            View listItem = listAdapter.getView(i, null, listView);
            //listItem.measure(0, 0);
            listItem.measure(desiredWidth, View.MeasureSpec.UNSPECIFIED);
            totalHeight += convertDpToPixel(30, context);
        }
        ViewGroup.LayoutParams params = listView.getLayoutParams();
        if (totalHeight > convertDpToPixel(120, context)) {
            totalHeight = (int) convertDpToPixel(120, context);
        }
        params.height = totalHeight;
        listView.setLayoutParams(params);

        listView.requestLayout();
    }

    public static float convertDpToPixel(float dp, Context context) {
        Resources resources = context.getResources();
        DisplayMetrics metrics = resources.getDisplayMetrics();
        float px = dp * (metrics.densityDpi / 160f);
        return px;
    }

    public static void copyDbFile(Context context, String dbname) {
        Log.i(context.getClass().getName(), "copyDbFile();");

        File fromFile = new File(Environment.getDataDirectory() + "/data/" + context.getPackageName() + "/databases/" + dbname);
        File toFile = new File(Environment.getExternalStorageDirectory() + "/" + dbname);
        FileOutputStream fos = null;
        BufferedOutputStream bos = null;


        try {

            InputStream is = new FileInputStream(fromFile);

            if (!toFile.exists()) {
                toFile.createNewFile();
            }
            fos = new FileOutputStream(toFile);
            bos = new BufferedOutputStream(fos);

            int read = -1;
            byte[] buffer = new byte[1024];
            while ((read = is.read(buffer, 0, 1024)) != -1) {
                bos.write(buffer, 0, read);
            }
            bos.flush();

            fos.close();
            bos.close();
            is.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
