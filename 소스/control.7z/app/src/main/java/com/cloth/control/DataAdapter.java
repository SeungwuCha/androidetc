package com.cloth.control;

import android.content.Context;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by roadpia_000 on 2017-01-18.
 */

public class DataAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<DataItem> items = null;
    private LayoutInflater layoutInflater = null;



    Handler handler;

    public void setHandler(Handler handler) {
        this.handler = handler;
    }

    public DataAdapter(Context context, ArrayList<DataItem> items) {
        this.context = context;
        this.items = items;
        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);


    }

    public class ViewHolder {

        TextView tv_box,tv_no,tv_idx,tv_state;
    }

    public void setItem(ArrayList<DataItem> items) {
        this.items = items;
        this.notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        DataAdapter.ViewHolder viewHolder = new DataAdapter.ViewHolder();
        if (convertView == null) {
            convertView = layoutInflater.inflate(R.layout.item_data, parent, false);

            viewHolder.tv_idx = (TextView) convertView.findViewById(R.id.tv_idx);
            viewHolder.tv_box = (TextView) convertView.findViewById(R.id.tv_box);
            viewHolder.tv_no = (TextView) convertView.findViewById(R.id.tv_no);
            viewHolder.tv_state = (TextView) convertView.findViewById(R.id.tv_state);



            convertView.setTag(viewHolder);
        } else {
            viewHolder = (DataAdapter.ViewHolder) convertView.getTag();
        }

        DataItem item = items.get(position);
        viewHolder.tv_idx.setText((position+1)+"");
        viewHolder.tv_state.setText(item.getState());
        viewHolder.tv_box.setText(item.getBox());
        viewHolder.tv_no.setText(item.getNo());


        return convertView;
    }


}



