package com.cloth.control;

import android.content.Context;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by roadpia_000 on 2017-01-18.
 */

public class PresentAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<PresentItem> items = null;
    private LayoutInflater layoutInflater = null;



    Handler handler;

    public void setHandler(Handler handler) {
        this.handler = handler;
    }

    public PresentAdapter(Context context, ArrayList<PresentItem> items) {
        this.context = context;
        this.items = items;
        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);


    }

    public class ViewHolder {

        TextView tv_content;
    }

    public void setItem(ArrayList<PresentItem> items) {
        this.items = items;
        this.notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        PresentAdapter.ViewHolder viewHolder = new PresentAdapter.ViewHolder();
        if (convertView == null) {
            convertView = layoutInflater.inflate(R.layout.item_present, parent, false);


            viewHolder.tv_content = (TextView) convertView.findViewById(R.id.tv_content);



            convertView.setTag(viewHolder);
        } else {
            viewHolder = (PresentAdapter.ViewHolder) convertView.getTag();
        }

        PresentItem item = items.get(position);
        viewHolder.tv_content.setText(item.getContent());



        return convertView;
    }


}



