package com.cloth.control;

/**
 * Created by csw on 2017-10-11.
 */
public class PresentItem {

    String content;

    public PresentItem(String content) {
        this.content = content;

    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
