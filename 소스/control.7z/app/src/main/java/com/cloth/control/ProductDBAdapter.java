package com.cloth.control;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;
import android.util.Log;

public class ProductDBAdapter {


    private static final String DATABASE_NAME = "data_product.db";
    private static final String DATABASE_TABLE = "tb_data_product";

    public static final int DATABASE_VERSION = 2;
    /*//인덱스
    public static final String Data_IDX = "idx";
    //구매자명
    public static final String Data_NAME = "name";
    //수령자명
    public static final String Data_NAME2 = "name2";
    //구매자 전화번호
    public static final String Data_PHONE1 = "phone1";
    //구매자 휴대전화
    public static final String Data_PHONE2 = "phone2";
    //수령자 전화번호
    public static final String Data_PHONE3 = "phone3";
    //수령자 휴대전화
    public static final String Data_PHONE4 = "phone4";
    //주문일
    public static final String Data_DATE = "date";
    //주소
    public static final String Data_ADDR = "addr";
    //총판매가
    public static final String Data_WON = "won";
    // 주문번호
    public static final String Data_NO = "no";
    // 상품코드
    public static final String Data_CODE = "code";*/
    private static final String DATABASE_CREATE = "create table "
            + DATABASE_TABLE + " (" + DataEntry.Data_IDX
            + " INTEGER AUTO_INCREMENT primary key, " + DataEntry.Data_NAME
            + " TEXT, " + DataEntry.Data_NAME2
            + " TEXT, " + DataEntry.Data_PHONE1
            + " TEXT, " + DataEntry.Data_PHONE2
            + " TEXT, " + DataEntry.Data_PHONE3
            + " TEXT, " + DataEntry.Data_PHONE4
            + " TEXT, " + DataEntry.Data_DATE
            + " TEXT, " + DataEntry.Data_ADDR
            + " TEXT, " + DataEntry.Data_WON
            + " INTEGER, " + DataEntry.Data_NO
            + " TEXT, " + DataEntry.Data_CODE
            + " TEXT, " + DataEntry.Data_SONGJANGNO
            + " TEXT, " + DataEntry.Data_CID//13
            + " TEXT, " + DataEntry.Data_C_DATE//14
            + " TEXT, " + DataEntry.Data_C_STATE//15
            + " TEXT);";

    private static final String TAG = "DrivingDBAdapter";

    public String[] COLUMNS = new String[]{DataEntry.Data_IDX, DataEntry.Data_NAME,
            DataEntry.Data_NAME2, DataEntry.Data_PHONE1, DataEntry.Data_PHONE2, DataEntry.Data_PHONE3, DataEntry.Data_PHONE4, DataEntry.Data_DATE, DataEntry.Data_ADDR
            , DataEntry.Data_WON, DataEntry.Data_NO, DataEntry.Data_CODE,DataEntry.Data_SONGJANGNO,DataEntry.Data_CID,DataEntry.Data_C_DATE,DataEntry.Data_C_STATE
    };
    public String[] COLUMNSUM = new String[]{/*DataEntry.Data_IDX, DataEntry.Data_NAME,
            DataEntry.Data_NAME2, DataEntry.Data_PHONE1, DataEntry.Data_PHONE2, DataEntry.Data_PHONE3, DataEntry.Data_PHONE4, DataEntry.Data_DATE, DataEntry.Data_ADDR
            , DataEntry.Data_WON, DataEntry.Data_NO, DataEntry.Data_CODE,*/"sum("+DataEntry.Data_WON+")","COUNT(songjangno)"
    };
    private String[] CountCOLUMNS = new String[]{"count(idx)"
    };
    private Context mContext;
    private DCTDatabaseHelper mDbHelper;
    private SQLiteDatabase mDb;

    public ProductDBAdapter(Context context) {
        mContext = context;
    }

    public ProductDBAdapter open() throws SQLException {
        mDbHelper = new DCTDatabaseHelper(mContext);
        mDb = mDbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        if (mDbHelper != null)
            mDbHelper.close();
    }


    public long createEntry(String name, String name2, String phone1, String phone2, String phone3, String phone4, String date, String addr, String won, String no, String code,String sangjangno,String cid,String cdate,String cstate) {
        ContentValues initialValues = new ContentValues();

        initialValues.put(DataEntry.Data_NAME, name);
        initialValues.put(DataEntry.Data_NAME2, name2);
        initialValues.put(DataEntry.Data_PHONE1, phone1);
        initialValues.put(DataEntry.Data_PHONE2, phone2);
        initialValues.put(DataEntry.Data_PHONE3, phone3);
        initialValues.put(DataEntry.Data_PHONE4, phone4);
        initialValues.put(DataEntry.Data_DATE, date);
        initialValues.put(DataEntry.Data_ADDR, addr);
        initialValues.put(DataEntry.Data_WON, won);
        initialValues.put(DataEntry.Data_NO, no);
        initialValues.put(DataEntry.Data_CODE, code);
        initialValues.put(DataEntry.Data_SONGJANGNO, sangjangno);
        initialValues.put(DataEntry.Data_CID,cid);
        initialValues.put(DataEntry.Data_C_DATE,cdate);
        initialValues.put(DataEntry.Data_C_STATE,cstate);

        return mDb.insert(DATABASE_TABLE, null, initialValues);
    }

    public long updateEntry(String idx, String name, String name2, String phone1, String phone2, String phone3, String phone4, String date,
                            String addr, String won, String no, String code,String sangjangno) {
        ContentValues initialValues = new ContentValues();

        initialValues.put(DataEntry.Data_NAME, name);
        initialValues.put(DataEntry.Data_NAME2, name2);
        initialValues.put(DataEntry.Data_PHONE1, phone1);
        initialValues.put(DataEntry.Data_PHONE2, phone2);
        initialValues.put(DataEntry.Data_PHONE3, phone3);
        initialValues.put(DataEntry.Data_PHONE4, phone4);
        initialValues.put(DataEntry.Data_DATE, date);
        initialValues.put(DataEntry.Data_ADDR, addr);
        initialValues.put(DataEntry.Data_WON, won);
        initialValues.put(DataEntry.Data_NO, no);
        initialValues.put(DataEntry.Data_CODE, code);
        initialValues.put(DataEntry.Data_SONGJANGNO, sangjangno);


        return mDb.update(DATABASE_TABLE, initialValues, DataEntry.Data_IDX + " = " + idx, null);

    }
/*    public Cursor selectREntry(int nAD) {
        //

        Cursor qu = mDb.query(DATABASE_TABLE, COLUMNS,
                DataEntry.OIL_AD + " >= " + nAD,
                null, null, null, DataEntry.OIL_R+" asc");

        return qu;

    }*/

    public Cursor selectEntry(String songjangno) {        //
        Cursor qu = mDb.query(DATABASE_TABLE, COLUMNS,
                DataEntry.Data_SONGJANGNO + " = '" + songjangno+"'",
                null, null, null, null);

        return qu;
    }

    public Cursor selectCountEntry(String name1,String name2,String phone1,String phone2,String addr) {
        //
        Cursor qu = mDb.query(DATABASE_TABLE, COLUMNSUM,
                "("+DataEntry.Data_NAME + " = '" + name1+"' or "+
                        DataEntry.Data_NAME2 + " = '" + name2+"') and ("+
                         DataEntry.Data_ADDR + " = '" + addr+"' or ((length("+DataEntry.Data_PHONE1+") >= "+11+" and length("+DataEntry.Data_PHONE2+") >= "+11+ ") and ("+DataEntry.Data_PHONE1 + " = '" + phone1+"' or "+
                        DataEntry.Data_PHONE2 + " = '" + phone2 +"'))) and ("+DataEntry.Data_C_STATE +"!='반품마감' and "+DataEntry.Data_C_STATE +"!='반품요청' and "+DataEntry.Data_C_STATE +"!='취소' and "+DataEntry.Data_C_STATE +"!='취소마감')",null, DataEntry.Data_SONGJANGNO, null, null);

        return qu;
    }

    public Cursor selectCountEntry2(String name1,String name2,String phone1,String phone2,String addr) {
        //
        Cursor qu = mDb.query(DATABASE_TABLE, COLUMNS,
                "("+DataEntry.Data_NAME + " = '" + name1+"' or "+
                        DataEntry.Data_NAME2 + " = '" + name2+"') and ("+
                        DataEntry.Data_ADDR + " = '" + addr+"' or ((length("+DataEntry.Data_PHONE1+") >= "+11+" and length("+DataEntry.Data_PHONE2+") >= "+11+ ") and ("+DataEntry.Data_PHONE1 + " = '" + phone1+"' or "+
                        DataEntry.Data_PHONE2 + " = '" + phone2 +"'))) and ("+DataEntry.Data_C_STATE +"!='반품마감' and "+DataEntry.Data_C_STATE +"!='반품요청' and "+DataEntry.Data_C_STATE +"!='취소' and "+DataEntry.Data_C_STATE +"!='취소마감')",null,null, null, null);
        return qu;
    }

    public Cursor selectCountEntry3(String name1,String name2,String phone1,String phone2,String addr,String no) {
        //
        Cursor qu = mDb.query(DATABASE_TABLE, COLUMNS,
                "("+DataEntry.Data_NAME + " = '" + name1+"' or "+
                        DataEntry.Data_NAME2 + " = '" + name2+"') and ("+
                        DataEntry.Data_ADDR + " = '" + addr+"' or ((length("+DataEntry.Data_PHONE1+") >= "+11+" and length("+DataEntry.Data_PHONE2+") >= "+11+ ") and ("+DataEntry.Data_PHONE1 + " = '" + phone1+"' or "+
                        DataEntry.Data_PHONE2 + " = '" + phone2 +"')))"+" and "+DataEntry.Data_NO+" != '"+no+"' and ("+DataEntry.Data_C_STATE +"!='반품마감' and "+DataEntry.Data_C_STATE +"!='반품요청' and "+DataEntry.Data_C_STATE +"!='취소' and "+DataEntry.Data_C_STATE +"!='취소마감')",null,null, null, null);

        return qu;
    }


    public Cursor selectIdxEntry(int nIdx) {
        //
        Cursor qu = mDb.query(DATABASE_TABLE, COLUMNS,
                DataEntry.Data_IDX + " = " + nIdx,
                null, null, null, null);

        return qu;

    }

    public Cursor fetchDateEntry(String date) {
        return mDb.rawQuery("Select * from " + DATABASE_TABLE + " where time LIKE '" + date + "%%'", null);
    }


    public Cursor fetchAllEntry() {
        //return mDb.rawQuery("Select * from "+DATABASE_TABLE,null);
        return mDb.query(DATABASE_TABLE, COLUMNS, null, null, null, null, null);
    }


    public int fetchAllEntryLength() {
        return mDb.query(DATABASE_TABLE, COLUMNS, null, null, null, null, null).getCount();
    }
    public void delALLEntry() {
        mDb.delete(DATABASE_TABLE,null, null);
    }

    public void delIDXEntry(int nIdx) {
        mDb.delete(DATABASE_TABLE, DataEntry.Data_IDX + "= " + nIdx, null);
    }

    private class DCTDatabaseHelper extends SQLiteOpenHelper {

        public DCTDatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(DATABASE_CREATE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
                    + newVersion + ", which will destory all old data");
            db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
            onCreate(db);
        }

    }


    public class DataEntry implements BaseColumns {
        //인덱스
        public static final String Data_IDX = "idx";
        //구매자명
        public static final String Data_NAME = "name";
        //수령자명
        public static final String Data_NAME2 = "name2";
        //구매자 전화번호
        public static final String Data_PHONE1 = "phone1";
        //구매자 휴대전화
        public static final String Data_PHONE2 = "phone2";
        //수령자 전화번호
        public static final String Data_PHONE3 = "phone3";
        //수령자 휴대전화
        public static final String Data_PHONE4 = "phone4";
        //주문일
        public static final String Data_DATE = "date";
        //주소
        public static final String Data_ADDR = "addr";
        //총판매가
        public static final String Data_WON = "won";
        // 주문번호
        public static final String Data_NO = "no";
        // 상품코드
        public static final String Data_CODE = "code";
        // 송장번호
        public static final String Data_SONGJANGNO = "songjangno";
        // 구매자 ID
        public static final String Data_CID = "cust_id";
        // 구매일
        public static final String Data_C_DATE = "cust_date";
        // 상태
        public static final String Data_C_STATE = "cust_state";
    }
}