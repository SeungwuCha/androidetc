package com.cloth.control;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;
import android.util.Log;

public class Data2DBAdapter {


    private static final String DATABASE_NAME = "data_cloth2.db";
    private static final String DATABASE_TABLE = "tb_data_cloth2";

    public static final int DATABASE_VERSION = 1;

    private static final String DATABASE_CREATE = "create table "
            + DATABASE_TABLE + " (" + DataEntry.Data_IDX
            + " INTEGER AUTO_INCREMENT primary key, "+ DataEntry.Data_NO1
            + " TEXT, "+ DataEntry.Data_NO2
            + " TEXT);";
    private static final String TAG = "DrivingDBAdapter";

    public String[] COLUMNS = new String[]{DataEntry.Data_IDX, DataEntry.Data_NO1,
            DataEntry.Data_NO2
    };
    private String[] CountCOLUMNS = new String[]{"count(idx)"
    };
    private Context mContext;
    private DCTDatabaseHelper mDbHelper;
    private SQLiteDatabase mDb;

    public Data2DBAdapter(Context context) {
        mContext = context;
    }

    public Data2DBAdapter open() throws SQLException {
        mDbHelper = new DCTDatabaseHelper(mContext);
        mDb = mDbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        if (mDbHelper != null)
            mDbHelper.close();
    }


    public long createEntry(String no1, String no2) {
        ContentValues initialValues = new ContentValues();

        initialValues.put(DataEntry.Data_NO1,no1);
        initialValues.put(DataEntry.Data_NO2, no2);




        return mDb.insert(DATABASE_TABLE, null, initialValues);
    }

    public long updateEntry(String idx, String no1, String no2) {
        ContentValues initialValues = new ContentValues();

        initialValues.put(DataEntry.Data_NO1,no1);
        initialValues.put(DataEntry.Data_NO2, no2);


        return mDb.update(DATABASE_TABLE, initialValues, DataEntry.Data_IDX + " = " + idx, null);

    }
/*    public Cursor selectREntry(int nAD) {
        //

        Cursor qu = mDb.query(DATABASE_TABLE, COLUMNS,
                DataEntry.OIL_AD + " >= " + nAD,
                null, null, null, DataEntry.OIL_R+" asc");

        return qu;

    }*/

    public Cursor selectIDXEntry(int nIdx) {
        //
        Cursor qu = mDb.query(DATABASE_TABLE, COLUMNS,
                DataEntry.Data_IDX + " = " + nIdx,
                null, null, null, null);

        return qu;

    }

    public Cursor fetchDateEntry(String date) {
        return mDb.rawQuery("Select * from " + DATABASE_TABLE + " where time LIKE '" + date + "%%'", null);
    }



    public int ALLDEL() {
        return mDb.delete(DATABASE_TABLE,null,null);
    }


    public Cursor fetchAllEntry() {
        //return mDb.rawQuery("Select * from "+DATABASE_TABLE,null);
        return mDb.query(DATABASE_TABLE, COLUMNS, null, null, null, null, null);
    }




    public int fetchAllEntryLength() {
        return mDb.query(DATABASE_TABLE, COLUMNS, null, null, null, null, null).getCount();
    }

    public void delIDXEntry(int nIdx) {
        mDb.delete(DATABASE_TABLE, DataEntry.Data_IDX + "= " + nIdx, null);
    }

    private class DCTDatabaseHelper extends SQLiteOpenHelper {

        public DCTDatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(DATABASE_CREATE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
                    + newVersion + ", which will destory all old data");
            db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
            onCreate(db);
        }

    }





    public class DataEntry implements BaseColumns {
        //인덱스
        public static final String Data_IDX = "idx";
        //송장번호
        public static final String Data_NO1 = "data_no1";
        //출하품
        public static final String Data_NO2 = "data_no2";


        
    }

}
