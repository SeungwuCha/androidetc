package com.cloth.control;

/**
 * Created by csw on 2017-10-11.
 */

public class ProductItem {
    String product;
    String box;
    String no;

    public ProductItem(String product, String box, String no) {
        this.product = product;
        this.box = box;
        this.no = no;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getBox() {
        return box;
    }

    public void setBox(String box) {
        this.box = box;
    }

    public String getNo() {
        return no;
    }

    public void setNo(String no) {
        this.no = no;
    }
}
