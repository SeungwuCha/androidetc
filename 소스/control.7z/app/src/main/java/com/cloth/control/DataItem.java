package com.cloth.control;

/**
 * Created by csw on 2017-10-11.
 */

public class DataItem {
    String state;
    String box;
    String no;

    public DataItem(String state,String box, String no) {
        this.state =state;
        this.box = box;
        this.no = no;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getBox() {
        return box;
    }

    public void setBox(String box) {
        this.box = box;
    }

    public String getNo() {
        return no;
    }

    public void setNo(String no) {
        this.no = no;
    }
}
