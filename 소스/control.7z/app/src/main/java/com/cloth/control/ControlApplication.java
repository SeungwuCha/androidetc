package com.cloth.control;

import android.app.Application;

import org.acra.ACRA;
import org.acra.ReportingInteractionMode;
import org.acra.annotation.ReportsCrashes;

/**
 * Created by roadpia_000 on 2017-01-18.
 */


@ReportsCrashes
        (
                formKey = "",
                resToastText = R.string.bug_report_title,
                mode = ReportingInteractionMode.DIALOG,
                resDialogIcon = android.R.drawable.ic_dialog_info,
                resDialogTitle = R.string.bug_report_title,
                resDialogText = R.string.bug_report_text,
                mailTo = "chasw12@naver.com"

        )

public class ControlApplication extends Application {






    @Override
    public void onCreate() {
        super.onCreate();
        /***
         * SDK 위치 초기화
         */
        ACRA.init(this);

    }

    @Override
    public void onTerminate() {
        super.onTerminate();

    }







}