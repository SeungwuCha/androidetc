package com.sunmi.smart.activity;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class PreferenceWrapper {
	
	static protected SharedPreferences getPref(Context c){
		return PreferenceManager.getDefaultSharedPreferences(c);
	}

	static protected SharedPreferences.Editor getEidtor(Context c){
		return getPref(c).edit();
	}
	
	public static boolean setPreferenceInt(Context c, String szName, int nData){
		SharedPreferences.Editor edit = getEidtor(c);
		edit.putInt(szName, nData);
		return edit.commit();
	}
	
	public static int getPreferenceInt(Context c, String szName, int nDefault){
		return getPref(c).getInt(szName, nDefault);
	}
	
	public static boolean setPreferenceLong(Context c, String szName, long nData){
		SharedPreferences.Editor edit = getEidtor(c);
		edit.putLong(szName, nData);
		return edit.commit();
	}
	
	public static long getPreferenceLong(Context c, String szName, long nDefault){
		return getPref(c).getLong(szName, nDefault);
	}
	
	
	public static boolean setPreferenceString(Context c, String szName, String szData){
		SharedPreferences.Editor edit = getEidtor(c);
		edit.putString(szName, szData);
		return edit.commit();
	}
	
	public static String getPreferenceString(Context c, String szName, String szDefault){
		return getPref(c).getString(szName, szDefault);
	}
	

	public static boolean setPreferenceBoolean(Context c, String szName, boolean bData){
		SharedPreferences.Editor edit = getEidtor(c);
		edit.putBoolean(szName, bData);
		return edit.commit();
	}
	
	public static boolean getPreferenceBoolean(Context c, String szName, boolean bDefault){
		return getPref(c).getBoolean(szName, bDefault);
	}
}
