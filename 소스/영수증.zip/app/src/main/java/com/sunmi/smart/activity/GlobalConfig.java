package com.sunmi.smart.activity;

import android.content.Context;


/**
 * Created by wangyida on 15-1-18.
 */
public class GlobalConfig {

    private static Context sContext;

    public static void setAppContext(Context context) {
        sContext = context;
    }

    public static Context getAppContext() {
        return sContext;
    }

}