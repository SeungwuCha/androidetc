package com.sunmi.smart.activity;

import android.content.Intent;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;
import com.google.firebase.iid.FirebaseInstanceId;
import com.sunmi.smart.R;
import com.sunmi.smart.bean.TableItem;
import com.sunmi.smart.utils.AidlUtil;
import com.sunmi.smart.utils.Sharedpreference;
import com.sunmi.smart.web.LoginRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.LinkedList;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;


public class LoginActivity extends BaseActivity implements View.OnClickListener {

    RequestQueue queue;
    LinkedList<TableItem> datalist = new LinkedList<>();
    //63개 DASH
    final String strDash = "---------------------------------------------------------------";

    Button btn_login;
    EditText et_id,et_pw;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
       initRes();
       initData();
    }

    private void initData() {
        et_id.setText(Sharedpreference.getSharedPrefUserID(this));
        et_pw.setText(Sharedpreference.getSharedPrefPASSWORD(this));
        if(Sharedpreference.getSharedPrefAutoLogin(this)){
            login(et_id.getText().toString(),et_pw.getText().toString());
        }
    }

    private void initRes() {
        et_id = findViewById(R.id.et_id);
        et_pw = findViewById(R.id.et_pw);
        btn_login = findViewById(R.id.btn_login);
        btn_login.setOnClickListener(this);

    }

    public void testCode(){
        //매장용
        if (baseApp.isAidl()) {
            datalist.clear();
            addOneData("[매장용]");

            AidlUtil.getInstance().printTable(datalist);
        }

        if (baseApp.isAidl()) {
            //12가 제일 작음,굵게 밑줄 모두 X
            AidlUtil.getInstance().printText(strDash,12,false,false);
        }
        if (baseApp.isAidl()) {
            //12가 제일 작음,굵게 밑줄 모두 X
            AidlUtil.getInstance().printText("배달주소 : 경기 군포시 당동 912-7 402호",21,false,false);
            AidlUtil.getInstance().printText("받으시는분 : 김크몽",21,false,false);
            AidlUtil.getInstance().printText("연락처 : 010-0000-0000",21,false,false);
        }
        if (baseApp.isAidl()) {
            //12가 제일 작음,굵게 밑줄 모두 X
            AidlUtil.getInstance().printText(strDash,12,false,false);
        }
        if (baseApp.isAidl()) {
            //12가 제일 작음,굵게 밑줄 모두 X
            AidlUtil.getInstance().printText("요청사항",21,false,false);
            AidlUtil.getInstance().printText("바삭하게 튀겨주세요",21,false,false);
        }
        if (baseApp.isAidl()) {
            //12가 제일 작음,굵게 밑줄 모두 X
            AidlUtil.getInstance().printText(strDash,12,false,false);
        }
        if (baseApp.isAidl()) {
            datalist.clear();
            addOneDataTitle("메뉴","수량","금액");
            AidlUtil.getInstance().printTable(datalist);
        }
        if (baseApp.isAidl()) {
            //12가 제일 작음,굵게 밑줄 모두 X
            AidlUtil.getInstance().printText(strDash,12,false,false);
        }
        if (baseApp.isAidl()) {
            datalist.clear();
            addOneData("1.","양념치킨","1","17,000");
            addOneData("2.","불짬뽕후라이드치킨","1","120,000");
            addOneData("3.","후라이드","1","16,000");
            addOneData("4.","이것은 갈비인가 통닭인가 갈비양념통닭","1","30,000");
            AidlUtil.getInstance().printTable(datalist);
        }
        if (baseApp.isAidl()) {
            //12가 제일 작음,굵게 밑줄 모두 X
            AidlUtil.getInstance().printText(strDash,12,false,false);
        }
        if (baseApp.isAidl()) {
            //12가 제일 작음,굵게 밑줄 모두 X
            AidlUtil.getInstance().printText("고객정보를 배달목적 외 사용하거나 보관,",21,false,false);
            AidlUtil.getInstance().printText("공개할 경우 법적처벌을 받을수 있습니다.",21,false,false);
        }

        if (baseApp.isAidl()) {
            //3줄
            AidlUtil.getInstance().print3Line();
        }

    }
    //매장용
    public void addOneData(String item) {


        TableItem ti = new TableItem(1);
        ti.getText()[0] = item;

        int[] width = {1};
        ti.setWidth(width);

        int[] align = {2};
        ti.setAlign(align);
        datalist.add(ti);
    }
    //번호 //메뉴,//개수//가격
    public void addOneData(String item1,String item2,String item3,String item4) {


        TableItem ti = new TableItem(4);
        ti.getText()[0] = item1;
        ti.getText()[1] = item2;
        ti.getText()[2] = item3;
        ti.getText()[3] = item4;
        int[] width = {2,9,3,5};
        ti.setWidth(width);

        int[] align = {0,0,1,2};
        ti.setAlign(align);
        datalist.add(ti);
    }
    //번호 //메뉴,//개수//가격
    public void addOneDataTitle(String item1,String item2,String item3) {


        TableItem ti = new TableItem(3);
        ti.getText()[0] = item1;
        ti.getText()[1] = item2;
        ti.getText()[2] = item3;

        int[] width = {11,3,5};
        ti.setWidth(width);

        int[] align = {0,1,2};
        ti.setAlign(align);
        datalist.add(ti);
    }

    public void login(String id,String pw) {


        String addr = "http://autocall6.why-be.co.kr/android_loginchk.php"+"?mb_id="+id+"&mb_pw="+pw;
        LoginRequest loginRequest = new LoginRequest(addr, responseListner,errorListener);
        // 실제 서버 응답 할 수 있는 tfRequest 생성
        if (queue == null) {
            queue = Volley.newRequestQueue(LoginActivity.this);
        }
        // loginRequest를 queue에 담아 실행
        queue.add(loginRequest);
                /* 정상적으로 tfRequest가 보내지고 그 결과로 나온 Response가 jsonResponse를 통해서 다루어지게 됨
                 따라서 오류난경우만 예외처리함 */

    }
    Response.Listener<String> responseListner = new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {
            // Response 에서 리스너를 만들어서 결과를 받아올 수 있도록 함
            Log.e("response",response);
            try {
                JSONObject json = new JSONObject(response);
                JSONArray results = json.getJSONArray("results");
                String ss_mb_key = results.getJSONObject(0).getString("ss_mb_key");
                Log.e("ss_mb_key",ss_mb_key);
                Intent intent = new Intent(LoginActivity.this,MainActivity.class);
                String device_id = Settings.Secure.getString(getApplicationContext().getContentResolver(), Settings.Secure.ANDROID_ID);
                String mb_id = et_id.getText().toString();
                String url = "http://autocall6.why-be.co.kr/mobile/shop/store/index.php?mb_id="+mb_id+"&ss_mb_key="+ss_mb_key;//mbv9rHHZqpUcgUB3CwUdSRKc4
                        //"http://autocall6.why-be.co.kr/mobile/shop/store/index.php?token="+ FirebaseInstanceId.getInstance().getToken() +"&uniq_id="+device_id+"&ss_mb_key="+ss_mb_key+"&mb_id="+mb_id;
                intent.putExtra("url",url);
                startActivity(intent);
                Sharedpreference.setSharedPrefUserID(LoginActivity.this,et_id.getText().toString());
                Sharedpreference.setSharedPrefPASSWORD(LoginActivity.this,et_pw.getText().toString());
                Sharedpreference.setSharedPrefAutoLogin(LoginActivity.this,true);
                finish();
            } catch (JSONException e) {
                e.printStackTrace();
                Toast.makeText(baseApp, "로그인이 되지 않았습니다.", Toast.LENGTH_SHORT).show();
            }

            // 예외처리
        }
    };
    Response.ErrorListener errorListener = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {

        }
    };

    @Override
    public void onClick(View view) {
        if(view == btn_login){
            login(et_id.getText().toString(),et_pw.getText().toString());
            //testCode();
        }
    }


}
