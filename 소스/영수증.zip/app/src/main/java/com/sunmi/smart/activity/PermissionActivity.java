/*
 * Copyright (C) 2015 Jacob Klinker
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.sunmi.smart.activity;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

public class PermissionActivity extends Activity {
private MainActivity mainActivity;
    @TargetApi(Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestPermissions(new String[]{
                Manifest.permission.READ_CONTACTS,
                //Manifest.permission.READ_SMS,
                Manifest.permission.INTERNET,
                Manifest.permission.READ_PHONE_NUMBERS,


                //Manifest.permission.SEND_SMS,
                //Manifest.permission.RECEIVE_SMS,
                //Manifest.permission.RECEIVE_MMS,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_PHONE_STATE,
                /*Manifest.permission.READ_PHONE_NUMBERS,*/ // READ_SMS로 대체가능
                Manifest.permission.CHANGE_NETWORK_STATE
        }, 0);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        /*PreferenceManager.getDefaultSharedPreferences(this).edit()
                .putBoolean("request_permissions", false)
                .commit();*/
        PreferenceWrapper.setPreferenceString(this,"perm","ok");

        //startActivity(new Intent(this, MainActivity.class));
        //new MainActivity.SendPost().execute();
        //mainActivity = (MainActivity)getApplicationContext();
        //mainActivity.new MainActivity.SendPost().execute();



       // new SendPost().execute();

        startActivity(new Intent(this, MainActivity.class));
        finish();

    }
    /*
    public class SendPost extends AsyncTask<Void, Void, String> {
        protected String doInBackground(Void... unused) {
            String content = executeClient();
            return content;
        }

        protected void onPostExecute(String result) {
            // 모두 작업을 마치고 실행할 일 (메소드 등등)
        }

        // 실제 전송하는 부분
        public String executeClient() {
            String refreshedToken = FirebaseInstanceId.getInstance().getToken();
            String device_id = Settings.Secure.getString(getApplicationContext().getContentResolver(), Settings.Secure.ANDROID_ID);

            ArrayList<NameValuePair> post = new ArrayList<NameValuePair>();
            post.add(new BasicNameValuePair("token", refreshedToken));
            post.add(new BasicNameValuePair("deviceid", device_id));

//            Log.d("타니????",refreshedToken);
            // 연결 HttpClient 객체 생성
            HttpClient client = new DefaultHttpClient();

            // 객체 연결 설정 부분, 연결 최대시간 등등
            HttpParams params = client.getParams();
            HttpConnectionParams.setConnectionTimeout(params, 5000);
            HttpConnectionParams.setSoTimeout(params, 5000);

            // Post객체 생성
            HttpPost httpPost = new HttpPost("http://hantheminjoo.cafe24.com/app_api/register_token.php");
            //HttpPost httpPost = new HttpPost("http://youbojob.why-be.co.kr/ju/test_2.php");
            Log.d("타니????","ㅇㅇㅇㅇㅇ");
            try {
                UrlEncodedFormEntity entity = new UrlEncodedFormEntity(post, "UTF-8");
                httpPost.setEntity(entity);
                client.execute(httpPost);
                return EntityUtils.getContentCharSet(entity);
            } catch (ClientProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }
    */
}
