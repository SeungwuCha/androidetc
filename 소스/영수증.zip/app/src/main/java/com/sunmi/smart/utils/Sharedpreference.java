package com.sunmi.smart.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class Sharedpreference {

	final private static String BT = "bt";





	//로그인한자의 아이디
	final private static String PREFKEY_USER_ID = "user_id";
	//로그인한자의 패스워드
	final private static String PREFKEY_PASSWORD = "password";
	//자동로그인
	final private static String PREFKEY_AUTO_LOGIN = "auto_login";




	public static void setSharedPrefUserID(Context context, String value){
		SharedPreferences pref = context.getSharedPreferences(BT, Context.MODE_PRIVATE);
		SharedPreferences.Editor prefEditor = pref.edit();
		prefEditor.putString(PREFKEY_USER_ID, value);
		prefEditor.commit();
	}
	public static String getSharedPrefUserID(Context context){
		SharedPreferences pref = context.getSharedPreferences(BT, Context.MODE_PRIVATE);
		return pref.getString(PREFKEY_USER_ID,"");
	}

	public static String getSharedPrefPASSWORD(Context context){
		SharedPreferences pref = context.getSharedPreferences(BT, Context.MODE_PRIVATE);
		return pref.getString(PREFKEY_PASSWORD,"");
	}
	public static void setSharedPrefPASSWORD(Context context, String value){
		SharedPreferences pref = context.getSharedPreferences(BT, Context.MODE_PRIVATE);
		SharedPreferences.Editor prefEditor = pref.edit();
		prefEditor.putString(PREFKEY_PASSWORD, value);
		prefEditor.commit();
	}
//PREFKEY_AUTO_LOGIN

	public static void setSharedPrefAutoLogin(Context context, boolean value){
		SharedPreferences pref = context.getSharedPreferences(BT, Context.MODE_PRIVATE);
		SharedPreferences.Editor prefEditor = pref.edit();
		prefEditor.putBoolean(PREFKEY_AUTO_LOGIN, value);
		prefEditor.commit();
	}

	public static boolean getSharedPrefAutoLogin(Context context){
		SharedPreferences pref = context.getSharedPreferences(BT, Context.MODE_PRIVATE);
		return pref.getBoolean(PREFKEY_AUTO_LOGIN,false);
	}






}
