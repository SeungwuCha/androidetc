package com.sunmi.smart.activity;

/**
 * Created by newarbhai on 6/30/18.
 */

public class Constants {

    public static final String CHANNEL_ID = "hid";
    public static final String CHANNEL_NAME= "haru";
    public static final String CHANNEL_DESC = "hdescription";
}