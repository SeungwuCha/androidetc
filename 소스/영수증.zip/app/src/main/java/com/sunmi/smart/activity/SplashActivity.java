package com.sunmi.smart.activity;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;

import com.sunmi.smart.R;


/**
 * Created by app on 2017-06-02.
 */

public class SplashActivity extends AppCompatActivity {
    @Override
    public void onCreate(Bundle saveInstanceState){
        super.onCreate(saveInstanceState);
        setContentView(new MyView(this));

        Handler handler = new Handler(){
            @Override
            public void handleMessage(Message msg){
                finish();
            }
        };
        handler.sendEmptyMessageDelayed(0, 3000);
    }

    class MyView extends View {
        int width, height, o_height;

        public MyView(Context context){
            super(context);
            Display display = ((WindowManager)context.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();

            //디바이스의 가로크기
            width = display.getWidth();

            //디바이스의 세로크기
            o_height = display.getHeight();

            //랜딩페이지의 이미지는 1200*1200 임
            /**
             * 랜딩페이지의 이미지는 1200*1200 임
             * 디바이스의 세로크기는 기종마다 다르기 때문에
             * (디바이스의 세로크기에 반) - (랜딩 페이지 이미지 크기의 반)
             * 으로 위치조정을 하면 랜딩 이미지가 정확이 중아에 오게됨
             * 랜딩 이미지는 가로 크기에 맞추에 리사이징이 되기때문에 깨지지 않음
             * 한번더 이마트에서 전화오면 ...
             */
            height = (o_height/2) - (width/2);
        }

        public void onDraw(Canvas canvas){
            Paint paint = new Paint();

            //벼경색은 rgb 코드로 255 255 `255 는 흰색임
            canvas.drawRGB(255, 255, 255);


            Resources r = getResources();

            /**
             * 여기서 부터 랜딩 이미지의 리사이징이 들어감
             * 랜딩이미지는 2개로 구성됨
             * 하나는 바탕 하나는 바탕위에 올라가는 로고 같은거
             * 바탕의 크기는 640*960 이고
             * 로고의 크기는 1200 *1200 일듯
             *
             * R.drawable.g_intro => drawable 폴더안에  g_intro 이미지
             */
            //배경이미지를 비트맵으로 변환
            BitmapDrawable background = (BitmapDrawable)r.getDrawable(R.mipmap.ic_launcher);
            Bitmap bg = background.getBitmap();
//			//바탕의 크기임. 디바이스 크기에 꽈곽 체움.
            Bitmap bg_last = Bitmap.createScaledBitmap(bg, width, o_height, true);
//			//배경을 화면에 그림
//			//bg_last를 오프셋 0,0 부터 그리기 시작함.
//			//canvas.drawBitmap(비트맵, 가로오프셋, 세로오프셋, paint);
            canvas.drawBitmap(bg_last, 0, 0, paint);

            //이제 배경그린거 위에 로고를 로고를 그림
//			BitmapDrawable logo = (BitmapDrawable)r.getDrawable(R.drawable.t_intro);
//			Bitmap lg = logo.getBitmap();
            //로고는 가로세로 둘다 디바이스의 가로크기에 맞춤.
//			Bitmap logo_last = Bitmap.createScaledBitmap(lg, width, width, true);
            //로고그리기
//			canvas.drawBitmap(logo_last, 0, height, paint);


            /**
             *
             * 끝
             * 중의사항 배경이미지 크기는 640 960
             * 배경위에 올라갈 이미지크기는 1200 1200
             *
             */
        }
    }
}
