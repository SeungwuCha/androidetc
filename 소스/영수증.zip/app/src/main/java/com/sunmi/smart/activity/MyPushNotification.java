package com.sunmi.smart.activity;

import android.annotation.SuppressLint;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.provider.Settings;
import android.support.v4.app.NotificationCompat;

import com.sunmi.smart.R;

import java.net.URL;

/**
 * Created by newarbhai on 6/30/18.
 */

public class MyPushNotification {
    Bitmap bigPicture;
    Context context;
    static MyPushNotification myNotification;

    MyPushNotification(Context context){
        this.context = context;

    }

    public static synchronized MyPushNotification getInstance(Context context){

        if (myNotification == null){
            myNotification = new MyPushNotification(context);
        }
        return myNotification;
    }

    public void displayNotification(String title, String content,String body){
        //body = "http://youbojob1.why-be.co.kr/img/logo.png";

        //이미지 온라인 링크를 가져와 비트맵으로 바꾼다.
        try {
            URL url = new URL(body);
            bigPicture = BitmapFactory.decodeStream(url.openConnection().getInputStream());
        } catch (Exception e) {
            e.printStackTrace();
        }
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, Constants.CHANNEL_ID)
                .setSmallIcon(R.drawable.switch_on)
                .setContentTitle("스마트안산")
                .setContentText(title)

                .setLargeIcon(BitmapFactory.decodeResource(context.getResources(), R.drawable.about))
                //.setShowWhen(true)
                .setColor(Color.GREEN)
                //.setLocalOnly(true)
                //이미지를 보내는 스타일 사용하기

                .setStyle(new NotificationCompat.BigTextStyle()
                        //.setBigContentTitle("FCM Push Big Text")

                        .bigText(title)

                );




/*
                .setStyle(new NotificationCompat.BigPictureStyle()

                            .bigPicture(bigPicture)

                            .setBigContentTitle(title)
                )
                    ;
*/



        builder.setVibrate(new long[] { 1000, 1000});
        builder.setSound(Settings.System.DEFAULT_NOTIFICATION_URI);




        Intent intent = new Intent(context, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        builder.setContentIntent(pendingIntent);
        @SuppressLint("ServiceCast")
        NotificationManager myNotification = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        int random = (int) (Math.random() * 100000) + 1;
        int random2 = (int) (Math.random() * 1000) + 1;
        if (myNotification != null){
            myNotification.notify(random+random2, builder.build());
        }
    }
    public void bigpic(String value)
    {
        String Yimg = ".setStyle(new NotificationCompat.BigPictureStyle().bigPicture(bigPicture));";
        String Yimg2 = ";";

    }
}
