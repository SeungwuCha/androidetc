package com.sunmi.smart.activity;

import android.Manifest;
import android.app.Activity;
import android.app.DownloadManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.MediaScannerConnection;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.Browser;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.webkit.GeolocationPermissions;
import android.webkit.HttpAuthHandler;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;
import com.google.firebase.iid.FirebaseInstanceId;
import com.sunmi.smart.R;
import com.sunmi.smart.bean.PrintItem;
import com.sunmi.smart.bean.TableItem;
import com.sunmi.smart.dialog.LodingDialog;
import com.sunmi.smart.utils.AidlUtil;
import com.sunmi.smart.utils.Sharedpreference;
import com.sunmi.smart.web.ODIDRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.reactivestreams.Publisher;
import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.Inet4Address;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.LinkedList;
import java.util.Locale;

import cz.msebera.android.httpclient.NameValuePair;
import cz.msebera.android.httpclient.client.ClientProtocolException;
import cz.msebera.android.httpclient.client.HttpClient;
import cz.msebera.android.httpclient.client.entity.UrlEncodedFormEntity;
import cz.msebera.android.httpclient.client.methods.HttpPost;
import cz.msebera.android.httpclient.impl.client.DefaultHttpClient;
import cz.msebera.android.httpclient.message.BasicNameValuePair;
import cz.msebera.android.httpclient.params.HttpConnectionParams;
import cz.msebera.android.httpclient.params.HttpParams;
import cz.msebera.android.httpclient.util.EntityUtils;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.FlowableEmitter;
import io.reactivex.FlowableOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.functions.Action;
import io.reactivex.functions.BiFunction;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;

import static android.os.Environment.DIRECTORY_PICTURES;
import static android.os.Environment.getExternalStoragePublicDirectory;
import static android.view.KeyEvent.KEYCODE_BACK;
import static com.sunmi.smart.R.id.container;

public class MainActivity extends BaseActivity {

    RequestQueue queue;
    private final int REQUEST_PERMISSION_CONTACTS=1;
    String TAG = "THAPP";
    public static MainActivity act;
    /*******************WEBVIEW SETTING***************/
    FrameLayout mContainer;
    ArrayList<WebView> childViews;
    WebView webview; // webview declared
    public final static int INET4ADDRESS = 1;
    public final static int INET6ADDRESS = 2;
    private ValueCallback<Uri> mUploadMessage;
    private ValueCallback<Uri[]> mFilePathCallback;
    private String mCameraPhotoPath;
    private static final String TYPE_IMAGE = "image/*";
    private static final int INPUT_FILE_REQUEST_CODE = 1;
    public String fp = "";

    private ProgressDialog mProgressDialog;
    /*******************WEBVIEW SETTING***************/
    private static final int REQUEST_TAKE_PHOTO = 1;

    /************화면캡처 셋팅**************/
    private final int MY_PERMISSIONS_REQUEST_WRITE_STORAGE = 5566;
    private static final int REQUEST_CODE = 5588;
    private MediaProjectionManager mProjectionManager;
    private MediaProjection mProjection;
    private ImageReader mImageReader;
    private VirtualDisplay mVirtualDisplay;
    private ImageReader.OnImageAvailableListener mImageListener;
    private MediaScannerConnection.OnScanCompletedListener mScanListener;
    private Context mContext;
    private Button mButton;
    private ImageButton button;
    String myResult;
    /************화면캡처 셋팅**************/
    int n;
    String photoPath;
    RelativeLayout rootContent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        act = this;


        rootContent = (RelativeLayout) findViewById(R.id.RelativeLayout);


        mContext = this;
        Log.d("mytokken==>",configData.getRegistrationId(mContext));
        /*
        mButton = findViewById(R.id.tmp);
        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                screenShot();
            }
        });
        */
        //askWritePermission();


        //startActivity(new Intent(getApplicationContext(),SplashActivity.class));
        String perm_checked = PreferenceWrapper.getPreferenceString(mContext,"perm","");
        Log.d("perm_checked-->",perm_checked);
        if (perm_checked.equals("") &&
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            startActivity(new Intent(this, PermissionActivity.class));
            finish();
            return;
        }
//        new SendPost().execute();
        //showContactsPermission(); // 퍼미션체크

        //Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);

        //setSupportActionBar(toolbar);

        createNotificationChannel(); //FCM 알림채널

        new SendPost().execute();


        mContainer = (FrameLayout) findViewById(container);
        childViews = new ArrayList<WebView>();

        webview = (WebView) findViewById(R.id.webview);
        webview.getSettings().setJavaScriptEnabled(true);
        webview.getSettings().setPluginState(WebSettings.PluginState.ON);
        webview.getSettings().setGeolocationEnabled(true);
        webview.setWebViewClient(new ybWebViewClient());
        webview.setWebChromeClient(new joyChromeClient());
        webview.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        webview.getSettings().setSupportMultipleWindows(false);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            // chromium, enable hardware acceleration
            webview.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        } else {
            // older android version, disable hardware acceleration
            webview.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }
        webview.clearCache(true);
        webview.addJavascriptInterface(new JavaScriptInterface(this), "AppUI");
        //    webview.loadUrl("http://www.joyfs.co.kr/");

        Intent intent = getIntent();
        String url =  intent.getStringExtra("url");
        try {
            if (url == null) {
                //webview.loadUrl("http://www.banchanok.co.kr/shop/?device=mobile");
                //webview.loadUrl("http://kth8295.why-be.co.kr/?device=mobile");
                String refreshedToken = FirebaseInstanceId.getInstance().getToken();
                Log.d("mytoken==>",refreshedToken);
                String device_id = Settings.Secure.getString(getApplicationContext().getContentResolver(), Settings.Secure.ANDROID_ID);
                //String hphp = get_hp_num();
                //webview.loadUrl("http://hantheminjoo.cafe24.com?token="+refreshedToken+"&uniq_id="+device_id+"&hp="+hphp);
                webview.loadUrl("http://autocall4.why-be.co.kr/mobile/shop/store/index.php?token="+refreshedToken+"&uniq_id="+device_id);
                Log.d("webviewurl--","http://autocall4.why-be.co.kr/mobile/shop/store/index.php?token="+refreshedToken+"&uniq_id="+device_id);

                //webview.loadUrl("http://kbunny3.why-be.co.kr/mypage/coupon_detail.php?cp_no=15&wr_id=168&win=pop_win&type=&barcode=GD26-M44C-CQ2D-VFBY&device=mobile");
            } else {
                webview.loadUrl(url);
            }
        }catch(NullPointerException e){
            Log.e(TAG,e.getMessage());
        }

    /*
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "you clicked this",Toast.LENGTH_LONG).show();
            }
        });
        */
        //getPrintIfno("2019050214334381");
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            NotificationChannel notificationChannel = new NotificationChannel(Constants.CHANNEL_ID, Constants.CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH);

            notificationChannel.setDescription(Constants.CHANNEL_DESC);
            notificationChannel.enableLights(true);
//            notificationChannel.setLightColor(Color.CYAN);
            notificationChannel.enableVibration(true);
            notificationChannel.setVibrationPattern(new long[]{100,200,300,400,500,400,300,200,400});
            notificationManager.createNotificationChannel(notificationChannel);
        }
    }

    private void initState(){
        mProjectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        //  mButton.setClickable(true);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    /*권한부분*/

    private void showContactsPermission() {
        int permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS);
        if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_CONTACTS)) {
                showExplanation("요청 권한이 필요합니다.", "[주소록] 접근권한이 있어야지 서비스가 가능합니다.", Manifest.permission.READ_CONTACTS, REQUEST_PERMISSION_CONTACTS); //권한필요 설명//
            } else {
                requestPermission(Manifest.permission.READ_CONTACTS, REQUEST_PERMISSION_CONTACTS);
            }
        } else {
            //Toast.makeText(MainActivity.this, "요청권한이 이미 승인되었습니다. 서비스를 계속합니다.", Toast.LENGTH_SHORT).show();
            //new SendPost().execute();
            //이후 작업진행//
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        Log.d("aaaa--","d");
        switch (requestCode) {
            case REQUEST_PERMISSION_CONTACTS:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                    Toast.makeText(MainActivity.this, "권한 승인", Toast.LENGTH_SHORT).show();
                    //new SendPost().execute();
                } else {
//                    Toast.makeText(MainActivity.this, "권한 거부로 정상적인 서비스가 불가합니다. 서비스를 이용하실려면 권한을 승인해야 합니다.", Toast.LENGTH_SHORT).show();
                }
            case MY_PERMISSIONS_REQUEST_WRITE_STORAGE: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    initState();
                }
                break;
            }
        }
    }

    private void showExplanation(String title, String message, final String permission, final int permissionRequestCode) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title)
                .setMessage(message)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        requestPermission(permission, permissionRequestCode); //권한 재요청//
                    }
                });
        builder.create().show();
    }

    private void requestPermission(String permissionName, int permissionRequestCode) {
        ActivityCompat.requestPermissions(this, new String[]{permissionName}, permissionRequestCode); //권한요청 다이얼로그//
    }






    /* 웹뷰 */
    private class ybWebViewClient extends WebViewClient {
        public static final String INTENT_PROTOCOL_START = "intent:";
        public static final String INTENT_PROTOCOL_INTENT = "#Intent;";
        public static final String INTENT_PROTOCOL_END = ";end;";
        public static final String GOOGLE_PLAY_STORE_PREFIX = "market://details?id=";

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, final String url) {


            Log.e("test","URL:" + url);
            //로그아웃처리
            if(url.contains("http://autocall6.why-be.co.kr/bbs/logout2.php")){

                Sharedpreference.setSharedPrefUserID(MainActivity.this,"");
                Sharedpreference.setSharedPrefPASSWORD(MainActivity.this,"");
                Sharedpreference.setSharedPrefAutoLogin(MainActivity.this,false);
                Intent intent = new Intent(MainActivity.this,LoginActivity.class);
                startActivity(intent);
                finish();

            }
            if(url.startsWith("http://")){
                new Thread() {
                    public void run() {
                        Run_Logging(url);
                    }
                }.start();

                view.loadUrl(url);
                return true;
            }else if(url.startsWith("https://")){
                new Thread() {
                    public void run() {
                        Run_Logging(url);
                    }
                }.start();

                view.loadUrl(url);
                return true;
            }else{
                boolean override = false;
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.putExtra(Browser.EXTRA_APPLICATION_ID, getPackageName());

                if (url.startsWith("sms:")) {
                    Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse(url));
                    startActivity(i);
                    return true;
                }

                if (url.startsWith("tel:")) {
                    //					new AlertDialog.Builder(view.getContext())
                    //					.setTitle("알림")
                    //					.setMessage("연결하시겠습니까?")
                    //					.setPositiveButton(android.R.string.ok,
                    //					new DialogInterface.OnClickListener() {
                    //						public void onClick(DialogInterface dialog, int which) {
                    Intent i = new Intent(Intent.ACTION_DIAL, Uri.parse(url));
                    startActivity(i);
                    //						}
                    //					})
                    //					.setNegativeButton(android.R.string.cancel,
                    //					new DialogInterface.OnClickListener() {
                    //						public void onClick(DialogInterface dialog, int which) {
                    //
                    //						}
                    //					}).create().show();

                    return true;
                }


                if (url.startsWith("mailto:")) {
                    Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse(url));
                    startActivity(i);
                    return true;
                }

                /*
                if (url.startsWith("intent:")) {
                    try {
                        Intent intent2 = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                        Intent existPackage = getPackageManager().getLaunchIntentForPackage(intent2.getPackage());
                        if (existPackage != null) {
                            startActivity(intent2);
                        } else {
                            Intent marketIntent = new Intent(Intent.ACTION_VIEW);
                            marketIntent.setData(Uri.parse("market://details?id=" + intent2.getPackage()));
                            startActivity(marketIntent);
                        }
                        return true;
                    } catch (Exception e) {
                        e.printStackTrace();
                        return false;
                    }
                } else {
                    return false;
                }*/
                try {
                    Intent intent2 = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                    Intent existPackage = getPackageManager().getLaunchIntentForPackage(intent2.getPackage());
                    if (existPackage != null) {
                        startActivity(intent2);
                    } else {
                        Intent marketIntent = new Intent(Intent.ACTION_VIEW);
                        marketIntent.setData(Uri.parse("market://details?id=" + intent2.getPackage()));
                        startActivity(marketIntent);
                    }
                    return true;
                } catch (Exception e) {
                    e.printStackTrace();
                    return false;
                }

                /*else if (url.startsWith(INTENT_PROTOCOL_START)) { //카카오링크 네이버밴드등 커스텀스키마들
                    final int customUrlStartIndex = INTENT_PROTOCOL_START.length();
                    final int customUrlEndIndex = url.indexOf(INTENT_PROTOCOL_INTENT);
                    if (customUrlEndIndex < 0) {
                        return false;
                    } else {
                        final String customUrl = url.substring(customUrlStartIndex, customUrlEndIndex);
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(customUrl)));
                        } catch (ActivityNotFoundException e) {
                            final int packageStartIndex = customUrlEndIndex + INTENT_PROTOCOL_INTENT.length();
                            final int packageEndIndex = url.indexOf(INTENT_PROTOCOL_END);

                            final String packageName = url.substring(packageStartIndex, packageEndIndex < 0 ? url.length() : packageEndIndex);
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(GOOGLE_PLAY_STORE_PREFIX + packageName)));
                        }
                        return true;
                    }
                } else {
                    return false;
                }*/

            }
        }
        @Override
        public void onPageFinished(WebView view, String url)
        {

            Log.d("finish--->url",url);


        }

        @Override
        public void onPageStarted(final WebView view, String url,
                                  Bitmap favicon) {
/*
            if(url.equals("http://hantheminjoo.cafe24.com") || url.equals("http://hantheminjoo.cafe24.com/") || url.equals("http://hantheminjoo.cafe24.com/index.php"))
            {

                //HttpPostData();

                // Create a new HttpClient and Post Header
                HttpClient httpclient = new DefaultHttpClient();
                HttpPost httppost = new HttpPost("http://hantheminjoo.cafe24.com/");

                try {
                    // Add your data
                    List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
                    nameValuePairs.add(new BasicNameValuePair("token", "111111"));
                    nameValuePairs.add(new BasicNameValuePair("token", "222222!"));
                    httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                    // Execute HTTP Post Request
                    HttpResponse response = httpclient.execute(httppost);

                } catch (ClientProtocolException e) {
                    // TODO Auto-generated catch block
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                }




            }
            */
            Log.d("================url::", url);
/*
            if(!url.contains("http://하루밥상안양.com"))
            {
//                Toast.makeText(mContext, "다른페이지임", Toast.LENGTH_SHORT).show();
                button.setVisibility(View.VISIBLE);

                button.setOnClickListener(
                    new Button.OnClickListener() {
                        public void onClick(View v) {

                            KeyEvent e = new KeyEvent(KeyEvent.ACTION_DOWN,KeyEvent.KEYCODE_BACK);
                            onKeyDown(KEYCODE_BACK,e);

                            //08-31 09:59:34.531 3975-3975/com.yb.haru_anyang D/event====>:
                            // KeyEvent { action=ACTION_DOWN, keyCode=KEYCODE_BACK, scanCode=158, metaState=0, flags=0x8, repeatCount=0, eventTime=401247103, downTime=401247103, deviceId=6, displayId=0, source=0x101 }
                            WebView childView = new WebView(MainActivity.this);
                            childView.setWebChromeClient(new WebChromeClient() {
                                @Override
                                public void onCloseWindow(WebView window) {
                                    window.setVisibility(View.GONE);
                                    webview.removeView(window);

                                }
                            });
                        }
                    }
            );

            }

          else  if(url.contains("http://하루밥상안양.com")){
//                Toast.makeText(mContext, "다른페이지아님", Toast.LENGTH_SHORT).show();

                button.setVisibility(View.GONE);
            }
*/           final String furl = url;
            new Thread() {
                public void run() {
                    Run_Logging(furl);
                }
            }.start();



            if ((url.startsWith("http://") || url.startsWith("https://"))
                    && url.endsWith(".apk")) {
                view.stopLoading();
                downloadFile(url);
            }else if (url.startsWith("http://") || url.startsWith("https://")) {
                // nothing

                String auto_login_token = configData.getUserAccounts(mContext);
                //if (url.contains("device=U") || url.contains("login.php") || url.contains("logout.php")){

                // } else {
                if ((url.contains("index.php") || url.contains("orderform.php")) && !url.contains("device=U") ){
                    String tok =  FirebaseInstanceId.getInstance().getToken();
                    if (url.contains("?")) {
                        url = url + "&device=U&token=" + tok;
                        Log.d("url--->1",tok);
                    } else {
                        url = url + "?device=U&token=" + tok;
                        Log.d("url--->2",tok);
                    }
                  //  view.loadUrl(url);
                    return;
                }




            }else if (url != null
                    && (
                    url.contains("vguard")
                            || url.contains("droidxantivirus")
                            || url.contains("smhyundaiansimclick://")
                            || url.contains("smshinhanansimclick://")
                            || url.contains("smshinhancardusim://")
                            || url.contains("smartwall://")
                            || url.contains("appfree://")
                            || url.contains("v3mobile")
                            || url.endsWith(".apk")
                            || url.contains("market://")
                            || url.contains("ansimclick")
                            || url.contains("hananbank://")
                            || url.contains("fb512174235461176://")
                            || url.contains("market://details?id=com.shcard.smartpay")
                            || url.contains("shinhan-sr-ansimclick://")
                            || url.contains("mpocket.online.ansimclick")
                            || url.contains("mvaccinestart")
                            || url.contains("vguardstart")
                            || url.contains("kakaolink")
                            || url.contains("tid") /*하나카드*/
                            || url.contains("kftc-bankpay://")
                            || url.contains("kb-acp://") //kb 국민은행
            )){
                view.stopLoading();
                callApp(url);
            }else if (url.startsWith("smartxpay-transfer://")) {
                view.stopLoading();
                boolean isatallFlag = isPackageInstalled(
                        getApplicationContext(), "kr.co.uplus.ecredit");
                if (isatallFlag) {
                    Intent intent = new Intent(Intent.ACTION_VIEW,
                            Uri.parse(url));
                    intent.addCategory(Intent.CATEGORY_BROWSABLE);
                    intent.putExtra(Browser.EXTRA_APPLICATION_ID,
                            getPackageName());
                    try {
                        startActivity(intent);
                    } catch (ActivityNotFoundException ex) {
                    }
                } else {
                    showAlert("확인버튼을 누르시면 구글플레이로 이동합니다.", "확인",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog,
                                                    int which) {
                                    Intent intent = new Intent(
                                            Intent.ACTION_VIEW,
                                            Uri.parse(("market://details?id=kr.co.uplus.ecredit")));
                                    intent.addCategory(Intent.CATEGORY_BROWSABLE);
                                    intent.putExtra(
                                            Browser.EXTRA_APPLICATION_ID,
                                            getPackageName());
                                    startActivity(intent);
                                    overridePendingTransition(0, 0);
                                }
                            }, "취소", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog,
                                                    int which) {
                                    dialog.cancel();
                                }
                            });
                }
            } else if (url.startsWith("ispmobile://")) {
                view.stopLoading();
                boolean isatallFlag = isPackageInstalled(
                        getApplicationContext(), "kvp.jjy.MispAndroid320");
                if (isatallFlag) {
                    Intent intent = new Intent(Intent.ACTION_VIEW,
                            Uri.parse(url));
                    intent.addCategory(Intent.CATEGORY_BROWSABLE);
                    intent.putExtra(Browser.EXTRA_APPLICATION_ID,
                            getPackageName());

                    try {
                        startActivity(intent);
                    } catch (ActivityNotFoundException ex) {
                    }
                } else {
                    showAlert("확인버튼을 누르시면 구글플레이로 이동합니다.", "확인",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog,
                                                    int which) {
                                    view.loadUrl("http://mobile.vpay.co.kr/jsp/MISP/andown.jsp");
                                }
                            }, "취소", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog,
                                                    int which) {
                                    dialog.cancel();
                                }
                            });
                }
            } else if (url.startsWith("paypin://")) {
                view.stopLoading();
                boolean isatallFlag = isPackageInstalled(
                        getApplicationContext(), "com.skp.android.paypin");
                if (isatallFlag) {
                    Intent intent = new Intent(Intent.ACTION_VIEW,
                            Uri.parse(url));
                    intent.addCategory(Intent.CATEGORY_BROWSABLE);
                    intent.putExtra(Browser.EXTRA_APPLICATION_ID,
                            getPackageName());

                    try {
                        startActivity(intent);
                    } catch (ActivityNotFoundException ex) {
                    }
                } else {
                    Intent intent = new Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse(("market://details?id=com.skp.android.paypin&feature=search_result#?t=W251bGwsMSwxLDEsImNvbS5za3AuYW5kcm9pZC5wYXlwaW4iXQ..")));
                    intent.addCategory(Intent.CATEGORY_BROWSABLE);
                    intent.putExtra(Browser.EXTRA_APPLICATION_ID,
                            getPackageName());
                    startActivity(intent);
                    overridePendingTransition(0, 0);
                }
            } else if (url.startsWith("lguthepay://")) {
                view.stopLoading();
                boolean isatallFlag = isPackageInstalled(
                        getApplicationContext(), "com.lguplus.paynow");
                if (isatallFlag) {
                    Intent intent = new Intent(Intent.ACTION_VIEW,
                            Uri.parse(url));
                    intent.addCategory(Intent.CATEGORY_BROWSABLE);
                    intent.putExtra(Browser.EXTRA_APPLICATION_ID,
                            getPackageName());

                    try {
                        startActivity(intent);
                    } catch (ActivityNotFoundException ex) {
                    }
                } else {
                    Intent intent = new Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse(("market://details?id=com.lguplus.paynow")));
                    intent.addCategory(Intent.CATEGORY_BROWSABLE);
                    intent.putExtra(Browser.EXTRA_APPLICATION_ID,
                            getPackageName());
                    startActivity(intent);
                    overridePendingTransition(0, 0);
                }
            } else {

            }

        }
        @Override
        public void onReceivedHttpAuthRequest(WebView view,
                                              HttpAuthHandler handler, String host, String realm) {
            // TODO Auto-generated method stub
            super.onReceivedHttpAuthRequest(view, handler, host, realm);
        }



    }
    public void Run_Logging(String page){
        String ip = getLocalIpAddress(INET4ADDRESS);
        long now = System.currentTimeMillis();
        Date date = new Date(now);
        SimpleDateFormat CurDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String dt = CurDateFormat.format(date);

      /*  TelephonyManager TMP_HPNUM = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        String HPNUM = TMP_HPNUM.getLine1Number();
        HPNUM = HPNUM.substring(HPNUM.length()-10,HPNUM.length());
        HPNUM="0"+HPNUM;
*/

//		App_Logging(page , ip, dt, HPNUM);
    }





    class joyChromeClient extends WebChromeClient {

        @Override
        public boolean onCreateWindow(WebView view, boolean isDialog,
                                      boolean isUserGesture, Message resultMsg) { //웹뷰내 팝업
            Log.d("window_open", "window_open!!");
            WebView childView = new WebView(MainActivity.this);
            childView.addJavascriptInterface(
                    new JavaScriptInterface(MainActivity.this), "AppUI");
            childView.setLongClickable(true);

            childView.getSettings().setJavaScriptEnabled(true);
            childView.getSettings().setGeolocationEnabled(true);
            childView.getSettings().setJavaScriptCanOpenWindowsAutomatically(
                    true);
            childView.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
            childView.getSettings().setSupportZoom(true);
            childView.getSettings().setBuiltInZoomControls(true);
            childView.getSettings().setUseWideViewPort(true);
            childView.getSettings().setPluginState(WebSettings.PluginState.ON_DEMAND);
            childView.getSettings().setDomStorageEnabled(true);
            childView.getSettings().setSupportMultipleWindows(false);
            childView.getSettings().setLoadWithOverviewMode(true);
            childView.getSettings().setSaveFormData(true);
            childView.getSettings().setLayoutAlgorithm(
                    WebSettings.LayoutAlgorithm.NARROW_COLUMNS);

            /****************/
            childView.setWebViewClient(new ybWebViewClient());
            childView.setTag("is_child");
            // on close window 이동
            /*
            childView.setWebChromeClient(new WebChromeClient() {
                @Override
                public void onCloseWindow(WebView window) {
                    window.setVisibility(View.GONE);
                    webview.removeView(window);

                }
            });*/


            childView.setWebChromeClient(new joyChromeClient());

            /*****************/
            mContainer.addView(childView);
            childViews.add(childView);

            WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
            transport.setWebView(childView);
            resultMsg.sendToTarget();
            Log.d("window_open", "window_open!!");
            if(webview.getUrl().toString().contains("view_image.php")){
                Log.d("view--->","dd");
                webview.goBack();
            }
            return true;

        }

        @Override
        public void onCloseWindow(WebView window) {
            Log.d("창닫기?", "ㅇㅇㅇㅇㅇ");

            String tg = (String)window.getTag();
            if (tg.equals("is_child")) {
                window.setVisibility(View.GONE);
                webview.removeView(window);
            } else {
                mContainer.removeView(window);
                childViews.remove(window);
            }


        }



        public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
            callback.invoke(origin, true, false);
        }

        // For Android Version < 3.0
        public void openFileChooser(ValueCallback<Uri> uploadMsg) {
            //System.out.println("WebViewActivity OS Version : " + Build.VERSION.SDK_INT + "\t openFC(VCU), n=1");
            mUploadMessage = uploadMsg;
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType(TYPE_IMAGE);
            startActivityForResult(intent, INPUT_FILE_REQUEST_CODE);
        }

        // For 3.0 <= Android Version < 4.1
        public void openFileChooser(ValueCallback<Uri> uploadMsg, String acceptType) {
            //System.out.println("WebViewActivity 3<A<4.1, OS Version : " + Build.VERSION.SDK_INT + "\t openFC(VCU,aT), n=2");
            openFileChooser(uploadMsg, acceptType, "");
        }

        // For 4.1 <= Android Version < 5.0
        public void openFileChooser(ValueCallback<Uri> uploadFile, String acceptType, String capture) {
            Log.d(getClass().getName(), "openFileChooser : "+acceptType+"/"+capture);
            mUploadMessage = uploadFile;
            imageChooser();
        }

        // For Android Version 5.0+
        // Ref: https://github.com/GoogleChrome/chromium-webview-samples/blob/master/input-file-example/app/src/main/java/inputfilesample/android/chrome/google/com/inputfilesample/MainFragment.java
        public boolean onShowFileChooser(WebView webView,
                                         ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
            System.out.println("WebViewActivity A>5, OS Version : " + Build.VERSION.SDK_INT + "\t onSFC(WV,VCUB,FCP), n=3");
            if (mFilePathCallback != null) {
                mFilePathCallback.onReceiveValue(null);
            }
            mFilePathCallback = filePathCallback;
            imageChooser();
            return true;
        }

        private void imageChooser() {
            Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                // Create the File where the photo should go
                File photoFile = null;
                try {
                    photoFile = createImageFile();
                    takePictureIntent.putExtra("PhotoPath", mCameraPhotoPath);
                } catch (IOException ex) {
                    // Error occurred while creating the File
                    Log.e(getClass().getName(), "Unable to create Image File", ex);
                }

                // Continue only if the File was successfully created
                if (photoFile != null) {
                    mCameraPhotoPath = "file:"+photoFile.getAbsolutePath();
                    takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT,
                            Uri.fromFile(photoFile));
                } else {
                    takePictureIntent = null;
                }
                fp = photoFile.getAbsolutePath();
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT,
                        Uri.fromFile(photoFile));
            }

            Intent contentSelectionIntent = new Intent(Intent.ACTION_GET_CONTENT);
            contentSelectionIntent.addCategory(Intent.CATEGORY_OPENABLE);
            contentSelectionIntent.setType(TYPE_IMAGE);

            Intent[] intentArray;
            if(takePictureIntent != null) {
                intentArray = new Intent[]{takePictureIntent};
            } else {
                intentArray = new Intent[0];
            }

            Intent chooserIntent = new Intent(Intent.ACTION_CHOOSER);
            chooserIntent.putExtra(Intent.EXTRA_INTENT, contentSelectionIntent);
            chooserIntent.putExtra(Intent.EXTRA_TITLE, "Image Chooser");
            chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, intentArray);

            startActivityForResult(chooserIntent, INPUT_FILE_REQUEST_CODE);
        }


        @Override
        public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("알림")
                    .setMessage(message)
                    .setPositiveButton(android.R.string.ok,
                            new AlertDialog.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    result.confirm();
                                }
                            }
                    ).setCancelable(false).create().show();
            return true;
        }
        @RequiresApi(api = Build.VERSION_CODES.HONEYCOMB)
        @JavascriptInterface
        public String image_down(String url) {
            Log.d("img122","");

            Log.d("img1","1");
            if(url.toLowerCase().endsWith(".jpg") || url.toLowerCase().endsWith(".png")) {
                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                request.allowScanningByMediaScanner();
                Log.d("img1","2");
                request.setNotificationVisibility(
                        DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                Log.d("img1","3");
                //마지막 구분자를 파일명으로 지정. 확장자를 포함하여야 내 파일에서 열린다.
                String filename[] = url.split("/");
                request.setDestinationInExternalPublicDir(
                        Environment.DIRECTORY_DOWNLOADS,    //Download folder
                        filename[filename.length-1]);       //Name of file
                Log.d("img1","4");
                DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                Toast.makeText(getApplicationContext(),"저장되었습니다.", Toast.LENGTH_SHORT).show();
                dm.enqueue(request);
                Log.d("img1","5");
            }



            return "";
        }

        @JavascriptInterface
        public boolean keyboard() {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.toggleSoftInput(0, 0);
            return false;
        }






        @Override
        public boolean onJsConfirm(WebView view, String url, String message, final JsResult result){
            new AlertDialog.Builder(view.getContext())
                    .setTitle("알림")
                    .setMessage(message)
                    .setPositiveButton(android.R.string.ok,
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    result.confirm();
                                }
                            }
                    )
                    .setNegativeButton(android.R.string.cancel,
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    result.cancel();
                                }
                            }
                    ).setCancelable(false).create().show();
            return true;
        }

    }














    private void downloadFile(String mUrl) {
        new DownloadFileTask().execute(mUrl);
    }
    // AsyncTask<Params,Progress,Result>
    private class DownloadFileTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... urls) {
            URL myFileUrl = null;
            try {
                myFileUrl = new URL(urls[0]);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            try {
                HttpURLConnection conn = (HttpURLConnection) myFileUrl
                        .openConnection();
                conn.setDoInput(true);
                conn.connect();
                InputStream is = conn.getInputStream();

                // 다운 받는 파일의 경로는 sdcard/ 에 저장되며 sdcard에 접근하려면
                // uses-permission에
                // android.permission.WRITE_EXTERNAL_STORAGE을 추가해야만 가능.
                String mPath = "sdcard/v3mobile.apk";
                FileOutputStream fos;
                File f = new File(mPath);
                if (f.createNewFile()) {
                    fos = new FileOutputStream(mPath);
                    int read;
                    while ((read = is.read()) != -1) {
                        fos.write(read);
                    }
                    fos.close();
                }

                return "v3mobile.apk";
            } catch (IOException e) {
                e.printStackTrace();
                return "";
            }
        }

        @Override
        protected void onPostExecute(String filename) {
            if (!"".equals(filename)) {
                Toast.makeText(getApplicationContext(),
                        "download complete", Toast.LENGTH_SHORT).show();

                // 안드로이드 패키지 매니저를 사용한 어플리케이션 설치.
                File apkFile = new File(
                        Environment.getExternalStorageDirectory() + "/"
                                + filename);
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setDataAndType(Uri.fromFile(apkFile),
                        "application/vnd.android.package-archive");
                startActivity(intent);
            }
        }
    }
    // 외부 앱 호출
    public boolean callApp(String url) {
        Intent intent = null;
        // 인텐트 정합성 체크 : 2014 .01추가
        try {
            intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
        } catch (URISyntaxException ex) {
            Log.e("Browser", "Bad URI " + url + ":" + ex.getMessage());
            return false;
        }
        try {
            boolean retval = true;
            // chrome 버젼 방식 : 2014.01 추가
            if (url.startsWith("intent")) { // chrome 버젼 방식
                // 앱설치 체크를 합니다.
                if (getApplicationContext().getPackageManager()
                        .resolveActivity(intent, 0) == null) {
                    String packagename = intent.getPackage();
                    if (packagename != null) {
                        Uri uri = Uri.parse("market://search?q=pname:"
                                + packagename);
                        intent = new Intent(Intent.ACTION_VIEW, uri);
                        startActivity(intent);
                        retval = true;
                    }
                } else {
                    intent.addCategory(Intent.CATEGORY_BROWSABLE);
                    intent.setComponent(null);
                    try {
                        if (this.startActivityIfNeeded(intent, -1)) {
                            Log.e("너도일로?", "그런듯한데.");
                            retval = true;
                        }
                    } catch (ActivityNotFoundException ex) {
                        retval = false;
                    }
                }
            } else { // 구 방식
                Uri uri = Uri.parse(url);
                Log.e("==>url", url);
                intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
                retval = true;
            }
            return retval;
        } catch (ActivityNotFoundException e) {
            Log.e("error ===>", e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    // App 체크 메소드 // 존재:true, 존재하지않음:false
    public static boolean isPackageInstalled(Context ctx, String pkgName) {
        try {
            ctx.getPackageManager().getPackageInfo(pkgName,
                    PackageManager.GET_ACTIVITIES);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    //ALERT DIALOG
    public void showAlert(String message, String positiveButton,
                          DialogInterface.OnClickListener positiveListener,
                          String negativeButton,
                          DialogInterface.OnClickListener negativeListener) {
        AlertDialog.Builder alert = new AlertDialog.Builder(getApplicationContext());
        alert.setMessage(message);
        alert.setPositiveButton(positiveButton, positiveListener);
        alert.setNegativeButton(negativeButton, negativeListener);
        alert.show();
    }

    public static String getLocalIpAddress(int type) {
        try {
            for (Enumeration<?> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements();) {
                NetworkInterface intf = (NetworkInterface) en.nextElement();
                for (Enumeration<?> enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements();) {
                    InetAddress inetAddress = (InetAddress) enumIpAddr.nextElement();
                    if (!inetAddress.isLoopbackAddress()) {
                        switch (type) {
                            case INET6ADDRESS:
                                if (inetAddress instanceof Inet6Address) {
                                    return inetAddress.getHostAddress().toString();
                                }
                                break;

                            case INET4ADDRESS:
                                if (inetAddress instanceof Inet4Address) {
                                    return inetAddress.getHostAddress().toString();
                                }
                                break;
                        }
                    }
                }
            }
        }catch (SocketException ex) {
        }
        return null;
    }



    //JAVASCRIPT INTERFACE
    public class JavaScriptInterface extends Activity {
        Context mContext;
        JavaScriptInterface(Context c) {
            mContext = c;
        }
        /*
        @JavascriptInterface
        public String get_hp_num() {
            String HPNUM;
            try{
                TelephonyManager TMP_HPNUM = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
                HPNUM = TMP_HPNUM.getLine1Number();
                HPNUM = HPNUM.substring(HPNUM.length()-10,HPNUM.length());
                HPNUM="0"+HPNUM;
            }catch(NullPointerException e){
                HPNUM = "";
            }
            return HPNUM;
        }
*/
        @JavascriptInterface
        public void app_finish(){
            finish();
        }
        @JavascriptInterface
        public String f_id(){
            SharedPreferences sharedPreferences = getSharedPreferences("pref", MODE_PRIVATE);
            String id = sharedPreferences.getString("id", "nodata");
            return id;
        }
        @JavascriptInterface
        public String codecopy(String code) {
            Log.d("codecode-->",code);

            ClipboardManager clipboardManager = (ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
            ClipData clipData = ClipData.newPlainText("label", code);
            clipboardManager.setPrimaryClip(clipData);
            Toast.makeText(getApplicationContext(),"복사되었습니다.", Toast.LENGTH_SHORT).show();

            return "";
        }



        @JavascriptInterface
        public void dialog_show(final String msg, final int delay){
            mHandler = new Handler();

            runOnUiThread(new Runnable()
            {
                @Override
                public void run()
                {
                    mProgressDialog = ProgressDialog.show(MainActivity.this,"",
                            msg,true);
                    mHandler.postDelayed( new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            try
                            {
                                if (mProgressDialog!=null&&mProgressDialog.isShowing()){
                                    mProgressDialog.dismiss();
                                    //다이얼로그 finish 후 동작할 함수 선언
                                }
                            }
                            catch ( Exception e )
                            {
                                e.printStackTrace();
                            }
                        }
                    }, delay);
                }
            } );
        }
        @JavascriptInterface
        public void camera_open(){
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(intent,1);
        }

        @JavascriptInterface
        public String get_token(){
            String Token = FirebaseInstanceId.getInstance().getToken();
            Log.d("mytoken===>",Token);
            return Token;


        }

        @JavascriptInterface
        public void give_od_id(String od_id) {
            Log.e("od_id",od_id);
            getPrintIfno(od_id);
            //

        }

        @JavascriptInterface
        public void getAppKeyHash(){
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), PackageManager.GET_SIGNATURES);
                        for (Signature signature : info.signatures) {
                            MessageDigest md;
                            md = MessageDigest.getInstance("SHA");
                            md.update(signature.toByteArray());
                            String something = new String(Base64.encode(md.digest(), 0));
                            Log.i("Hash key", something);
                        }
                    } catch (Exception e) {
                        // TODO Auto-generated catch block
                        Log.e("name not found", e.toString());
                    }
                }
            });
        }
        @JavascriptInterface
        public boolean is_android(){
            return true;
        }



        @Override
        public void onPointerCaptureChanged(boolean hasCapture) {

        }
    }
    //주문정보 가져오기
    public void getPrintIfno(String od_id) {

        String addr = "http://autocall6.why-be.co.kr/print_json.php?od_id="+od_id;
        ODIDRequest odidRequest = new ODIDRequest(addr, responseListner,errorListener);
        // 실제 서버 응답 할 수 있는 tfRequest 생성
        if (queue == null) {
            queue = Volley.newRequestQueue(MainActivity.this);
        }
        // loginRequest를 queue에 담아 실행
        queue.add(odidRequest);
                /* 정상적으로 tfRequest가 보내지고 그 결과로 나온 Response가 jsonResponse를 통해서 다루어지게 됨
                 따라서 오류난경우만 예외처리함 */

    }
    Response.Listener<String> responseListner = new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {
            // Response 에서 리스너를 만들어서 결과를 받아올 수 있도록 함
            Log.e("response",response);
            try {
                JSONObject json = new JSONObject(response);
                JSONArray printArray = json.getJSONArray("print");
                ArrayList<PrintItem> alPrint= new ArrayList<>();
                String od_tel = "";
                String od_address = "";
                String od_name = "";
                String od_memo = "";
                for(int i=0;i<printArray.length();i++){
                    JSONObject object = printArray.getJSONObject(i);
                    //메뉴명
                    String od_item = object.getString("od_item");
                    //해당메뉴의 카운트
                    String od_cnt = object.getString("od_cnt");
                    //해당메뉴의 가격
                    String od_price = object.getString("od_price");
                    //주문자 연락처
                    od_tel = object.getString("od_tel");
                    //주문자 주소
                    od_address = object.getString("od_address");
                    //결제 방식
                    String  od_settle_case = object.getString("od_settle_case");
                    //총금액
                    String tot_price = object.getString("tot_price");
                    //주문일시
                    String od_time = object.getString("od_time");
                    //주문번호
                    String od_id = object.getString("od_id");
                    //요청사항
                    od_memo = object.getString("od_memo");

                    alPrint.add(new PrintItem((i+1)+".",od_item,od_cnt,od_price));
                }
                if(alPrint.size()>0){
                    PrintTask task = new PrintTask();
                    task.setAddress(od_address);
                    task.setName(od_name);
                    task.setPhone(od_tel);
                    task.setOrderMemo(od_memo);
                    task.setAlPrint(alPrint);
                    task.execute();
                }
                for(PrintItem item : alPrint ){
                    Log.e("item",item.getNo()+" "+item.getName()+" "+item.getCount()+" "+item.getPrice());
                }

            } catch (JSONException e) {
                e.printStackTrace();

            }

            // 예외처리
        }
    };
    Response.ErrorListener errorListener = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {

        }
    };

    private class PrintTask extends AsyncTask<String, Void, String> {
        //배달주소
        String address;
        //받으시는분
        String name;
        //연락처
        String phone;
        //요청사항
        String orderMemo;
        ArrayList<PrintItem> alPrint = new ArrayList<>();

        public void setAddress(String address) {
            this.address = address;
        }

        public void setName(String name) {
            this.name = name;
        }

        public void setPhone(String phone) {
            this.phone = phone;
        }

        public void setOrderMemo(String orderMemo) {
            this.orderMemo = orderMemo;
        }

        public void setAlPrint(ArrayList<PrintItem> alPrint) {
            this.alPrint = alPrint;
        }

        LodingDialog mLoding;
        public void SetLoding(Context context, String strMsg) {
            if(strMsg.equals("")) {
                if (mLoding == null) {
                    mLoding = new LodingDialog(context, strMsg);
                }
            }
        }



        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            mLoding = new LodingDialog(MainActivity.this, "");
            if (mLoding != null) {
                mLoding.dismiss();
                mLoding.show();
                mLoding.setCancelable(false);
            }
        }

        LinkedList<TableItem> datalist = new LinkedList<>();
        //63개 DASH
        final String strDash = "---------------------------------------------------------------";
        @Override
        protected String doInBackground(String... params) {
            String strRtn = null;

            //매장용
            if (baseApp.isAidl()) {
                datalist.clear();
                addOneData("[매장용]");

                AidlUtil.getInstance().printTable(datalist);
            }

            if (baseApp.isAidl()) {
                //12가 제일 작음,굵게 밑줄 모두 X
                AidlUtil.getInstance().printText(strDash,12,false,false);
            }
            if (baseApp.isAidl()) {
                //12가 제일 작음,굵게 밑줄 모두 X
                datalist.clear();
                addTwoData("배달주소 : ",address);
                AidlUtil.getInstance().printTable(datalist);

                AidlUtil.getInstance().printText("받으시는분 : "+name,21,false,false);
                AidlUtil.getInstance().printText("연락처 : "+phone,21,false,false);
            }
            if (baseApp.isAidl()) {
                //12가 제일 작음,굵게 밑줄 모두 X
                AidlUtil.getInstance().printText(strDash,12,false,false);
            }
            if (baseApp.isAidl()) {
                //12가 제일 작음,굵게 밑줄 모두 X
                AidlUtil.getInstance().printText("요청사항",21,false,false);
                AidlUtil.getInstance().printText(orderMemo,21,false,false);
            }
            if (baseApp.isAidl()) {
                //12가 제일 작음,굵게 밑줄 모두 X
                AidlUtil.getInstance().printText(strDash,12,false,false);
            }
            if (baseApp.isAidl()) {
                datalist.clear();
                addThreeDataTitle("메뉴","수량","금액");
                AidlUtil.getInstance().printTable(datalist);
            }
            if (baseApp.isAidl()) {
                //12가 제일 작음,굵게 밑줄 모두 X
                AidlUtil.getInstance().printText(strDash,12,false,false);
            }
            if (baseApp.isAidl()) {
                datalist.clear();
                for(int i=0;i<alPrint.size();i++){
                    addFourData(alPrint.get(i).getNo(),alPrint.get(i).getName(),alPrint.get(i).getCount(),alPrint.get(i).getPrice());
                }

                AidlUtil.getInstance().printTable(datalist);
            }
            if (baseApp.isAidl()) {
                //12가 제일 작음,굵게 밑줄 모두 X
                AidlUtil.getInstance().printText(strDash,12,false,false);
            }
            if (baseApp.isAidl()) {
                //12가 제일 작음,굵게 밑줄 모두 X
                AidlUtil.getInstance().printText("고객정보를 배달목적 외 사용하거나 보관,",21,false,false);
                AidlUtil.getInstance().printText("공개할 경우 법적처벌을 받을수 있습니다.",21,false,false);
            }

            if (baseApp.isAidl()) {
                //3줄
                AidlUtil.getInstance().print3Line();
            }
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            //매장용
            if (baseApp.isAidl()) {
                datalist.clear();
                addOneData("[고객용]");

                AidlUtil.getInstance().printTable(datalist);
            }

            if (baseApp.isAidl()) {
                //12가 제일 작음,굵게 밑줄 모두 X
                AidlUtil.getInstance().printText(strDash,12,false,false);
            }
            if (baseApp.isAidl()) {
                //12가 제일 작음,굵게 밑줄 모두 X
                datalist.clear();
                addTwoData("배달주소 : ",address);
                AidlUtil.getInstance().printTable(datalist);

                AidlUtil.getInstance().printText("받으시는분 : "+name,21,false,false);
                AidlUtil.getInstance().printText("연락처 : "+phone,21,false,false);
            }
            if (baseApp.isAidl()) {
                //12가 제일 작음,굵게 밑줄 모두 X
                AidlUtil.getInstance().printText(strDash,12,false,false);
            }
            if (baseApp.isAidl()) {
                //12가 제일 작음,굵게 밑줄 모두 X
                AidlUtil.getInstance().printText("요청사항",21,false,false);
                AidlUtil.getInstance().printText(orderMemo,21,false,false);
            }
            if (baseApp.isAidl()) {
                //12가 제일 작음,굵게 밑줄 모두 X
                AidlUtil.getInstance().printText(strDash,12,false,false);
            }
            if (baseApp.isAidl()) {
                datalist.clear();
                addThreeDataTitle("메뉴","수량","금액");
                AidlUtil.getInstance().printTable(datalist);
            }
            if (baseApp.isAidl()) {
                //12가 제일 작음,굵게 밑줄 모두 X
                AidlUtil.getInstance().printText(strDash,12,false,false);
            }
            if (baseApp.isAidl()) {
                datalist.clear();
                for(int i=0;i<alPrint.size();i++){
                    addFourData(alPrint.get(i).getNo(),alPrint.get(i).getName(),alPrint.get(i).getCount(),alPrint.get(i).getPrice());
                }

                AidlUtil.getInstance().printTable(datalist);
            }
            if (baseApp.isAidl()) {
                //12가 제일 작음,굵게 밑줄 모두 X
                AidlUtil.getInstance().printText(strDash,12,false,false);
            }
            if (baseApp.isAidl()) {
                //12가 제일 작음,굵게 밑줄 모두 X
                AidlUtil.getInstance().printText("고객정보를 배달목적 외 사용하거나 보관,",21,false,false);
                AidlUtil.getInstance().printText("공개할 경우 법적처벌을 받을수 있습니다.",21,false,false);
            }

            if (baseApp.isAidl()) {
                //3줄
                AidlUtil.getInstance().print3Line();
            }


            return strRtn;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            if (mLoding != null) {
                mLoding.dismiss();
                mLoding = null;
            }
        }
        //매장용
        public void addOneData(String item) {


            TableItem ti = new TableItem(1);
            ti.getText()[0] = item;

            int[] width = {1};
            ti.setWidth(width);

            int[] align = {2};
            ti.setAlign(align);
            datalist.add(ti);
        }
        //배달주소
        public void addTwoData(String item1,String item2) {


            TableItem ti = new TableItem(2);
            ti.getText()[0] = item1;
            ti.getText()[1] = item2;

            int[] width = {5,11};
            ti.setWidth(width);

            int[] align = {0,0};
            ti.setAlign(align);
            datalist.add(ti);
        }
        //번호 //메뉴,//개수//가격
        public void addFourData(String item1, String item2, String item3, String item4) {


            TableItem ti = new TableItem(4);
            ti.getText()[0] = item1;
            ti.getText()[1] = item2;
            ti.getText()[2] = item3;
            ti.getText()[3] = item4;
            int[] width = {2,9,3,5};
            ti.setWidth(width);

            int[] align = {0,0,1,2};
            ti.setAlign(align);
            datalist.add(ti);
        }
        //번호 //메뉴,//개수//가격
        public void addThreeDataTitle(String item1, String item2, String item3) {


            TableItem ti = new TableItem(3);
            ti.getText()[0] = item1;
            ti.getText()[1] = item2;
            ti.getText()[2] = item3;

            int[] width = {11,3,5};
            ti.setWidth(width);

            int[] align = {0,1,2};
            ti.setAlign(align);
            datalist.add(ti);
        }
    }

    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_PICTURES);
        File imageFile = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );
        return imageFile;
    }
    /*
    protected void onResume(){
        super.onResume();

        IntentIntegrator integrator = new IntentIntegrator(this);
        integrator.setCaptureActivity(CustomScannerActivity.class);
        integrator.initiateScan();


    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        Log.d("onActivityResult", "onActivityResult: .");
        if (resultCode == Activity.RESULT_OK) {
            IntentResult scanResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, intent);
            String re = scanResult.getContents();
            String message = re;
            Log.d("onActivityResult", "onActivityResult: ." + re);
            Toast.makeText(this, re, Toast.LENGTH_LONG).show();
        }
    }
    */


    private void askWritePermission(){
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    MY_PERMISSIONS_REQUEST_WRITE_STORAGE);
        }
        else{
            initState();
        }
    }
    private Bitmap createBitmap(Image image){
        Log.d("kanna", "check create bitmap: " + Thread.currentThread().toString());
        Bitmap bitmap;
        Image.Plane[] planes = image.getPlanes();
        ByteBuffer buffer = planes[0].getBuffer();
        int pixelStride = planes[0].getPixelStride();
        int rowStride = planes[0].getRowStride();
        int rowPadding = rowStride - pixelStride * image.getWidth();
        // create bitmap
        bitmap = Bitmap.createBitmap(image.getWidth() + rowPadding / pixelStride,
                image.getHeight(), Bitmap.Config.ARGB_8888);
        bitmap.copyPixelsFromBuffer(buffer);
        image.close();
        return bitmap;
    }

    private Flowable<Image> getScreenShot(){
        final Point screenSize = new Point();
        final DisplayMetrics metrics = getResources().getDisplayMetrics();
        Display display = getWindowManager().getDefaultDisplay();
        display.getRealSize(screenSize);
        return Flowable.create(new FlowableOnSubscribe<Image>() {
            @Override
            public void subscribe(@NonNull final FlowableEmitter<Image> emitter) throws Exception {
                mImageReader = ImageReader.newInstance(screenSize.x, screenSize.y, PixelFormat.RGBA_8888, 2);
                mVirtualDisplay = mProjection.createVirtualDisplay("cap", screenSize.x, screenSize.y, metrics.densityDpi,
                        DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, mImageReader.getSurface(), null, null);
                mImageListener = new ImageReader.OnImageAvailableListener() {
                    Image image = null;
                    @Override
                    public void onImageAvailable(ImageReader imageReader) {
                        try {
                            image = imageReader.acquireLatestImage();
                            Log.d("kanna", "check reader: " + Thread.currentThread().toString());
                            if (image != null) {
                                emitter.onNext(image);
                                emitter.onComplete();
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            emitter.onError(new Throwable("ImageReader error"));
                        }
                        mImageReader.setOnImageAvailableListener(null, null);
                    }

                };
                mImageReader.setOnImageAvailableListener(mImageListener, null);

            }
        },BackpressureStrategy.DROP);
    }
    private Flowable<String> createFile(){
        return Flowable.create(new FlowableOnSubscribe<String>() {
            @Override
            public void subscribe(@NonNull FlowableEmitter<String> emitter) throws Exception {
                Log.d("kanna", "check create filename: " + Thread.currentThread().toString());
                String directory, fileHead, fileName;
                int count = 0;
                File externalFilesDir = getExternalStoragePublicDirectory(DIRECTORY_PICTURES);
                if (externalFilesDir != null) {
                    directory = getExternalStoragePublicDirectory(DIRECTORY_PICTURES)
                            .getAbsolutePath() + "/screenshots/";

                    Log.d("kanna", directory);
                    File storeDirectory = new File(directory);
                    if (!storeDirectory.exists()) {
                        boolean success = storeDirectory.mkdirs();
                        if (!success) {
                            emitter.onError(new Throwable("failed to create file storage directory."));
                            return;
                        }
                    }
                } else {
                    emitter.onError(new Throwable("failed to create file storage directory," +
                            " getExternalFilesDir is null."));
                    return;
                }

                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
                Calendar c = Calendar.getInstance();
                fileHead = simpleDateFormat.format(c.getTime()) + "_";
                fileName = directory + fileHead + count + ".png";
                File storeFile = new File(fileName);
                while (storeFile.exists()) {
                    count++;
                    fileName = directory + fileHead + count + ".png";
                    storeFile = new File(fileName);
                }
                emitter.onNext(fileName);
                emitter.onComplete();
            }
        },BackpressureStrategy.DROP).subscribeOn(Schedulers.io());
    }
    private void writeFile(Bitmap bitmap, String fileName) throws IOException {
        Log.d("kanna", "check write file: " + Thread.currentThread().toString());
        FileOutputStream fos = new FileOutputStream(fileName);
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
        fos.close();
        bitmap.recycle();
    }
    private Flowable<String> updateScan(final String fileName){
        return Flowable.create(new FlowableOnSubscribe<String>() {
            @Override
            public void subscribe(@NonNull final FlowableEmitter<String> emitter) throws Exception {
                String[] path = new String[]{fileName};
                mScanListener = new MediaScannerConnection.OnScanCompletedListener() {
                    @Override
                    public void onScanCompleted(String s, Uri uri) {
                        Log.d("kanna", "check scan file: " + Thread.currentThread().toString());
                        if (uri == null) {
                            emitter.onError(new Throwable("Scan fail" + s));
                        }
                        else {
                            emitter.onNext(s);
                            emitter.onComplete();
                        }
                    }
                };
                MediaScannerConnection.scanFile(mContext, path, null, mScanListener);
            }
        },BackpressureStrategy.DROP);
    }
    private void finalRelease(){
        if (mVirtualDisplay != null){
            mVirtualDisplay.release();
        }
        if (mImageReader != null){
            mImageReader = null;
        }
        if(mImageListener != null){
            mImageListener = null;
        }
        if(mScanListener != null){
            mScanListener = null;
        }
        if(mProjection != null){
            mProjection.stop();
            mProjection = null;
        }
    }

    /*
    RXJava
     */
    private void shotScreen(){
        getScreenShot()
                .subscribeOn(AndroidSchedulers.mainThread())
                .observeOn(Schedulers.io())
                .map(new Function<Image, Bitmap>() {
                    @Override
                    public Bitmap apply(@NonNull Image image) throws Exception {
                        return createBitmap(image);
                    }
                })
                .zipWith(createFile(), new BiFunction<Bitmap, String, String>() {
                    @Override
                    public String apply(@NonNull Bitmap bitmap, @NonNull String fileName) throws Exception {
                        writeFile(bitmap, fileName);
                        return fileName;
                    }
                })
                .flatMap(new Function<String, Publisher<String>>() {
                    @Override
                    public Publisher<String> apply(@NonNull String fileName) throws Exception {
                        return updateScan(fileName);
                    }
                })
                .observeOn(Schedulers.io())
                .doFinally(new Action() {
                    @Override
                    public void run() throws Exception {
                        Log.d("kanna", "check do finally: " + Thread.currentThread().toString());
                        finalRelease();
                    }
                })
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<String>() {

                    @Override
                    public void onSubscribe(Subscription s) {
                        s.request(Long.MAX_VALUE);
                    }

                    @Override
                    public void onNext(String filename) {
                        Log.d("kanna", "onNext: " + filename);
                        Toast.makeText(mContext, "Success: " + filename, Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onError(Throwable t) {
                        Log.w("kanna", "onError: ", t);
                        Toast.makeText(mContext, "Error: " + t, Toast.LENGTH_SHORT).show();

                    }

                    @Override
                    public void onComplete() {
                        Log.d("kanna", "onComplete");
                    }
                });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_CODE) {
            mProjection = mProjectionManager.getMediaProjection(resultCode, data);
            if(mProjection != null) {
                shotScreen();
            }
        }
    }

    private void screenShot(){
        if(mProjectionManager != null) {
            startActivityForResult(mProjectionManager.createScreenCaptureIntent(), REQUEST_CODE);
        }
    }




    private class SendPost extends AsyncTask<Void, Void, String> {
        protected String doInBackground(Void... unused) {
            String content = executeClient();
            return content;
        }

        protected void onPostExecute(String result) {
            // 모두 작업을 마치고 실행할 일 (메소드 등등)
        }

        // 실제 전송하는 부분
        public String executeClient() {
            String refreshedToken = FirebaseInstanceId.getInstance().getToken();
            String device_id = Settings.Secure.getString(getApplicationContext().getContentResolver(), Settings.Secure.ANDROID_ID);
            //String hp = get_hp_num();

            ArrayList<NameValuePair> post = new ArrayList<NameValuePair>();
            post.add(new BasicNameValuePair("token", refreshedToken));
            post.add(new BasicNameValuePair("uniqid", device_id));
            post.add(new BasicNameValuePair("gubun", "store"));
            //  post.add(new BasicNameValuePair("hp", hp));

            //          Log.d("타니????","ㅇㅇㅇㅇ");
//            Log.d("타니????111",refreshedToken);
//            Log.d("타니????222",device_id);
            // 연결 HttpClient 객체 생성
            HttpClient client = new DefaultHttpClient();

            // 객체 연결 설정 부분, 연결 최대시간 등등
            HttpParams params = client.getParams();
            HttpConnectionParams.setConnectionTimeout(params, 5000);
            HttpConnectionParams.setSoTimeout(params, 5000);

            // Post객체 생성
           //HttpPost httpPost = new HttpPost("http://하루밥상상록.com/register_token
            // ");
            HttpPost httpPost = new HttpPost("http://autocall4.why-be.co.kr/mobile/savetoken.php");
            //HttpPost httpPost = new HttpPost("http://youbojob.why-be.co.kr/ju/test_2.php");
            Log.d("타니????","ㅇㅇㅇㅇㅇ");
            try {
                UrlEncodedFormEntity entity = new UrlEncodedFormEntity(post, "UTF-8");
                httpPost.setEntity(entity);
                client.execute(httpPost);
                return EntityUtils.getContentCharSet(entity);
            } catch (ClientProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    private Handler mHandler;
    private boolean mFlag = false;
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        Log.d("keyCode====>", String.valueOf(keyCode));
        Log.d("event====>",event.toString());
        if(keyCode == KEYCODE_BACK){
            Log.i("keydown url==>",webview.getUrl());
            if((webview.getUrl().toString().equals("http://autocall4.why-be.co.kr/mobile/shop/store/index.php"))
                //if(webview.getUrl().toString().equals("http://kth8295.why-be.co.kr")
                    ){
                if(!mFlag) {
                    Toast.makeText(this, "'뒤로' 버튼을 한번 더 누르시면 종료됩니다.", Toast.LENGTH_SHORT).show();
                    mFlag = true;
                    return false;
                }else{
                    finish();
                }
            }
            if(webview.canGoBack()){
                webview.goBack();
                return false;
            }else{
                if(!mFlag) {
                    Toast.makeText(this, "'뒤로' 버튼을 한번 더 누르시면 종료됩니다.", Toast.LENGTH_SHORT).show();
                    mFlag = true;
                    return false;
                }else{
                    finish();
                }
            }
        }
        return super.onKeyDown(keyCode, event);
    }


    public String get_hp_num() {

        String HPNUM = "";
        /*
        try {
            TelephonyManager TMP_HPNUM = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
            HPNUM = TMP_HPNUM.getLine1Number();

            HPNUM = HPNUM.substring(HPNUM.length() - 10, HPNUM.length());
            HPNUM = "0" + HPNUM;

            StringBuilder b1 = new StringBuilder(HPNUM);
            for (int i = b1.length() - 1; i > 0; i--) {
                if (i % 2 == 0) {
                    b1.insert(i, "****");
                }
            }
            //  Log.d("HPNUM==>",b1.toString());

            HPNUM = b1.toString();
        }catch(Exception e){
            HPNUM = "null";
        }
        Log.d("hpnnn->",HPNUM);

    */
        return HPNUM;
    }

/*
    public void HttpPostData() {

        try {
            Log.d("httppostdate","1");
            //--------------------------
            //   URL 설정하고 접속하기
            //--------------------------
            URL url = new URL("http://hantheminjoo.cafe24.com/index.php");       // URL 설정
            HttpURLConnection http = (HttpURLConnection) url.openConnection();   // 접속
            //--------------------------
            //   전송 모드 설정 - 기본적인 설정이다
            //--------------------------
            http.setDefaultUseCaches(false);
            http.setDoInput(true);                         // 서버에서 읽기 모드 지정
            http.setDoOutput(true);                       // 서버로 쓰기 모드 지정
            http.setRequestMethod("POST");         // 전송 방식은 POST

            // 서버에게 웹에서 <Form>으로 값이 넘어온 것과 같은 방식으로 처리하라는 걸 알려준다
            http.setRequestProperty("content-type", "application/x-www-form-urlencoded");
            //--------------------------
            //   서버로 값 전송
            //--------------------------
            StringBuffer buffer = new StringBuffer();

            String refreshedToken = FirebaseInstanceId.getInstance().getToken();
            String device_id = Settings.Secure.getString(getApplicationContext().getContentResolver(), Settings.Secure.ANDROID_ID);
            String hp = get_hp_num();


            buffer.append("token").append("=").append(refreshedToken).append("&");                 // php 변수에 값 대입
            buffer.append("uniq_id").append("=").append(device_id).append("&");   // php 변수 앞에 '$' 붙이지 않는다
            buffer.append("hp").append("=").append(hp).append("&");

            OutputStreamWriter outStream = new OutputStreamWriter(http.getOutputStream(), "EUC-KR");
            PrintWriter writer = new PrintWriter(outStream);
            writer.write(buffer.toString());
            Toast.makeText(MainActivity.this, "전송", Toast.LENGTH_LONG).show();
            writer.flush();


        } catch (MalformedURLException e) {
            //
        } catch (IOException e) {
            //
        } // try
    } // HttpPostData

*/




}
