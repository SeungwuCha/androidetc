package com.sunmi.smart.activity;

import android.util.Log;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;

public class MyFirebaseInstantService extends FirebaseInstanceIdService {
    public static String push_key = "";
    @Override
    public void onTokenRefresh() {
        // Get updated InstanceID token.
        String refreshedToken = FirebaseInstanceId.getInstance().getToken();
        Log.d("My fire", "Refreshed token: " + refreshedToken);

        push_key = refreshedToken;

        configData.setRegistrationId(getApplicationContext(),push_key);
    }
}
