package com.sunmi.smart.activity;

import android.content.Context;


public class configData {

	//FIXME: GCM_SENDER_ID 넣어주세요.
	public final static String GCM_SENDER_ID = "22222222";	// GCM 발송 SENDER_ID (구글 개발자 사이트에서 발급받은 고유값)
	public final static int GCM_NOTIFICATION_ID = 123878;	// GCM 노티 ID (임의의 값)

	public final static String PREF_REGISTRATION_ID = "regId";
	public final static String PREF_USER_ACCOUNTS = "userAccounts";

	/**
	 * RegistrationId
	 */
	static public boolean  setRegistrationId(Context context, String regId){
		return PreferenceWrapper.setPreferenceString(context, PREF_REGISTRATION_ID, regId);
	}

	static public String getRegistrationId(Context context) {
		return PreferenceWrapper.getPreferenceString(context, PREF_REGISTRATION_ID, "");
	}

	/**
	 * userAccounts
	 * && 로 아이디와 패스워드 구분
	 */
	static public boolean  setUserAccounts(Context context, String userAccounts){
		return PreferenceWrapper.setPreferenceString(context, PREF_USER_ACCOUNTS , userAccounts);
	}

	static public String getUserAccounts(Context context) {
		return PreferenceWrapper.getPreferenceString(context, PREF_USER_ACCOUNTS, "");
	}
}
