package com.sunmi.smart.activity;

import android.util.Log;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class MyFirebaseMessageService extends FirebaseMessagingService {
    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {

        //String title = remoteMessage.getNotification().getTitle();
        //String body = remoteMessage.getNotification().getBody();
        String title = remoteMessage.getData().get("message");
        String content = remoteMessage.getData().get("content");
        String body = remoteMessage.getData().get("imgurllink");
        //String body = remoteMessage.getData().get("imgurllink");

        Log.i("PVL1", "RECEIVED MESSAGE: " + title);
        Log.i("PVL2", "RECEIVED MESSAGE: " + content);
        Log.i("PVL3", "RECEIVED MESSAGE: " + body);
        // Log.i("PVL", "RECEIVED MESSAGE22: " + content);

/*
        Log.d("title==>",title);
        Log.d("content==>",content);
        Log.d("body==>",body);
*/


        MyPushNotification.getInstance(getApplicationContext())
                .displayNotification(title,content,body);
    }

}
