package com.sunmi.smart.bean;

public class PrintItem {
    //no(숫자와.)
    String no;
    //name(제품명)
    String name;
    //개수
    String count;
    //가격
    String price;

    public PrintItem(String no, String name, String count, String price) {
        this.no = no;
        this.name = name;
        this.count = count;
        this.price = price;
    }

    public String getNo() {
        return no;
    }

    public void setNo(String no) {
        this.no = no;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }
}
