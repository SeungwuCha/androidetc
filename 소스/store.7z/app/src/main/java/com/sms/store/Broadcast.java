package com.sms.store;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;
import android.widget.Toast;


import java.text.SimpleDateFormat;
import java.util.Date;

public class Broadcast extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        if ("android.provider.Telephony.SMS_RECEIVED".equals(intent.getAction())) {
            Log.d("onReceive()", "문자수신");

            // SMS
            Bundle bundle = intent.getExtras();
            Object messages[] = (Object[]) bundle.get("pdus");
            SmsMessage smsMessage[] = new SmsMessage[messages.length];

            for (int i = 0; i < messages.length; i++) {

                smsMessage[i] = SmsMessage.createFromPdu((byte[]) messages[i]);
            }


            Date curDate = new Date(smsMessage[0].getTimestampMillis());
            Log.d("onReceive()", curDate.toString());


            String origNumber = smsMessage[0].getOriginatingAddress();


            String message = smsMessage[0].getMessageBody().toString();
            Log.d("onReceive()", "전화번호" + origNumber + " " + "message" + message);
            // abortBroadcast();
            //TODO 데이터 베이스에 저장
            if(Sharedpreference.getSharedPrefNo(context).equals(origNumber)) {
                CallDBAdapter callDBAdapter = new CallDBAdapter(context);
                callDBAdapter.open();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                callDBAdapter.createEntry(origNumber, message, sdf.format(new Date()));
                callDBAdapter.close();
            }
        }
    }
}
