package com.sms.store;



import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;
import android.util.Log;

public class CallDBAdapter {


	private static final String DATABASE_NAME = "calldb.db";
	private static final String DATABASE_TABLE = "tb_calldb";

	public static final int DATABASE_VERSION = 1;
	private static final String DATABASE_CREATE = "create table "
			+ DATABASE_TABLE + " (" + CallEntry.Call_IDX
			+ " INTEGER primary key, " +  CallEntry.Call_NO
			+ " TEXT not null, " + CallEntry.Call_TEXT
			+ " TEXT not null, " + CallEntry.Call_DATE
			+ " TEXT not null);";
	private static final String TAG = "BoothDBAdapter";

	public String[] COLUMNS = new String[] {CallEntry.Call_IDX,
			CallEntry.Call_NO, CallEntry.Call_TEXT,CallEntry.Call_DATE
			};
	private String[] CountCOLUMNS = new String[] {"count(idx)"
			};
	private Context mContext;
	private DCTDatabaseHelper mDbHelper;
	private SQLiteDatabase mDb;

	public CallDBAdapter(Context context) {
		mContext = context;
	}

	public CallDBAdapter open() throws SQLException {
		mDbHelper = new DCTDatabaseHelper(mContext);
		mDb = mDbHelper.getWritableDatabase();
		return this;
	}

	public void close() {
		if(mDbHelper!=null)
			mDbHelper.close();
	}
	
	
	public long createEntry(String no, String text,String date) {
		ContentValues initialValues = new ContentValues();

		initialValues.put(CallEntry.Call_TEXT, text);
		initialValues.put(CallEntry.Call_NO, no);
		initialValues.put(CallEntry.Call_DATE,date);

		
		
		return mDb.insert(DATABASE_TABLE, null, initialValues);
	}
	


	

	public Cursor selectIDXEntry(String strIdx) {
		//
		Cursor qu = mDb.query(DATABASE_TABLE, COLUMNS,
				CallEntry.Call_IDX+" = "+strIdx,
				null, null, null, null);

		return qu;

	}



	
	public Cursor fetchAllEntry() {
		return mDb.query(DATABASE_TABLE, COLUMNS, null, null, null, null, null);
	}
	public Cursor fetchAllEntryASC() {
		return mDb.query(DATABASE_TABLE, COLUMNS, null, null, null, null, CallEntry.Call_IDX+" asc");
	}
	
	
	public int fetchAllEntryLength() {
		return mDb.query(DATABASE_TABLE, COLUMNS, null, null, null, null, null).getCount();
	}
	
	public void delIDXEntry(String strIdx) {
		mDb.delete(DATABASE_TABLE, CallEntry.Call_IDX+"= "+strIdx, null);
	}

    public void delAllEntry() {
		mDb.delete(DATABASE_TABLE, null, null);
    }


    private class DCTDatabaseHelper extends SQLiteOpenHelper {

		public DCTDatabaseHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			db.execSQL(DATABASE_CREATE);

		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
					+ newVersion + ", which will destory all old data");
			db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
			onCreate(db);
		}

	}



	
	public class CallEntry implements BaseColumns {
		public static final String Call_IDX = "idx";

		public static final String Call_NO = "call_no";
		public static final String Call_TEXT = "call_text";
		public static final String Call_DATE = "call_date";

	}
	
}
