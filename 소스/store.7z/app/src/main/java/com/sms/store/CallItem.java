package com.sms.store;

/**
 * Created by csw on 2017-09-07.
 */

public class CallItem {
    String no;
    String text;
    String date;

    public CallItem(String no, String text, String date) {
        this.no = no;
        this.text = text;
        this.date = date;
    }

    public String getNo() {
        return no;
    }

    public void setNo(String no) {
        this.no = no;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
