package com.sms.store;

import android.content.Context;
import android.content.SharedPreferences;

public class Sharedpreference {

	final private static String PREFNAME_Phone = "phone";
	//전화번호
	final private static String PREFKEY_NO = "no";




	public static void setSharedPrefNo(Context context, String value){
		SharedPreferences pref = context.getSharedPreferences(PREFNAME_Phone, Context.MODE_PRIVATE);
		SharedPreferences.Editor prefEditor = pref.edit();
		prefEditor.putString(PREFKEY_NO, value);
		prefEditor.commit();
	}

	public static String getSharedPrefNo(Context context){
		SharedPreferences pref = context.getSharedPreferences(PREFNAME_Phone, Context.MODE_PRIVATE);
		return pref.getString(PREFKEY_NO,"");
	}


}
