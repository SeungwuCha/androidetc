package com.sms.store;

import android.Manifest;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.gun0912.tedpermission.PermissionListener;
import com.gun0912.tedpermission.TedPermission;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    EditText et_phone;
    Button btn_phone;
    ListView list;
    CallAdapter adapter;
    ArrayList<CallItem> alCall =  new ArrayList<>();
    Button btn_save;
    Button btn_load;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        checkPermission();
        initRes();
        getData();
    }
    public void checkPermission(){
        TedPermission.with(this)
                .setPermissionListener(permissionlistener)
                .setDeniedMessage("If you reject permission,you can not use this service\n\nPlease turn on permissions at [Setting] > [Permission]")
                .setPermissions(Manifest.permission.RECEIVE_SMS,Manifest.permission.RECEIVE_MMS,Manifest.permission.READ_SMS,Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.READ_EXTERNAL_STORAGE)
                .check();
    }
    PermissionListener permissionlistener = new PermissionListener() {
        @Override
        public void onPermissionGranted() {
          //  Toast.makeText(MainActivity.this, "Permission Granted", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onPermissionDenied(ArrayList<String> deniedPermissions) {
            Toast.makeText(MainActivity.this, "Permission Denied\n" + deniedPermissions.toString(), Toast.LENGTH_SHORT).show();
        }


    };

    private void getData() {
        CallDBAdapter dbAdapter = new CallDBAdapter(this);
        dbAdapter.open();
        Cursor c = dbAdapter.fetchAllEntry();
        while(c.moveToNext()){
            alCall.add(new CallItem(c.getString(1),c.getString(2),c.getString(3)));
        }
        adapter.notifyDataSetChanged();
        dbAdapter.close();

    }

    private void initRes() {
        et_phone = (EditText)findViewById(R.id.et_phone);
        et_phone.setText(Sharedpreference.getSharedPrefNo(this));
        btn_phone = (Button)findViewById(R.id.btn_phone);
        btn_phone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Sharedpreference.setSharedPrefNo(MainActivity.this,et_phone.getText().toString());
            }
        });

        btn_save = (Button)findViewById(R.id.btn_save);
        btn_load = (Button)findViewById(R.id.btn_load);
        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                File file = new File(Environment.getExternalStorageDirectory() + "/call.csv");
                FileWriter fw = null;
                BufferedWriter bw = null;
                try {
                    CallDBAdapter callDBAdapter = new CallDBAdapter(MainActivity.this);
                    callDBAdapter.open();
                    //callDBAdapter.delAllEntry();

                    fw = new FileWriter(file);
                    bw = new BufferedWriter(fw);
                    Cursor c = callDBAdapter.fetchAllEntry();
                    while(c.moveToNext()){
                        bw.write(c.getString(1)+","+c.getString(2)+","+c.getString(3));
                        bw.newLine();
                    }
                    bw.close();
                    fw.close();
                    callDBAdapter.close();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        btn_load.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                File file = new File(Environment.getExternalStorageDirectory() + "/call.csv");
                FileReader fis = null;
                BufferedReader in = null;
                try {
                    CallDBAdapter callDBAdapter = new CallDBAdapter(MainActivity.this);
                    callDBAdapter.open();
                    callDBAdapter.delAllEntry();

                    fis = new FileReader(file);
                    in = new BufferedReader(fis);
                    String s;
                    while ((s = in.readLine()) != null) {
                        String[] strArray = s.split(",");
                        if (strArray.length >= 3) {
                            callDBAdapter.createEntry(strArray[0], strArray[1], strArray[2]);
                        }

                    }
                    in.close();
                    fis.close();
                    callDBAdapter.close();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        list = (ListView)findViewById(R.id.list);
        adapter = new CallAdapter(this,R.layout.item_call,alCall);
        list.setAdapter(adapter);

    }


}
