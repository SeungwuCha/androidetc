package com.sms.store;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import android.widget.TextView;


import java.util.ArrayList;


public class CallAdapter extends BaseAdapter {
	private Context context;
	private LayoutInflater inflater;
	private ArrayList<CallItem> arSrc;
	private int layout;

	public CallAdapter(Context c, int layout, ArrayList<CallItem> arSrc) {
		this.context = c;
		this.inflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		this.arSrc = arSrc;
		this.layout = layout;

	}

	@Override
	public int getCount() {
		return arSrc.size();
	}

	@Override
	public CallItem getItem(int position) {
		return arSrc.get(position);
	}

	@Override
	public long getItemId(int arg0) {
		return 0;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		LVHolder viewHolder;

		if (convertView == null) {
			convertView = inflater.inflate(layout, parent, false);

			viewHolder = new LVHolder();

			viewHolder.tv_no = (TextView) convertView.findViewById(R.id.tv_no);
			viewHolder.tv_text = (TextView) convertView.findViewById(R.id.tv_text);
			viewHolder.tv_date = (TextView) convertView.findViewById(R.id.tv_date);


			convertView.setTag(viewHolder);
		} else {
			viewHolder = (LVHolder) convertView.getTag();
		}


		CallItem item = arSrc.get(position);

		viewHolder.tv_no.setText(item.getNo());
		viewHolder.tv_text.setText(item.getText());
		viewHolder.tv_date.setText(item.getDate());




		
		return convertView;
	}



	public class LVHolder {

		TextView tv_no, tv_text,tv_date;
	}

	

	



}
