package com.kmong.bluelight.list;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;

import com.kmong.bluelight.R;

import java.util.ArrayList;

/** An array adapter that knows how to render views when given CustomData classes */
public class CustomArrayAdapter extends ArrayAdapter<CustomData> {
    private LayoutInflater mInflater;

    public CustomArrayAdapter(Context context, ArrayList<CustomData> values) {
        super(context, R.layout.custom_data_view, values);
        mInflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Holder holder;

        if (convertView == null) {
            // Inflate the view since it does not exist
            convertView = mInflater.inflate(R.layout.custom_data_view, parent, false);

            // Create and save off the holder in the tag so we get quick access to inner fields
            // This must be done for performance reasons
            holder = new Holder();
           // holder.btn = (Button) convertView.findViewById(R.id.btn);
            holder.iv = (ImageView) convertView.findViewById(R.id.iv);

            convertView.setTag(holder);
        } else {
            holder = (Holder) convertView.getTag();
        }

        // Populate the text
        if(!getItem(position).getText().equals("set")) {
/*            holder.btn.setText(getItem(position).getText());
            holder.btn.setVisibility(View.VISIBLE);*/
            holder.iv.setVisibility(View.INVISIBLE);
        }else{
      //      holder.btn.setVisibility(View.INVISIBLE);
            holder.iv.setVisibility(View.VISIBLE);
        }

        // Set the color
        convertView.setBackgroundResource(getItem(position).IsEnable()?R.color.btn_enable_true:R.color.btn_enable_false);

        return convertView;
    }

    /** View holder for the views we need access to */
    private static class Holder {
        public Button btn;
        public ImageView iv;
    }
}
