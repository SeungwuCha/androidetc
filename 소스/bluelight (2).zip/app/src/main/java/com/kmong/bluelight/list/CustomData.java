package com.kmong.bluelight.list;

/** This is just a simple class for holding data that is used to render our custom view */
public class CustomData {
    private boolean mIsEnable;
    private String mText;

    public CustomData(String text,boolean isEnable) {
        mIsEnable = isEnable;
        mText = text;
    }


    public boolean IsEnable() {
        return mIsEnable;
    }

    /**
     * @return the text
     */
    public String getText() {
        return mText;
    }
}
