package com.qrcode.calllogtest;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.provider.CallLog;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.gun0912.tedpermission.PermissionListener;
import com.gun0912.tedpermission.TedPermission;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    EditText et_phone;
    Button btn_del;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        permissionCheck();
        initRes();

    }

    private void initRes() {
        et_phone = (EditText)findViewById(R.id.et_phone);
        btn_del = (Button)findViewById(R.id.btn_del);
        btn_del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //DeleteCallLogByNumber(et_phone.getText().toString());
               // selectCallLogByNumber();
                int n1 = DeleteCallLogByNumber1(et_phone.getText().toString());
                int n2= DeleteCallLogByNumber2(et_phone.getText().toString());
                Toast.makeText(MainActivity.this, (n1+n2)+"개 삭제완료", Toast.LENGTH_SHORT).show();
              //  selectCallLogByNumber();
            }
        });
    }

    private void permissionCheck() {
        TedPermission.with(this)
                .setPermissionListener(permissionlistener)
                .setDeniedMessage("If you reject permission,you can not use this service\n\nPlease turn on permissions at [Setting] > [Permission]")
                .setPermissions(Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CALL_LOG,Manifest.permission.WRITE_CONTACTS,Manifest.permission.READ_CALL_LOG)
                .check();
    }

    public int DeleteCallLogByNumber1(String phone) {
        String queryString = "number='" + phone+"'";
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return 0;
        }
       return this.getContentResolver().delete(CallLog.Calls.CONTENT_URI, queryString, null);
    }
    public int DeleteCallLogByNumber2(String phone) {
        String queryString = "number=" + phone+"";
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return 0;
        }
        return this.getContentResolver().delete(CallLog.Calls.CONTENT_URI, queryString, null);
    }
    public void selectCallLogByNumber() {

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        String queryString = "number = '01042338364'";
        Cursor c1 = getContentResolver().query(CallLog.Calls.CONTENT_URI,null,queryString,null,null);
        Log.e("cursorCount",""+c1.getCount());
        while(c1.moveToNext()){
            Log.e("number",c1.getString(c1.getColumnIndex("number"))+" "+c1.getString(c1.getColumnIndex("_id")));
            //DeleteCallLogByNumber(c1.getString(c1.getColumnIndex("_id")));
        }
    }
    PermissionListener permissionlistener = new PermissionListener() {
        @Override
        public void onPermissionGranted() {

        }

        @Override
        public void onPermissionDenied(List<String> deniedPermissions) {
            Toast.makeText(MainActivity.this, "Permission Denied\n" + deniedPermissions.toString(), Toast.LENGTH_SHORT).show();
        }


    };
}
